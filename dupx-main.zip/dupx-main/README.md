# UPX 脱壳工具 (ARM64 Linux)

> 基于 `ptrace` + `process_vm_readv` 的 UPX 内存脱壳工具，适用于 ARM64 Linux 平台。

作者：难忘 <743225426@qq.com>

## 项目简介

本项目通过 `ptrace` 跟踪目标进程的系统调用，在 UPX 完成解压后、程序正式执行前，从进程内存中扫描并导出还原后的 ELF 文件，实现内存脱壳。

**核心原理：**

1. `fork` + `ptrace(TRACEME)` 启动目标程序，在 `execve` 处中断
2. 单步跟踪系统调用，捕获 `read` (syscall nr=63) 作为 UPX 解压完成的信号
3. 扫描 `/proc/<pid>/maps` 定位解压后的 ELF 基址
4. 解析 ELF 程序头表（PT_LOAD 段），从内存中 dump 出完整 ELF 文件

## 编译

```bash
gcc -O2 -o dupx dupx.c
```


## 使用方法

```bash
# 基本用法
sudo ./dupx <目标程序路径> [参数...]

# 指定输出文件名
sudo ./dupx ./hello_packed -o dump.bin
```

### 示例

```bash
$ ./dupx ./hello_packed
========================================
  UPX脱壳工具 (ARM64 Linux)
========================================
[+] 目标程序: ./hello_packed
[*] 等待系统调用 read (NR=63) ...
    (此时 UPX 正在解压，解压完成后 ld.so 会调用 read)
[+] 命中系统调用 read (第 42 步)
[*] 正在扫描进程内存中的解压后 ELF ...
[+] 找到解压后 ELF 基址: 0xaaaaaaace000
[+] 解析 ELF 成功: 8 个程序头
[✓] 脱壳成功！
[✓] 输出文件: dupx.bin
```

脱壳后的文件可以使用 `readelf`、`objdump` 等工具进一步分析，或直接运行（需修复权限）。

## 运行环境

- **架构**：ARM64 (AArch64)
- **系统**：Linux（需支持 `/proc/<pid>/maps` 和 `process_vm_readv`）
- **权限**：root（或具有 `CAP_SYS_PTRACE` 能力）
- **编译器**：GCC / Clang（支持 C99 及以上）

## 代码说明

| 函数 | 功能 |
|------|------|
| `启动目标()` | fork + ptrace(TRACEME)，在 execve 处断下 |
| `ptrace_系统调用()` | PTRACE_SYSCALL 单步跟踪系统调用 |
| `ptrace_取系统调用号()` | 读取 ARM64 x8 寄存器获取 syscall 号 |
| `查找_elf_基址()` | 扫描进程 maps，通过 ELF 魔数定位基址 |
| `解析_elf()` | 读取 ELF 头 + 程序头表 |
| `导出_elf_段()` | 按 PT_LOAD 段从内存 dump 完整 ELF |

## 注意事项

- 本工具仅用于 **学习研究、逆向分析、CTF 竞赛** 等合法合规场景
- 请勿用于脱壳商业软件的版权保护程序
- UPX 版本不同可能导致解压行为差异，若脱壳失败可调整系统调用等待策略
- 当前实现假设 ELF 基址与 p_vaddr 为线性映射关系

## 开源协议

本项目基于 **GNU General Public License v3.0** 开源。

- 你可以自由使用、修改、分发本软件
- 修改后的版本必须以相同协议开源
- 必须保留原始版权声明

详见 [LICENSE](./LICENSE) 文件。


## 致谢

- [UPX](https://github.com/upx/upx) — 开源可执行文件压缩工具
- Linux Kernel — `ptrace` / `process_vm_readv` 机制
- GNU Project — GPLv3 协议

---

> ⚠️ **免责声明**：本工具仅供技术研究和安全学习使用。使用者需遵守所在地区法律法规，因不当使用造成的任何后果由使用者自行承担。
