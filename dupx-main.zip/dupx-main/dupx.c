/*
 * upx_dump.c — UPX 内存脱壳工具 (ARM64 Linux)
 * Copyright (C) 2026  难忘 <743225426@qq.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * 项目地址: https://github.com/NanWang91/dupx
 * 联系方式: 743225426@qq.com
 * 作者: 难忘
 * 协议: GPLv3
 */

//by 难忘

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <sys/uio.h>
#include <elf.h>
#include <errno.h>
#include <stdint.h>
#include <stdbool.h>
#include <fcntl.h>
#include <signal.h>



/* 附加到目标进程 */
bool ptrace_附加(pid_t pid) {
    if (ptrace(PTRACE_ATTACH, pid, NULL, NULL) == -1) {
        perror("ptrace_附加 失败");
        return false;
    }
    int 状态;
    waitpid(pid, &状态, 0);
    if (!WIFSTOPPED(状态)) return false;
    if (ptrace(PTRACE_SETOPTIONS, pid, NULL, PTRACE_O_TRACESYSGOOD) == -1) {
        perror("ptrace_设置选项 失败");
        return false;
    }
    return true;
}

/* 分离目标进程 */
void ptrace_分离(pid_t pid) {
    ptrace(PTRACE_DETACH, pid, NULL, NULL);
}

/* 从目标进程读取内存 */
bool ptrace_读内存(pid_t pid, uint64_t 地址, void *缓冲区, size_t 长度) {
    struct iovec 本地 = { .iov_base = 缓冲区, .iov_len = 长度 };
    struct iovec 远程 = { .iov_base = (void *)地址, .iov_len = 长度 };
    ssize_t n = process_vm_readv(pid, &本地, 1, &远程, 1, 0);
    return (n == (ssize_t)长度);
}

/* 单步执行到系统调用 */
bool ptrace_系统调用(pid_t pid) {
    if (ptrace(PTRACE_SYSCALL, pid, NULL, NULL) == -1) {
        perror("ptrace_系统调用 失败");
        return false;
    }
    int 状态;
    waitpid(pid, &状态, 0);
    if (!WIFSTOPPED(状态)) {
        return false;
    }
    return true;
}

/* 获取当前系统调用号 (ARM64: x8) */
long ptrace_取系统调用号(pid_t pid) {
    struct user_pt_regs 寄存器;
    struct iovec iov = { .iov_base = &寄存器, .iov_len = sizeof(寄存器) };
    if (ptrace(PTRACE_GETREGSET, pid, NT_PRSTATUS, &iov) == -1) return -1;
    return 寄存器.regs[8];
}


/* 启动目标程序并进入调试模式 */
pid_t 启动目标(const char *路径, char *const 参数[]) {
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork 失败");
        return -1;
    }
    if (pid == 0) {
        /* 子进程：允许被跟踪 */
        ptrace(PTRACE_TRACEME, 0, NULL, NULL);
        raise(SIGSTOP);   /* 让父进程有机会设置选项 */
        execv(路径, 参数);
        perror("execv 失败");
        exit(1);
    }

    /* 父进程：等待子进程在 exec 前停止 */
    int 状态;
    waitpid(pid, &状态, 0);
    if (!WIFSTOPPED(状态)) {
        fprintf(stderr, "子进程未按预期停止\n");
        return -1;
    }

    /* 设置 ptrace 选项：在 execve 时触发跟踪 */
    if (ptrace(PTRACE_SETOPTIONS, pid, NULL, 
               PTRACE_O_TRACEEXEC | PTRACE_O_TRACESYSGOOD) == -1) {
        perror("ptrace_设置选项 失败");
        return -1;
    }

    /* 继续运行，直到执行 execve */
    if (ptrace(PTRACE_CONT, pid, NULL, NULL) == -1) {
        perror("ptrace_继续 失败");
        return -1;
    }
    waitpid(pid, &状态, 0);
    if (!WIFSTOPPED(状态)) {
        fprintf(stderr, "子进程未在 execve 处停止\n");
        return -1;
    }

    /* 此时子进程已执行 execve，停在第一条指令 */
    return pid;
}



uint64_t 查找_elf_基址(pid_t pid) {
    char 路径[256];
    snprintf(路径, sizeof(路径), "/proc/%d/maps", pid);
    FILE *fp = fopen(路径, "r");
    if (!fp) {
        perror("打开 /proc/pid/maps 失败");
        return 0;
    }

    char 行[512];
    uint64_t 基址 = 0;
    while (fgets(行, sizeof(行), fp)) {
        unsigned long 起始, 结束;
        char 权限[8], 映射文件[256] = {0};
        if (sscanf(行, "%lx-%lx %7s %*s %*s %*s %255s", 
                   &起始, &结束, 权限, 映射文件) >= 3) {
            /* 优先找 r-xp 或 r--p 段 */
            if ((权限[0] == 'r') && (权限[2] == 'x' || 权限[2] == '-')) {
                unsigned char 魔数[4];
                if (ptrace_读内存(pid, 起始, 魔数, 4) && 
                    memcmp(魔数, ELFMAG, 4) == 0) {
                    /* 额外验证 ELF 头字段是否合理 */
                    Elf64_Ehdr ehdr;
                    if (ptrace_读内存(pid, 起始, &ehdr, sizeof(ehdr))) {
                        if (ehdr.e_phoff > 0 && ehdr.e_phoff < 0x10000 && 
                            ehdr.e_phnum > 0 && ehdr.e_phnum < 100) {
                            基址 = 起始;
                            break;
                        }
                    }
                }
            }
        }
    }
    fclose(fp);
    return 基址;
}



/* 从内存中读取 ELF 头和程序头表 */
bool 解析_elf(pid_t pid, uint64_t 基址, Elf64_Ehdr *ehdr, 
              Elf64_Phdr **phdrs, int *phnum) {
    if (!ptrace_读内存(pid, 基址, ehdr, sizeof(Elf64_Ehdr))) {
        fprintf(stderr, "读取 ELF 头失败\n");
        return false;
    }
    if (memcmp(ehdr->e_ident, ELFMAG, SELFMAG) != 0) {
        fprintf(stderr, "地址 0x%lx 处没有 ELF 魔数\n", 基址);
        return false;
    }
    *phnum = ehdr->e_phnum;
    if (*phnum <= 0) return false;

    size_t phdr_size = (*phnum) * sizeof(Elf64_Phdr);
    *phdrs = (Elf64_Phdr *)malloc(phdr_size);
    if (!*phdrs) return false;

    uint64_t phdr_addr = 基址 + ehdr->e_phoff;
    if (!ptrace_读内存(pid, phdr_addr, *phdrs, phdr_size)) {
        free(*phdrs);
        return false;
    }
    return true;
}

/* 按 PT_LOAD 段从内存中 dump 出完整 ELF */
bool 导出_elf_段(pid_t pid, uint64_t 基址, Elf64_Ehdr *ehdr, 
                 Elf64_Phdr *phdrs, int phnum, const char *输出文件) {
    /* 1. 遍历所有 LOAD 段，计算输出文件总大小（基于 p_memsz） */
    uint64_t 最大偏移 = 0;
    int 段数 = 0;
    printf("\n【调试信息】找到的 PT_LOAD 段：\n");
    for (int i = 0; i < phnum; i++) {
        if (phdrs[i].p_type == PT_LOAD) {
            uint64_t 结束 = phdrs[i].p_offset + phdrs[i].p_memsz;
            if (结束 > 最大偏移) 最大偏移 = 结束;
            段数++;
            printf("  LOAD[%d]: 偏移=0x%08lx  内存地址=0x%08lx  "
                   "文件大小=0x%06lx  内存大小=0x%06lx\n",
                   i, phdrs[i].p_offset, phdrs[i].p_vaddr,
                   phdrs[i].p_filesz, phdrs[i].p_memsz);
        }
    }
    if (段数 == 0) {
        fprintf(stderr, "没有找到任何 PT_LOAD 段\n");
        return false;
    }
    printf("【调试信息】输出文件总大小: 0x%08lx (%lu 字节)\n", 
           最大偏移, 最大偏移);

    /* 2. 创建输出文件，预分配大小（段间自动补零） */
    FILE *fp = fopen(输出文件, "wb");
    if (!fp) {
        perror("打开输出文件失败");
        return false;
    }
    if (最大偏移 > 0) {
        fseek(fp, 最大偏移 - 1, SEEK_SET);
        fputc(0, fp);
        fseek(fp, 0, SEEK_SET);
    }

    /* 3. 按 p_offset 写入每个 LOAD 段 */
    bool 成功 = true;
    for (int i = 0; i < phnum; i++) {
        if (phdrs[i].p_type != PT_LOAD) continue;
        if (phdrs[i].p_memsz == 0) continue;

        uint8_t *缓冲区 = (uint8_t *)malloc(phdrs[i].p_memsz);
        if (!缓冲区) {
            成功 = false;
            continue;
        }
        memset(缓冲区, 0, phdrs[i].p_memsz);

        uint64_t 内存地址 = 基址 + phdrs[i].p_vaddr;
        size_t 读取大小 = phdrs[i].p_memsz;

        if (ptrace_读内存(pid, 内存地址, 缓冲区, 读取大小)) {
            fseek(fp, phdrs[i].p_offset, SEEK_SET);
            size_t 写入大小 = fwrite(缓冲区, 1, 读取大小, fp);
            if (写入大小 != 读取大小) {
                fprintf(stderr, "警告: 段 %d 写入不完整 (写入 %zu / %zu)\n",
                        i, 写入大小, 读取大小);
                成功 = false;
            }
        } else {
            fprintf(stderr, "警告: 读取段 %d 失败 (地址 0x%lx, 大小 0x%lx)\n",
                    i, phdrs[i].p_vaddr, phdrs[i].p_memsz);
            成功 = false;
        }
        free(缓冲区);
    }

    fclose(fp);
    return 成功;
}


int main(int argc, char *argv[]) {
    /* 检查命令行参数 */
    if (argc < 2) {
        fprintf(stderr, "用法: %s <目标程序路径> [参数...]\n", argv[0]);
        fprintf(stderr, "示例: %s ./hello_packed\n", argv[0]);
      //  fprintf(stderr, "注意: 需要 root 权限执行\n");
        return 1;
    }

    char *程序路径 = argv[1];
    char *输出文件 = "dupx.bin";

    /* 解析 -o 选项 */
    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "-o") == 0 && i + 1 < argc) {
            输出文件 = argv[i + 1];
            argv[i] = NULL;
            argv[i+1] = NULL;
            break;
        }
    }

    /* 构造子进程参数列表 */
    char *子进程参数[256];
    int idx = 0;
    子进程参数[idx++] = 程序路径;
    for (int i = 2; i < argc; i++) {
        if (argv[i] == NULL) continue;
        子进程参数[idx++] = argv[i];
    }
    子进程参数[idx] = NULL;

    printf("\n========================================\n");
    printf("  UPX脱壳工具 (ARM64 Linux)\n");
    printf("========================================\n");
    printf("[+] 目标程序: %s\n", 程序路径);

    /* 启动目标进程 */
    pid_t pid = 启动目标(程序路径, 子进程参数);
    if (pid == -1) {
        fprintf(stderr, "启动目标程序失败\n");
        return 1;
    }
    printf("[+] 目标进程 PID: %d\n", pid);

    /* ---------- 核心：捕获 read 系统调用 ---------- */
    const long NR_read = 63;  /* ARM64 上 read 的系统调用号 */
    printf("[*] 等待系统调用 read (NR=%ld) ...\n", NR_read);
    printf("    (此时 UPX 正在解压，解压完成后 ld.so 会调用 read)\n");

    int 步数 = 0;
    bool 命中_read = false;
    while (!命中_read) {
        if (!ptrace_系统调用(pid)) {
            fprintf(stderr, "ptrace_系统调用 在第 %d 步失败\n", 步数);
            break;
        }
        long 调用号 = ptrace_取系统调用号(pid);

        /* 每次系统调用会触发两次停住：进入(步数偶数) 和 退出(步数奇数) */
        if (步数 % 2 == 0 && 调用号 == NR_read) {
            printf("[+] 命中系统调用 read (第 %d 步)\n", 步数);
            命中_read = true;
            break;
        }
        步数++;

        /* 安全限制 */
        if (步数 > 10000) {
            fprintf(stderr, "[-] 系统调用过多，目标可能不是 UPX 加壳程序\n");
            break;
        }
    }

    if (!命中_read) {
        fprintf(stderr, "[-] 未捕获到 read 系统调用，脱壳失败\n");
        ptrace_分离(pid);
        return 1;
    }

    /* ---------- 此时 UPX 已解压完成，开始扫描 ELF ---------- */
    printf("[*] 正在扫描进程内存中的解压后 ELF ...\n");
    uint64_t 基址 = 查找_elf_基址(pid);
    if (基址 == 0) {
        fprintf(stderr, "[-] 未找到解压后的 ELF 头\n");
        ptrace_分离(pid);
        return 1;
    }
    printf("[+] 找到解压后 ELF 基址: 0x%lx\n", 基址);

    /* 解析 ELF */
    Elf64_Ehdr ehdr;
    Elf64_Phdr *phdrs = NULL;
    int phnum = 0;
    if (!解析_elf(pid, 基址, &ehdr, &phdrs, &phnum)) {
        fprintf(stderr, "[-] 解析 ELF 失败\n");
        ptrace_分离(pid);
        return 1;
    }
    printf("[+] 解析 ELF 成功: %d 个程序头\n", phnum);

    /* 导出 ELF 段 */
    if (!导出_elf_段(pid, 基址, &ehdr, phdrs, phnum, 输出文件)) {
        fprintf(stderr, "[-] 导出 ELF 段失败\n");
        free(phdrs);
        ptrace_分离(pid);
        return 1;
    }

    /* 完成 */
    
    printf("[✓] 脱壳成功！\n");
    printf("[✓] 输出文件: %s\n", 输出文件);


    free(phdrs);
    ptrace_分离(pid);
    return 0;
}
