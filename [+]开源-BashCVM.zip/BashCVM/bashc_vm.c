/*
 * Copyright (c) [2026] 难忘 743225426@qq.com
 *
 * This file is part of [Project Name], licensed under the Custom Source
 * Code License v1.0. You may use, modify, and distribute this file,
 * including in closed-source form, provided that this copyright and
 * license header is fully retained and no commercial charge is made.
 * See the LICENSE file for full terms.
 */
 
/*
 * bashc_vm.c -- Bash bytecode VM interpreter
 * Compile: gcc -o bashc_vm bashc_vm.c bashc_lib.c -I.
 * Usage:   ./bashc_vm program.bc
 */

#include "bashc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/times.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <fnmatch.h>
#include <signal.h>
#include <time.h>
#include <dirent.h>

/* ========== forward declarations ========== */
static char *get_var(VM *vm, const char *name);
static void set_var(VM *vm, const char *name, const char *value);
static void unset_var(VM *vm, const char *name);
static int  execute_test(VM *vm, int argc, char **argv);
int  builtin_lookup(const char *name);

/* ========== string builder ========== */
#define SBUF_SIZE 65536
typedef struct { char buf[SBUF_SIZE]; int len; } SBuf;

static void sb_init(SBuf *sb) { sb->buf[0] = 0; sb->len = 0; }

static void sb_append(SBuf *sb, const char *s) {
    if (!s) return;
    int slen = strlen(s);
    if (sb->len + slen < SBUF_SIZE - 1) {
        memcpy(sb->buf + sb->len, s, slen);
        sb->len += slen;
        sb->buf[sb->len] = 0;
    }
}

static void sb_append_char(SBuf *sb, char c) {
    if (sb->len < SBUF_SIZE - 1) { sb->buf[sb->len++] = c; sb->buf[sb->len] = 0; }
}

static char *sb_detach(SBuf *sb) {
    char *s = strdup(sb->buf);
    sb->len = 0; sb->buf[0] = 0;
    return s;
}

/* ========== for-loop state (nested) ========== */
#define FOR_DEPTH_MAX 32
typedef struct { char *var_name; char **items; int item_count; int current; } ForLoopState;

static ForLoopState for_stack[FOR_DEPTH_MAX];
static int for_sp = 0;

static void for_push(const char *var_name, char **items, int item_count) {
    if (for_sp >= FOR_DEPTH_MAX) return;
    ForLoopState *fs = &for_stack[for_sp++];
    fs->var_name = strdup(var_name);
    fs->items = malloc(sizeof(char *) * item_count);
    for (int i = 0; i < item_count; i++) fs->items[i] = strdup(items[i]);
    fs->item_count = item_count;
    fs->current = -1;
}

static void for_pop(void) {
    if (for_sp <= 0) return;
    ForLoopState *fs = &for_stack[--for_sp];
    free(fs->var_name);
    for (int i = 0; i < fs->item_count; i++) free(fs->items[i]);
    free(fs->items);
    memset(fs, 0, sizeof(*fs));
}

static int for_advance(VM *vm) {
    if (for_sp <= 0) return 0;
    ForLoopState *fs = &for_stack[for_sp - 1];
    fs->current++;
    if (fs->current >= fs->item_count) return 0;
    set_var(vm, fs->var_name, fs->items[fs->current]);
    return 1;
}

static void for_begin(VM *vm, const char *var_name) {
    if (for_sp <= 0) return;
    ForLoopState *fs = &for_stack[for_sp - 1];
    if (fs->item_count > 0) { fs->current = 0; set_var(vm, var_name, fs->items[0]); }
}

/* ========== directory stack (pushd/popd/dirs) ========== */
#define DIR_STACK_MAX 64
static char *dir_stack[DIR_STACK_MAX];
static int dir_sp = 0;

static void dirs_push(const char *path) {
    if (dir_sp >= DIR_STACK_MAX) return;
    dir_stack[dir_sp++] = strdup(path);
}

static char *dirs_pop(void) {
    if (dir_sp <= 0) return NULL;
    char *p = dir_stack[--dir_sp];
    dir_stack[dir_sp] = NULL;
    return p;
}

/* ========== variable management ========== */

static char *get_var(VM *vm, const char *name) {
    if (!name) return NULL;
    /* Special variables */
    if (strcmp(name, "?") == 0) {
        char buf[32]; snprintf(buf, sizeof(buf), "%d", vm->exit_code);
        char *r = malloc(32); strcpy(r, buf); return r;
    }
    if (strcmp(name, "$") == 0) {
        char buf[32]; snprintf(buf, sizeof(buf), "%d", (int)getpid());
        char *r = malloc(32); strcpy(r, buf); return r;
    }
    if (strcmp(name, "#") == 0) {
        char buf[32]; snprintf(buf, sizeof(buf), "%d", vm->positional_count);
        char *r = malloc(32); strcpy(r, buf); return r;
    }
    if (strcmp(name, "0") == 0) {
        return strdup(vm->script_name ? vm->script_name : "bashc");
    }
    /* Numeric positional: $1, $2, ... */
    if (isdigit(name[0]) && name[1] == 0) {
        int n = name[0] - '0';
        if (n > 0 && n <= vm->positional_count) {
            return strdup(vm->positional[n - 1]);
        }
        return strdup("");
    }
    if (isdigit(name[0]) && name[1] >= '0' && name[1] <= '9' && name[2] == 0) {
        int n = (name[0] - '0') * 10 + (name[1] - '0');
        if (n > 0 && n <= vm->positional_count) {
            return strdup(vm->positional[n - 1]);
        }
        return strdup("");
    }
    if (strcmp(name, "@") == 0 || strcmp(name, "*") == 0) {
        SBuf sb; sb_init(&sb);
        for (int i = 0; i < vm->positional_count; i++) {
            if (i > 0 && strcmp(name, "@") == 0) sb_append_char(&sb, ' ');
            else if (i > 0) sb_append_char(&sb, ' ');
            sb_append(&sb, vm->positional[i]);
        }
        return sb_detach(&sb);
    }
    for (int i = 0; i < vm->var_count; i++)
        if (strcmp(vm->vars[i].name, name) == 0) return vm->vars[i].value;
    return getenv(name);
}

static void set_var(VM *vm, const char *name, const char *value) {
    if (!name) return;
    if (strcmp(name, "?") == 0 || strcmp(name, "$") == 0 ||
        strcmp(name, "#") == 0 || strcmp(name, "0") == 0) {
        /* Special variables are read-only - silently ignore */
        return;
    }
    if (isdigit(name[0])) {
        /* Positional parameters are read-only */
        return;
    }
    for (int i = 0; i < vm->var_count; i++) {
        if (strcmp(vm->vars[i].name, name) == 0) {
            char *nv = value ? strdup(value) : strdup("");
            /* 注意: 如果 value 与 vars[i].value 是同一指针 (来自 OP_STORE 等),
             * 必须先 strdup 再 free, 否则 use-after-free */
            free(vm->vars[i].value);
            vm->vars[i].value = nv;
            return;
        }
    }
    if (vm->var_count >= VM_VARS_MAX) return;
    vm->vars[vm->var_count].name = strdup(name);
    vm->vars[vm->var_count].value = value ? strdup(value) : strdup("");
    vm->var_count++;
}

static void unset_var(VM *vm, const char *name) {
    if (!name) return;
    for (int i = 0; i < vm->var_count; i++) {
        if (strcmp(vm->vars[i].name, name) == 0) {
            free(vm->vars[i].name); free(vm->vars[i].value);
            vm->vars[i] = vm->vars[vm->var_count - 1]; vm->var_count--;
            unsetenv(name);
            return;
        }
    }
    unsetenv(name);
}

static void export_var(VM *vm, const char *name) {
    if (!name) return;
    char *val = get_var(vm, name);
    if (val) setenv(name, val, 1);
}

/* ========== array management ========== */

static int array_get_index(VM *vm, const char *name) {
    for (int i = 0; i < vm->array_count; i++)
        if (strcmp(vm->arrays[i].name, name) == 0) return i;
    if (vm->array_count >= MAX_ARRAYS) return -1;
    vm->arrays[vm->array_count].name = strdup(name);
    vm->arrays[vm->array_count].count = 0;
    return vm->array_count++;
}

static void array_set(VM *vm, const char *name, int idx, const char *value) {
    int ai = array_get_index(vm, name);
    if (ai < 0) return;
    if (idx < 0 || idx >= MAX_ARRAY_SIZE) return;
    if (vm->arrays[ai].values[idx]) free(vm->arrays[ai].values[idx]);
    vm->arrays[ai].values[idx] = strdup(value ? value : "");
    if (idx >= vm->arrays[ai].count) vm->arrays[ai].count = idx + 1;
}

static char *array_get(VM *vm, const char *name, int idx) {
    int ai = array_get_index(vm, name);
    if (ai < 0) return NULL;
    if (idx < 0 || idx >= vm->arrays[ai].count) return NULL;
    return vm->arrays[ai].values[idx];
}

/* ========== alias management ========== */

static char *get_alias(VM *vm, const char *name) {
    if (!name) return NULL;
    for (int i = 0; i < vm->alias_count; i++)
        if (strcmp(vm->aliases[i].name, name) == 0) return vm->aliases[i].value;
    return NULL;
}

static void set_alias(VM *vm, const char *name, const char *value) {
    if (!name) return;
    for (int i = 0; i < vm->alias_count; i++) {
        if (strcmp(vm->aliases[i].name, name) == 0) {
            free(vm->aliases[i].value);
            vm->aliases[i].value = value ? strdup(value) : strdup("");
            return;
        }
    }
    if (vm->alias_count >= 256) return;
    vm->aliases[vm->alias_count].name = strdup(name);
    vm->aliases[vm->alias_count].value = value ? strdup(value) : strdup("");
    vm->alias_count++;
}

static void unset_alias(VM *vm, const char *name) {
    if (!name) return;
    for (int i = 0; i < vm->alias_count; i++) {
        if (strcmp(vm->aliases[i].name, name) == 0) {
            free(vm->aliases[i].name); free(vm->aliases[i].value);
            vm->aliases[i] = vm->aliases[vm->alias_count - 1]; vm->alias_count--;
            return;
        }
    }
}

/* ========== stack operations ========== */

static void push_int(VM *vm, int val) {
    if (vm->sp >= VM_STACK_SIZE) return;
    vm->stack[vm->sp].type = 0; vm->stack[vm->sp].ival = val;
    vm->stack[vm->sp].sval = NULL; vm->sp++;
}

static void push_str(VM *vm, const char *s) {
    if (vm->sp >= VM_STACK_SIZE) return;
    vm->stack[vm->sp].type = 1; vm->stack[vm->sp].ival = 0;
    vm->stack[vm->sp].sval = s ? strdup(s) : strdup(""); vm->sp++;
}

static VMValue pop(VM *vm) {
    VMValue v = {0, 0, NULL};
    if (vm->sp <= 0) return v;
    vm->sp--; v = vm->stack[vm->sp];
    vm->stack[vm->sp].type = 0; vm->stack[vm->sp].ival = 0; vm->stack[vm->sp].sval = NULL;
    return v;
}

static void free_value(VMValue *v) {
    if (v->type == 1 && v->sval) { free(v->sval); v->sval = NULL; }
}

static int pop_int(VM *vm) {
    VMValue v = pop(vm);
    int result = (v.type == 0) ? v.ival : (v.sval ? atoi(v.sval) : 0);
    free_value(&v); return result;
}

static char *pop_str(VM *vm) {
    VMValue v = pop(vm);
    if (v.type == 1 && v.sval) return v.sval;
    if (v.type == 0) { char buf[32]; snprintf(buf, sizeof(buf), "%d", v.ival); return strdup(buf); }
    return strdup("");
}

static VMValue *peek(VM *vm) {
    return (vm->sp > 0) ? &vm->stack[vm->sp - 1] : NULL;
}

/* ========== variable expansion ========== */

static const char *parse_var_name(const char *p, char *out, int out_size) {
    int i = 0;
    if (*p == '{') {
        p++;
        while (*p && *p != '}' && i < out_size - 1) out[i++] = *p++;
        if (*p == '}') p++;
    } else {
        while (*p && (isalnum(*p) || *p == '_') && i < out_size - 1) out[i++] = *p++;
    }
    out[i] = 0;
    return p;
}

static char *expand_vars(VM *vm, const char *str) {
    if (!str) return strdup("");
    SBuf sb; sb_init(&sb);
    const char *p = str;
    while (*p) {
        if (*p == '\\' && *(p + 1)) { p++; sb_append_char(&sb, *p++); continue; }
        if (*p == '$' && *(p+1) == '*') { sb_append(&sb, vm->positional_count > 0 && vm->positional[0] ? vm->positional[0] : ""); p += 2; continue; }
        if (*p == '$' && *(p+1) == '@') { sb_append(&sb, vm->positional_count > 0 && vm->positional[0] ? vm->positional[0] : ""); p += 2; continue; }
        if (*p == '$' && *(p+1) == '#') { char buf[16]; snprintf(buf, sizeof(buf), "%d", vm->positional_count); sb_append(&sb, buf); p += 2; continue; }
        if (*p == '$' && *(p+1) == '?') { char buf[16]; snprintf(buf, sizeof(buf), "%d", vm->exit_code); sb_append(&sb, buf); p += 2; continue; }
        if (*p == '$' && *(p+1) == '$') { char buf[16]; snprintf(buf, sizeof(buf), "%d", (int)getpid()); sb_append(&sb, buf); p += 2; continue; }
        if (*p == '$' && *(p+1) == '!') { sb_append(&sb, ""); p += 2; continue; }
        if (*p == '$' && (isdigit(*(p+1)) || *(p+1) == '0')) {
            /* $0, $1, $2, ... */
            int n = *(p+1) - '0'; p += 2;
            if (n == 0) { sb_append(&sb, vm->script_name ? vm->script_name : "sh"); }
            else if (n >= 1 && n <= vm->positional_count && vm->positional[n-1]) {
                sb_append(&sb, vm->positional[n-1]);
            }
            continue;
        }
        if (*p == '$' && (isalpha(*(p+1)) || *(p+1) == '_' || *(p+1) == '{')) {
            p++; char vname[256]; p = parse_var_name(p, vname, sizeof(vname));
            char *val = get_var(vm, vname);
            if (val) sb_append(&sb, val);
        } else { sb_append_char(&sb, *p++); }
    }
    return sb_detach(&sb);
}

/* ========== arithmetic expression evaluator ========== */

static const char *arith_skip(const char *p) { while (*p && isspace(*p)) p++; return p; }

static int arith_primary(VM *vm, const char **pp) {
    const char *p = arith_skip(*pp); int val = 0;
    if (*p == '(') { p++; val = arith_primary(vm, &p); p = arith_skip(p); if (*p == ')') p++; *pp = p; return val; }
    if (*p == '-' || *p == '+') { int sign = (*p == '-') ? -1 : 1; p++; val = sign * arith_primary(vm, &p); *pp = p; return val; }
    if (*p == '~') { p++; val = ~arith_primary(vm, &p); *pp = p; return val; }
    if (*p == '!') { p++; val = !arith_primary(vm, &p); *pp = p; return val; }
    if (*p == '$' && isdigit((unsigned char)*(p+1))) {
        /* $1 $2 ... 位置参数 */
        p++;
        int n = *p - '0'; p++;
        const char *valp = NULL;
        if (n == 0) valp = vm->script_name;
        else if (n >= 1 && n <= vm->positional_count) valp = vm->positional[n-1];
        int current = valp ? atoi(valp) : 0;
        p = arith_skip(p);
        if (*p == '+' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            *pp = p; return current + rhs;
        }
        if (*p == '-' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            *pp = p; return current - rhs;
        }
        if (*p == '*' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            *pp = p; return current * rhs;
        }
        if (*p == '/' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            *pp = p; return rhs ? current / rhs : 0;
        }
        if (*p == '%' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            *pp = p; return rhs ? current % rhs : 0;
        }
        *pp = p; return current;
    }
    if (*p == '$' || isalpha(*p) || *p == '_') {
        if (*p == '$') p++;
        char vname[256]; int i = 0;
        while (*p && (isalnum(*p) || *p == '_') && i < 255) vname[i++] = *p++;
        vname[i] = 0; char *v = get_var(vm, vname);
        int current = v ? atoi(v) : 0;
        p = arith_skip(p);
        /* Handle assignment operators: +=, -=, *=, /=, %= */
        if (*p == '+' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            char buf[32]; snprintf(buf, sizeof(buf), "%d", current + rhs);
            set_var(vm, vname, buf); *pp = p; return current + rhs;
        }
        if (*p == '-' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            char buf[32]; snprintf(buf, sizeof(buf), "%d", current - rhs);
            set_var(vm, vname, buf); *pp = p; return current - rhs;
        }
        if (*p == '*' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            char buf[32]; snprintf(buf, sizeof(buf), "%d", current * rhs);
            set_var(vm, vname, buf); *pp = p; return current * rhs;
        }
        if (*p == '/' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            char buf[32]; snprintf(buf, sizeof(buf), "%d", rhs ? current / rhs : 0);
            set_var(vm, vname, buf); *pp = p; return rhs ? current / rhs : 0;
        }
        if (*p == '%' && *(p+1) == '=') {
            p += 2; int rhs = arith_primary(vm, &p);
            char buf[32]; snprintf(buf, sizeof(buf), "%d", rhs ? current % rhs : 0);
            set_var(vm, vname, buf); *pp = p; return rhs ? current % rhs : 0;
        }
        *pp = p; return current;
    }
    if (isdigit(*p)) { while (*p && isdigit(*p)) { val = val * 10 + (*p - '0'); p++; } *pp = p; return val; }
    *pp = p; return 0;
}

static int arith_bitand(VM *vm, const char **pp) {
    int left = arith_primary(vm, pp); const char *p;
    while (1) { p = arith_skip(*pp); if (*p != '&' || *(p+1) == '&') break; p++; left &= arith_primary(vm, &p); *pp = p; }
    return left;
}

static int arith_bitxor(VM *vm, const char **pp) {
    int left = arith_bitand(vm, pp); const char *p;
    while (1) { p = arith_skip(*pp); if (*p != '^') break; p++; left ^= arith_bitand(vm, &p); *pp = p; }
    return left;
}

static int arith_bitor(VM *vm, const char **pp) {
    int left = arith_bitxor(vm, pp); const char *p;
    while (1) { p = arith_skip(*pp); if (*p != '|' || *(p+1) == '|') break; p++; left |= arith_bitxor(vm, &p); *pp = p; }
    return left;
}

static int arith_term(VM *vm, const char **pp) {
    int left = arith_bitor(vm, pp); const char *p;
    while (1) {
        p = arith_skip(*pp);
        if (*p != '*' && *p != '/' && *p != '%') break;
        char op = *p++; int right = arith_bitor(vm, &p);
        if (op == '*') left *= right;
        else if (op == '/') left = right ? left / right : 0;
        else left = right ? left % right : 0;
        *pp = p;
    }
    return left;
}

static int arith_shift(VM *vm, const char **pp) {
    int left = arith_term(vm, pp); const char *p;
    while (1) {
        p = arith_skip(*pp);
        if (*p == '<' && *(p+1) == '<') { p += 2; left <<= arith_term(vm, &p); *pp = p; }
        else if (*p == '>' && *(p+1) == '>') { p += 2; left >>= arith_term(vm, &p); *pp = p; }
        else break;
    }
    return left;
}

static int arith_expr(VM *vm, const char **pp) {
    int left = arith_shift(vm, pp); const char *p;
    while (1) {
        p = arith_skip(*pp);
        if (*p != '+' && *p != '-') break;
        char op = *p++; int right = arith_shift(vm, &p);
        left = (op == '+') ? left + right : left - right;
        *pp = p;
    }
    return left;
}

static int arith_compare(VM *vm, const char **pp) {
    int left = arith_expr(vm, pp); const char *p = arith_skip(*pp);
    if (*p == '<' && *(p+1) == '=') { p += 2; left = left <= arith_expr(vm, &p); *pp = p; return left; }
    if (*p == '>' && *(p+1) == '=') { p += 2; left = left >= arith_expr(vm, &p); *pp = p; return left; }
    if (*p == '=' && *(p+1) == '=') { p += 2; left = left == arith_expr(vm, &p); *pp = p; return left; }
    if (*p == '!' && *(p+1) == '=') { p += 2; left = left != arith_expr(vm, &p); *pp = p; return left; }
    if (*p == '<') { p++; left = left < arith_expr(vm, &p); *pp = p; return left; }
    if (*p == '>') { p++; left = left > arith_expr(vm, &p); *pp = p; return left; }
    *pp = p; return left;
}

static int eval_arithmetic(VM *vm, const char *expr) {
    if (!expr || !*expr) return 0;
    const char *p = expr; return arith_compare(vm, &p);
}

/* ========== command substitution $(cmd) ========== */

static char *command_substitution(VM *vm, const char *cmd) {
    /* 让子 VM 同时执行父 VM 的代码+函数表+变量, 然后执行 cmd 捕获 stdout */
    const char *parent_bc = getenv("BASHC_PARENT_BC");
    if (!parent_bc) {
        /* 退化: 写到临时文件让 sh 跑 */
        int pipefd[2];
        if (pipe(pipefd) == -1) return strdup("");
        pid_t pid = fork();
        if (pid == 0) {
            close(pipefd[0]); dup2(pipefd[1], STDOUT_FILENO); close(pipefd[1]);
            execlp("sh", "sh", "-c", cmd, (char *)NULL);
            _exit(127);
        }
        close(pipefd[1]);
        SBuf sb; sb_init(&sb); char buf[256]; ssize_t n;
        while ((n = read(pipefd[0], buf, sizeof(buf) - 1)) > 0) { buf[n] = 0; sb_append(&sb, buf); }
        close(pipefd[0]);
        int status; waitpid(pid, &status, 0);
        char *result = sb_detach(&sb);
        int rlen = strlen(result);
        while (rlen > 0 && result[rlen - 1] == '\n') result[--rlen] = 0;
        return result;
    }
    /* 编译 cmd 为临时 .bc */
    char tmpsh[256]; snprintf(tmpsh, sizeof(tmpsh), "/tmp/bashc_cmd_%d.sh", (int)getpid());
    char tmpbc[256]; snprintf(tmpbc, sizeof(tmpbc), "/tmp/bashc_cmd_%d.bc", (int)getpid());
    FILE *fp = fopen(tmpsh, "w");
    if (!fp) return strdup("");
    fprintf(fp, "%s\n", cmd);
    fclose(fp);
    char cmdline[1024];
    snprintf(cmdline, sizeof(cmdline),
             "%s/bashc_compile %s %s >/dev/null 2>&1",
             getenv("BASHC_BIN") ? getenv("BASHC_BIN") : ".", tmpsh, tmpbc);
    int rc = system(cmdline);
    if (rc != 0) { unlink(tmpsh); unlink(tmpbc); return strdup(""); }
    /* 合并: 父 .bc 字符串表+函数表 + cmd .bc 字符串表+函数表 + cmd code (重映射)
     * 父 code 被一个 HALT 替换 (这样子 VM 不重跑父顶层代码, 但能调用父函数) */
    char mergebc[256]; snprintf(mergebc, sizeof(mergebc), "/tmp/bashc_merge_%d.bc", (int)getpid());
    FILE *fpr = fopen(parent_bc, "rb");
    FILE *fpc = fopen(tmpbc, "rb");
    FILE *fpw = fopen(mergebc, "wb");
    if (!fpr || !fpc || !fpw) { if(fpr)fclose(fpr); if(fpc)fclose(fpc); if(fpw)fclose(fpw); unlink(tmpsh); unlink(tmpbc); return strdup(""); }
    /* 读 parent header */
    uint32_t magic, ver, pstr_n;
    fread(&magic, 4, 1, fpr);
    fread(&ver, 4, 1, fpr);
    fread(&pstr_n, 4, 1, fpr);
    /* 写 magic+ver+(父+cmd)字符串表总数 */
    fseek(fpc, 8, SEEK_SET);
    uint32_t cstr_n; fread(&cstr_n, 4, 1, fpc);
    uint32_t total_str = pstr_n + cstr_n;
    fwrite(&magic, 4, 1, fpw);
    fwrite(&ver, 4, 1, fpw);
    fwrite(&total_str, 4, 1, fpw);
    /* 复制父 str 表条目 */
    fseek(fpr, 12, SEEK_SET);
    for (uint32_t i = 0; i < pstr_n; i++) {
        uint32_t len; fread(&len, 4, 1, fpr);
        char *b = malloc(len + 1); if (len) fread(b, 1, len, fpr); b[len] = 0;
        fwrite(&len, 4, 1, fpw); fwrite(b, 1, len, fpw); free(b);
    }
    /* 复制 cmd str 表条目 (原文) */
    fseek(fpc, 12, SEEK_SET);
    for (uint32_t i = 0; i < cstr_n; i++) {
        uint32_t len; fread(&len, 4, 1, fpc);
        char *b = malloc(len + 1); if (len) fread(b, 1, len, fpc); b[len] = 0;
        fwrite(&len, 4, 1, fpw); fwrite(b, 1, len, fpw); free(b);
    }
    /* 读父 func 表 (count + entries) */
    uint32_t pfc; fread(&pfc, 4, 1, fpr);
    /* 跳过父 func entries (每个 12 字节) 才能读到 code size */
    for (uint32_t i = 0; i < pfc; i++) {
        int32_t tmp;
        fread(&tmp, 4, 1, fpr);
        fread(&tmp, 4, 1, fpr);
        fread(&tmp, 4, 1, fpr);
    }
    /* 父 func 表中 name_idx 是父 str 表索引, addr 是父 code 内偏移 (新 code 中改成 0=HALT 位置)
     * 父 func 表保留: name_idx 不变, addr = 0 (指向 HALT 位置) — 不, 函数体内地址需要保留
     * 因为父 code 被整体丢弃, 函数体在父 code 内不可达
     * 解决: 把父 code 也保留, 但仅保留函数体部分
     * 简化: 父 code 全部保留, 但在父 code 末尾追加 cmd code, 父 code 不会自动跑因为有 HALT
     * 但是 HALT 在父 code 末尾! 所以父 code 还会跑
     * 解决: 把父 code 末尾的 HALT 替换为 NOP, 然后 cmd code 追加
     *         在父 code 头部加 JMP 到 cmd code
     * 简单方案: 父 code 头部插入 JMP 到 父_code_size + cmd_code_size (跳过父 code 直接到 cmd)
     *         但父 code 中函数地址都是基于父 code 内偏移, 函数定义位置会被跳过, 但函数内代码段在中间
     * 最简单方案: 让父 code 跑但不要副作用, 把"父 code 顶层"全部 NOP
     * 但顶层 vs 函数体无法从字节码区分
     * 终极方案: 父 code 完全保留, 但 PC 一开始就跳到 HALT
     *         这样父 code 加载到子 VM 后, 跑完 JMP 到 HALT 立即停止
     * 函数体内 addr 仍正确指向函数体位置
     */
    /* 读父 code size - 之前已跳过父 func entries */
    uint32_t pcode_n; fread(&pcode_n, 4, 1, fpr);
    uint8_t *pcode = malloc(pcode_n); fread(pcode, 1, pcode_n, fpr);
    fclose(fpr);  /* 父文件已读完 */
    /* 父 code 末尾通常是 HALT(0x01). 改成 JMP 到 cmd code 开始位置 */
    /* 新 code: [JMP 5] 父 code 末尾 HALT 改成 NOP [cmd code (重映射) + HALT] */
    /* 由于修改后字节码指令数可能变化, 用一个简单方法:
     * 父 code 末尾 HALT 改成 NOP
     * 在父 code 开头插入 JMP pcode_n (跳过父 code, 直接到 cmd code)
     * 但插入 5 字节会让所有跳转/函数地址失效 (偏移 +5)
     *
     * 更简单: 父 code 不变, 整体作为子 VM 的 code, 但把 PC 改为 pcode_n
     *        并把父 code 末尾 HALT 替换为 NOP
     *        然后追加 cmd code + HALT
     * 子 VM 加载时设 PC = pcode_n (跳过父 code, 直接到 cmd code) */
    /* 这个 PC 设置需要在子 VM 内做 — 但 vm_init 设 PC=0
     * 解决: 让合并的 .bc 在父 code 开头强制跳到 cmd code 位置
     * 用 JMP 指令, 5 字节 (op + 4字节 addr)
     * 父 code 头部 5 字节改写: JMP pcode_n (跳过父 code)
     * 但父 code 头 5 字节可能是单字节 op + 0~4 operand, 替换为 JMP 会破坏原指令
     * 父 code 至少 6 字节 (HALT + 上面一些) — 我用追加方式:
     *   在父 code 头部插入 5 字节 JMP 指令, 父 code 长度 +5
     *   父 code 内部所有跳转地址 +5
     *   父 func 表所有 addr +5
     *   cmd code 内跳转地址 + pcode_n + 5
     *   cmd func 表所有 addr + pcode_n + 5
     */
    /* 父 code 末尾 HALT 改为 NOP */
     if (pcode_n > 0) pcode[pcode_n - 1] = 0x00; /* NOP */
     /* 父 code 头部 5 字节改为 JMP pcode_n+5 (跳过父 code 到 cmd code)
      * 同时把父 code 内部所有跳转地址 +5 */
     if (pcode_n >= 5) {
         int q = 0;
         while (q < (int)pcode_n) {
             uint8_t op = pcode[q];
             int opnd = 0;
             switch (op) {
                 case 0x10: case 0x11: case 0x20: case 0x21: case 0x22:
                 case 0x26: case 0x27: case 0x40: case 0x41: case 0x46:
                 case 0x42: case 0x43: case 0x44: case 0x45: case 0x47:
                 case 0x50: case 0x51: case 0x52: case 0x53: case 0x55:
                 case 0x56: case 0x66: case 0x70: case 0x71: case 0x73:
                 case 0x74: case 0x82: case 0x83: case 0x84: case 0x85:
                 case 0x90: case 0x91: case 0x92: case 0xA3: case 0xA4:
                 case 0xA5: case 0xB2:
                     opnd = 1; break;
                 case 0x24: opnd = 2; break;
                 default: opnd = 0; break;
             }
             if (opnd == 1) {
                 /* 跳转指令 +5 */
                 if (op == 0x50 || op == 0x51 || op == 0x52 || op == 0x53 || op == 0x71 || op == 0x73) {
                     int32_t val; memcpy(&val, pcode + q + 1, 4);
                     val += 5;
                     memcpy(pcode + q + 1, &val, 4);
                 }
                 q += 5;
             } else if (opnd == 2) { q += 9; } else { q += 1; }
         }
     }
    /* 读 cmd func 表 (count + entries) */
    uint32_t cfc; fread(&cfc, 4, 1, fpc);
    /* 读 cmd code size + code */
    uint32_t ccode_n; fread(&ccode_n, 4, 1, fpc);
    uint8_t *ccode = malloc(ccode_n); fread(ccode, 1, ccode_n, fpc);
    fclose(fpc);
    /* 父 func 表 entries: 把 addr 加 5 (因为我们在父 code 头部插入 5 字节 JMP) */
    /* 我们需要父 func entries — 重新打开 parent_bc 读 func entries */
    fpr = fopen(parent_bc, "rb");
    fseek(fpr, 12, SEEK_SET);
    for (uint32_t i = 0; i < pstr_n; i++) { uint32_t len; fread(&len, 4, 1, fpr); fseek(fpr, len, SEEK_CUR); }
    /* 现在在 func_count 位置 */
    uint32_t pfc2; fread(&pfc2, 4, 1, fpr);
    /* 写总 func 数 = 父 + cmd */
    uint32_t total_func = pfc2 + cfc;
    fwrite(&total_func, 4, 1, fpw);
    /* 写父 func entries (addr + 5) */
    for (uint32_t i = 0; i < pfc2; i++) {
        int32_t ni, ad, ac; fread(&ni, 4, 1, fpr); fread(&ad, 4, 1, fpr); fread(&ac, 4, 1, fpr);
        ad += 5;
        fwrite(&ni, 4, 1, fpw); fwrite(&ad, 4, 1, fpw); fwrite(&ac, 4, 1, fpw);
    }
    fclose(fpr);
    /* 重映射 cmd code: 字符串引用 +pstr_n, 跳转地址 +(pcode_n+5) */
    uint8_t *new_code = malloc(ccode_n);
    int j = 0;
    while (j < (int)ccode_n) {
        uint8_t op = ccode[j];
        new_code[j] = op;
        int opnd = 0;
        switch (op) {
            case 0x10: case 0x11: case 0x20: case 0x21: case 0x22:
            case 0x26: case 0x27: case 0x40: case 0x41: case 0x46:
            case 0x42: case 0x43: case 0x44: case 0x45: case 0x47:
            case 0x50: case 0x51: case 0x52: case 0x53: case 0x55:
            case 0x56: case 0x66: case 0x70: case 0x71: case 0x73:
            case 0x74: case 0x82: case 0x83: case 0x84: case 0x85:
            case 0x90: case 0x91: case 0x92: case 0xA3: case 0xA4:
            case 0xA5: case 0xB2:
                opnd = 1; break;
            case 0x24: opnd = 2; break;
            default: opnd = 0; break;
        }
        if (opnd == 1) {
             int32_t val; memcpy(&val, ccode + j + 1, 4);
             if (op == 0x10 || op == 0x20 || op == 0x21 || op == 0x22 || op == 0x45 || op == 0x66 || op == 0x82 || op == 0x84 || op == 0x85)
                 val += pstr_n;
             /* FUNC_CALL(0x83) 编码: 高16位 arg_count + 低16位 name_idx, 只 remap 低16位 */
             if (op == 0x83) {
                 int argc = (val >> 16) & 0xFFFF;
                 int nidx = val & 0xFFFF;
                 nidx += pstr_n;
                 val = (argc << 16) | nidx;
             }
             if (op == 0x50 || op == 0x51 || op == 0x52 || op == 0x53 || op == 0x71 || op == 0x73)
                 val += (pcode_n + 5);
             memcpy(new_code + j + 1, &val, 4);
             j += 5;
         } else if (opnd == 2) {
            int32_t v1, v2; memcpy(&v1, ccode + j + 1, 4); memcpy(&v2, ccode + j + 5, 4);
            if (op == 0x24) { v1 += pstr_n; v2 += pstr_n; }
            memcpy(new_code + j + 1, &v1, 4); memcpy(new_code + j + 5, &v2, 4);
            j += 9;
        } else { j += 1; }
    }
    /* 写 cmd func entries (name_idx +pstr_n, addr +(pcode_n+5), argc 不变) */
    fpc = fopen(tmpbc, "rb");
    fseek(fpc, 12, SEEK_SET);
    for (uint32_t i = 0; i < cstr_n; i++) { uint32_t len; fread(&len, 4, 1, fpc); fseek(fpc, len, SEEK_CUR); }
    uint32_t cfc2; fread(&cfc2, 4, 1, fpc);
    for (uint32_t i = 0; i < cfc2; i++) {
        int32_t ni, ad, ac; fread(&ni, 4, 1, fpc); fread(&ad, 4, 1, fpc); fread(&ac, 4, 1, fpc);
        ni += pstr_n; ad += (pcode_n + 5);
        fwrite(&ni, 4, 1, fpw); fwrite(&ad, 4, 1, fpw); fwrite(&ac, 4, 1, fpw);
    }
    fclose(fpc);
    /* 写 code: [JMP pcode_n+5] [父 code (5..pcode_n-1)] [cmd code 重映射] [HALT] */
     uint32_t new_code_n = 5 + (pcode_n - 5) + ccode_n + 1;
     fwrite(&new_code_n, 4, 1, fpw);
     /* JMP op + addr (跳过父 code 全部) */
     uint8_t jmp_op = 0x50; fwrite(&jmp_op, 1, 1, fpw);
     int32_t jmp_addr = 5 + (pcode_n - 5); fwrite(&jmp_addr, 4, 1, fpw);
     /* 父 code 5..pcode_n-1 (跳过前 5 字节) */
     fwrite(pcode + 5, 1, pcode_n - 5, fpw);
     /* cmd code (重映射) */
     fwrite(new_code, 1, ccode_n, fpw);
     /* HALT */
     uint8_t halt = 0x01; fwrite(&halt, 1, 1, fpw);
     fclose(fpw);
     free(pcode); free(ccode); free(new_code);
    /* fork+exec bashc_vm 跑 mergebc */
    int pipefd[2];
    if (pipe(pipefd) == -1) { unlink(tmpsh); unlink(tmpbc); unlink(mergebc); return strdup(""); }
    pid_t pid = fork();
    if (pid == 0) {
        close(pipefd[0]);
        dup2(pipefd[1], STDOUT_FILENO);
        close(pipefd[1]);
        char binpath[1024];
        snprintf(binpath, sizeof(binpath), "%s/bashc_vm",
                 getenv("BASHC_BIN") ? getenv("BASHC_BIN") : ".");
        execl(binpath, "bashc_vm", mergebc, (char *)NULL);
        _exit(127);
    }
    close(pipefd[1]);
    SBuf sb; sb_init(&sb); char buf[256]; ssize_t n;
    while ((n = read(pipefd[0], buf, sizeof(buf) - 1)) > 0) { buf[n] = 0; sb_append(&sb, buf); }
    close(pipefd[0]);
    int status; waitpid(pid, &status, 0);
    unlink(tmpsh); unlink(tmpbc); unlink(mergebc);
    char *result = sb_detach(&sb);
    int rlen = strlen(result);
    while (rlen > 0 && result[rlen - 1] == '\n') result[--rlen] = 0;
    return result;
}

/* ========== full expansion: $VAR, ${VAR}, $((expr)), $(cmd) ========== */

static char *expand_all(VM *vm, const char *str) {
    if (!str) return strdup("");
    /* Tilde expansion: at start of word, ~ or ~/path or ~user */
    if (str[0] == '~' && (str[1] == '/' || str[1] == 0 || str[1] == ' ')) {
        const char *home = getenv("HOME");
        if (!home) home = "/";
        SBuf tsb; sb_init(&tsb); sb_append(&tsb, home); sb_append(&tsb, str + 1);
        char *tilded = sb_detach(&tsb);
        char *result = expand_all(vm, tilded);
        free(tilded);
        return result;
    }
    SBuf sb; sb_init(&sb); const char *p = str;
    while (*p) {
        /* Keep \X escape sequences for echo -e to interpret */
        if (*p == '\\' && *(p + 1)) { sb_append_char(&sb, *p++); sb_append_char(&sb, *p++); continue; }
        if (*p == '$') {
            p++;
            if (*p == '(' && *(p+1) == '(') {
                p += 2; const char *start = p; int depth = 1;
                while (*p && depth > 0) { if (*p == '(') depth++; else if (*p == ')') depth--; if (depth > 0) p++; }
                int len = p - start; char *expr = strndup(start, len);
                if (*p == ')') p++;
                if (*p == ')') p++;
                int result = eval_arithmetic(vm, expr); free(expr);
                char numbuf[32]; snprintf(numbuf, sizeof(numbuf), "%d", result); sb_append(&sb, numbuf);
            } else if (*p == '(') {
                p++; const char *start = p; int depth = 1;
                while (*p && depth > 0) { if (*p == '(') depth++; else if (*p == ')') depth--; if (depth > 0) p++; }
                int len = p - start; char *cmd = strndup(start, len);
                if (*p == ')') p++;
                char *result = command_substitution(vm, cmd); free(cmd);
                sb_append(&sb, result); free(result);
            } else if (*p == '{') {
                p++;
                /* Check for ${#VAR} (length) */
                if (*p == '#') {
                    p++;
                    char vname[256]; int vi = 0;
                    while (*p && *p != '}' && vi < 255) vname[vi++] = *p++;
                    vname[vi] = 0;
                    if (*p == '}') p++;
                    char *val = get_var(vm, vname);
                    char buf[32]; snprintf(buf, sizeof(buf), "%zu", val ? strlen(val) : 0);
                    sb_append(&sb, buf);
                    continue;
                }
                char vname[256]; int vi = 0;
                while (*p && *p != '/' && *p != '}' && *p != ':' && vi < 255) vname[vi++] = *p++;
                vname[vi] = 0;
                char *val = get_var(vm, vname);
                if (!val) val = "";

                /* ${VAR:-default} - default if unset or empty */
                if (*p == ':' && *(p+1) == '-') {
                    p += 2;
                    char def[256]; int di = 0;
                    while (*p && *p != '}' && di < 255) def[di++] = *p++;
                    def[di] = 0;
                    if (*p == '}') p++;
                    if (val[0] == 0) sb_append(&sb, def);
                    else sb_append(&sb, val);
                    continue;
                }

                /* ${VAR:=default} - assign default if unset or empty */
                if (*p == ':' && *(p+1) == '=') {
                    p += 2;
                    char def[256]; int di = 0;
                    while (*p && *p != '}' && di < 255) def[di++] = *p++;
                    def[di] = 0;
                    if (*p == '}') p++;
                    if (val[0] == 0) {
                        set_var(vm, vname, def);
                        sb_append(&sb, def);
                    } else {
                        sb_append(&sb, val);
                    }
                    continue;
                }

                /* ${VAR:+value} - value if set and non-empty, else empty */
                if (*p == ':' && *(p+1) == '+') {
                    p += 2;
                    char alt[256]; int ai = 0;
                    while (*p && *p != '}' && ai < 255) alt[ai++] = *p++;
                    alt[ai] = 0;
                    if (*p == '}') p++;
                    if (val[0] != 0) sb_append(&sb, alt);
                    continue;
                }

                if (*p == '/' && *(p+1) == '/') {
                    p += 2;
                    char pat[256]; int pi = 0;
                    while (*p && *p != '/' && *p != '}' && pi < 255) pat[pi++] = *p++;
                    pat[pi] = 0;
                    if (*p == '/') {
                        p++;
                        char repl[256]; int ri = 0;
                        while (*p && *p != '}' && ri < 255) repl[ri++] = *p++;
                        repl[ri] = 0;
                        if (*p == '}') p++;
                        char *result = strdup(val);
                        char *pos;
                        while ((pos = strstr(result, pat)) != NULL) {
                            int prefix_len = pos - result;
                            int pat_len = strlen(pat);
                            int repl_len = strlen(repl);
                            int suffix_len = strlen(pos + pat_len);
                            char *new_str = malloc(prefix_len + repl_len + suffix_len + 1);
                            memcpy(new_str, result, prefix_len);
                            memcpy(new_str + prefix_len, repl, repl_len);
                            memcpy(new_str + prefix_len + repl_len, pos + pat_len, suffix_len + 1);
                            free(result);
                            result = new_str;
                            if (pat_len == 0) break;
                        }
                        sb_append(&sb, result);
                        free(result);
                    } else {
                        if (*p == '}') p++;
                        char *result = strdup(val);
                        char *pos;
                        int pat_len = strlen(pat);
                        while (pat_len > 0 && (pos = strstr(result, pat)) != NULL) {
                            int prefix_len = pos - result;
                            int suffix_len = strlen(pos + pat_len);
                            char *new_str = malloc(prefix_len + suffix_len + 1);
                            memcpy(new_str, result, prefix_len);
                            memcpy(new_str + prefix_len, pos + pat_len, suffix_len + 1);
                            free(result);
                            result = new_str;
                        }
                        sb_append(&sb, result);
                        free(result);
                    }
                } else {
                    if (*p == '}') p++;
                    sb_append(&sb, val);
                }
            } else if (isalpha(*p) || *p == '_') {
                char vname[256]; p = parse_var_name(p, vname, sizeof(vname));
                char *val = get_var(vm, vname); if (val) sb_append(&sb, val);
            } else if (*p == '*' || *p == '@') {
                /* $* 和 $@ 展开为所有位置参数 (空格分隔) */
                for (int i = 0; i < vm->positional_count; i++) {
                    if (i > 0) sb_append_char(&sb, ' ');
                    if (vm->positional[i]) sb_append(&sb, vm->positional[i]);
                }
                p++;
            } else if (*p == '?') {
                char buf[16]; snprintf(buf, sizeof(buf), "%d", vm->exit_code);
                sb_append(&sb, buf); p++;
            } else if (*p == '$') {
                char buf[16]; snprintf(buf, sizeof(buf), "%d", (int)getpid());
                sb_append(&sb, buf); p++;
            } else if (*p == '#') {
                char buf[16]; snprintf(buf, sizeof(buf), "%d", vm->positional_count);
                sb_append(&sb, buf); p++;
            } else if (isdigit(*p)) {
                int n = *p - '0';
                if (n == 0) sb_append(&sb, vm->script_name ? vm->script_name : "sh");
                else if (n >= 1 && n <= vm->positional_count && vm->positional[n-1])
                    sb_append(&sb, vm->positional[n-1]);
                p++;
            } else { sb_append_char(&sb, '$'); sb_append_char(&sb, *p++); }
        } else { sb_append_char(&sb, *p++); }
    }
    return sb_detach(&sb);
}

/* ========== pattern matching (for [[ ]] and case) ========== */

static int pattern_match(const char *pattern, const char *str) {
    return pattern && str && fnmatch(pattern, str, 0) == 0;
}

/* ========== extended builtin helper (fork+execvp fallback) ========== */

static int builtin_execvp(VM *vm, int argc, char **argv) {
    (void)vm; (void)argc;
    fflush(NULL);
    pid_t pid = fork();
    if (pid == 0) {
        execvp(argv[0], argv);
        _exit(127);
    } else if (pid > 0) {
        int status; waitpid(pid, &status, 0);
        return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
    }
    return 1;
}

/* ========== builtin dispatch table ========== */

static int builtin_dispatch(VM *vm, BuiltinID id, int argc, char **argv) {
    (void)argc;
    switch (id) {
    /* ---- core builtins ---- */
    case BID_ECHO: {
        int nl = 1, start = 1, interpret = 0;
        while (argc > start && argv[start][0] == '-' && argv[start][1] != 0 && argv[start][2] == 0) {
            if (strcmp(argv[start], "-n") == 0) { nl = 0; start++; }
            else if (strcmp(argv[start], "-e") == 0) { interpret = 1; start++; }
            else if (strcmp(argv[start], "-E") == 0) { interpret = 0; start++; }
            else break;
        }
        /* Combined options like -ne, -en, -neE */
        while (argc > start && argv[start][0] == '-' && argv[start][1] != 0 && argv[start][2] != 0) {
            char *p = argv[start] + 1;
            int recognized = 1;
            while (*p) {
                if (*p == 'n') nl = 0;
                else if (*p == 'e') interpret = 1;
                else if (*p == 'E') interpret = 0;
                else { recognized = 0; break; }
                p++;
            }
            if (recognized) start++;
            else break;
        }
        for (int i = start; i < argc; i++) {
            if (i > start) printf(" ");
            if (interpret) {
                /* Interpret \033, \n, \t, \\ etc */
                const char *s = argv[i];
                while (*s) {
                    if (*s == '\\' && s[1]) {
                        s++;
                        switch (*s) {
                            case 'n': printf("\n"); break;
                            case 't': printf("\t"); break;
                            case 'r': printf("\r"); break;
                            case '\\': printf("\\"); break;
                            case 'a': printf("\a"); break;
                            case 'b': printf("\b"); break;
                            case 'f': printf("\f"); break;
                            case 'v': printf("\v"); break;
                            case '0': { /* octal up to 3 digits */
                                int val = 0; int j = 0;
                                while (j < 3 && s[1] >= '0' && s[1] <= '7') {
                                    s++; val = val * 8 + (*s - '0'); j++;
                                }
                                printf("%c", val); break;
                            }
                            case 'x': { /* hex 1-2 digits */
                                int val = 0; int j = 0;
                                while (j < 2 && ((s[1] >= '0' && s[1] <= '9') ||
                                                 (s[1] >= 'a' && s[1] <= 'f') ||
                                                 (s[1] >= 'A' && s[1] <= 'F'))) {
                                    s++;
                                    if (*s >= '0' && *s <= '9') val = val * 16 + (*s - '0');
                                    else if (*s >= 'a' && *s <= 'f') val = val * 16 + (*s - 'a' + 10);
                                    else val = val * 16 + (*s - 'A' + 10);
                                    j++;
                                }
                                printf("%c", val); break;
                            }
                            default: printf("%c", *s); break;
                        }
                        s++;
                    } else {
                        putchar(*s++);
                    }
                }
            } else {
                printf("%s", argv[i]);
            }
        }
        if (nl) printf("\n");
        fflush(stdout);
        return 0;
    }
    case BID_CD: {
        const char *path = (argc > 1) ? argv[1] : getenv("HOME");
        if (!path) path = "/";
        if (chdir(path) != 0) { fprintf(stderr, "bashc: cd: %s: %s\n", path, strerror(errno)); return 1; }
        char cwd[4096]; if (getcwd(cwd, sizeof(cwd))) set_var(vm, "PWD", cwd);
        return 0;
    }
    case BID_PWD: {
        char cwd[4096];
        if (getcwd(cwd, sizeof(cwd))) printf("%s\n", cwd);
        fflush(stdout); return 0;
    }
    case BID_EXIT: {
        int code = (argc > 1) ? atoi(argv[1]) : vm->exit_code;
        vm->exit_code = code; vm->running = 0; return code;
    }
    case BID_READ: {
        char *vname = (argc > 1) ? argv[1] : "REPLY";
        char line[4096];
        if (fgets(line, sizeof(line), stdin)) {
            line[strcspn(line, "\n")] = 0; line[strcspn(line, "\r")] = 0;
            set_var(vm, vname, line);
        }
        return 0;
    }
    case BID_EXPORT: {
        for (int i = 1; i < argc; i++) {
            char *eq = strchr(argv[i], '=');
            if (eq) { *eq = 0; set_var(vm, argv[i], eq + 1); export_var(vm, argv[i]); *eq = '='; }
            else export_var(vm, argv[i]);
        }
        return 0;
    }
    case BID_UNSET: {
        for (int i = 1; i < argc; i++) unset_var(vm, argv[i]);
        return 0;
    }
    case BID_TRUE: return 0;
    case BID_FALSE: return 1;
    case BID_BREAK: return 0;
    case BID_CONTINUE: return 0;
    case BID_SOURCE: {
        if (argc < 2) return 1;
        VM *sub_vm = malloc(sizeof(VM));
        if (!sub_vm) return 1;
        memset(sub_vm, 0, sizeof(VM));
        if (vm_init(sub_vm, argv[1]) != 0) { free(sub_vm); return 1; }
        for (int i = 0; i < vm->var_count; i++) set_var(sub_vm, vm->vars[i].name, vm->vars[i].value);
        for (int i = 0; i < vm->array_count; i++) {
            int ai = array_get_index(sub_vm, vm->arrays[i].name);
            if (ai >= 0) {
                for (int j = 0; j < vm->arrays[i].count; j++)
                    if (vm->arrays[i].values[j])
                        array_set(sub_vm, vm->arrays[i].name, j, vm->arrays[i].values[j]);
                sub_vm->arrays[ai].count = vm->arrays[i].count;
            }
        }
        vm_run(sub_vm);
        int rc = sub_vm->exit_code;
        for (int i = 0; i < sub_vm->var_count; i++) set_var(vm, sub_vm->vars[i].name, sub_vm->vars[i].value);
        vm_free(sub_vm);
        free(sub_vm);
        return rc;
    }
    case BID_EVAL: {
        if (argc < 2) return 0;
        SBuf sb; sb_init(&sb);
        for (int i = 1; i < argc; i++) { if (i > 1) sb_append_char(&sb, ' '); sb_append(&sb, argv[i]); }
        char *scmd = sb_detach(&sb); int ret = system(scmd); free(scmd); return ret;
    }
    case BID_EXEC: {
        if (argc < 2) return 0;
        execvp(argv[1], argv + 1);
        fprintf(stderr, "bashc: exec: %s: %s\n", argv[1], strerror(errno));
        _exit(127);
    }
    case BID_SHIFT: {
        int n = (argc > 1) ? atoi(argv[1]) : 1;
        if (n < 0) n = 0;
        if (n > vm->positional_count) n = vm->positional_count;
        for (int i = 0; i < n; i++) free(vm->positional[i]);
        for (int i = n; i < vm->positional_count; i++) vm->positional[i - n] = vm->positional[i];
        vm->positional_count -= n;
        return 0;
    }
    case BID_SET: {
        if (argc == 1) {
            for (int i = 0; i < vm->var_count; i++)
                printf("%s=%s\n", vm->vars[i].name, vm->vars[i].value);
            fflush(stdout);
        } else {
            for (int i = 1; i < argc; i++) {
                char *eq = strchr(argv[i], '=');
                if (eq) { *eq = 0; set_var(vm, argv[i], eq + 1); *eq = '='; }
            }
        }
        return 0;
    }
    case BID_PRINTF: {
        if (argc < 2) return 0;
        const char *fmt = argv[1];
        int arg_idx = 2;
        const char *p = fmt;
        while (*p) {
            if (*p == '%' && *(p+1)) {
                p++;
                if (*p == '%') { putchar('%'); p++; continue; }
                char spec[32] = {'%', 0}; int si = 1;
                while (*p && strchr("-#0 +'", *p)) spec[si++] = *p++;
                while (*p && isdigit(*p)) spec[si++] = *p++;
                if (*p == '.') { spec[si++] = *p++; while (*p && isdigit(*p)) spec[si++] = *p++; }
                char conv = 0;
                if (*p && strchr("diouxXeEfFgGaAcs", *p)) { conv = *p++; spec[si++] = conv; spec[si] = 0; }
                else { spec[si] = 0; if (*p) p++; }
                if (arg_idx < argc && conv) {
                    char *arg = argv[arg_idx++];
                    char *expanded = expand_all(vm, arg);
                    if (strchr("diouxX", conv))
                        printf(spec, atoi(expanded));
                    else if (strchr("eEfFgGaA", conv))
                        printf(spec, atof(expanded));
                    else
                        printf(spec, expanded);
                    free(expanded);
                }
            } else { putchar(*p++); }
        }
        fflush(stdout); return 0;
    }
    case BID_LET: {
        for (int i = 1; i < argc; i++) {
            char *eq = strchr(argv[i], '=');
            if (eq) {
                *eq = 0; int val = eval_arithmetic(vm, eq + 1);
                char buf[32]; snprintf(buf, sizeof(buf), "%d", val);
                set_var(vm, argv[i], buf); *eq = '=';
            } else {
                eval_arithmetic(vm, argv[i]);
            }
        }
        return 0;
    }
    case BID_ALIAS: {
        if (argc == 1) {
            for (int i = 0; i < vm->alias_count; i++)
                printf("alias %s='%s'\n", vm->aliases[i].name, vm->aliases[i].value);
            fflush(stdout);
        } else {
            for (int i = 1; i < argc; i++) {
                char *eq = strchr(argv[i], '=');
                if (eq) { *eq = 0; set_alias(vm, argv[i], eq + 1); *eq = '='; }
                else {
                    char *v = get_alias(vm, argv[i]);
                    if (v) printf("alias %s='%s'\n", argv[i], v);
                    else fprintf(stderr, "bashc: alias: %s: not found\n", argv[i]);
                }
            }
            fflush(stdout);
        }
        return 0;
    }
    case BID_UNALIAS: {
        for (int i = 1; i < argc; i++) unset_alias(vm, argv[i]);
        return 0;
    }
    case BID_TYPE: {
        for (int i = 1; i < argc; i++) {
            int bid = builtin_lookup(argv[i]);
            if (bid >= 0) printf("%s is a shell builtin\n", argv[i]);
            else if (get_alias(vm, argv[i])) printf("%s is aliased to `%s'\n", argv[i], get_alias(vm, argv[i]));
            else {
                char *path = getenv("PATH");
                char *path_copy = path ? strdup(path) : strdup("/usr/bin:/bin");
                char *dir = strtok(path_copy, ":"); int found = 0;
                while (dir) {
                    char full[4096]; snprintf(full, sizeof(full), "%s/%s", dir, argv[i]);
                    struct stat st;
                    if (stat(full, &st) == 0 && (st.st_mode & S_IXUSR)) {
                        printf("%s is %s\n", argv[i], full); found = 1; break;
                    }
                    dir = strtok(NULL, ":");
                }
                if (!found) printf("bashc: type: %s: not found\n", argv[i]);
                free(path_copy);
            }
        }
        fflush(stdout); return 0;
    }
    case BID_WAIT: {
        int status;
        while (waitpid(-1, &status, 0) > 0);
        return 0;
    }
    case BID_JOBS: {
        printf("bashc: jobs: no job control in this VM\n");
        fflush(stdout); return 0;
    }
    case BID_BG: {
        fprintf(stderr, "bashc: bg: no job control\n"); return 1;
    }
    case BID_FG: {
        fprintf(stderr, "bashc: fg: no job control\n"); return 1;
    }
    case BID_KILL: {
        if (argc < 2) { fprintf(stderr, "bashc: kill: usage: kill [-s sigspec] pid\n"); return 1; }
        int sig = SIGTERM; int arg_start = 1;
        if (argv[1][0] == '-') {
            if (argv[1][1] == 's') {
                if (argc < 4) { fprintf(stderr, "bashc: kill: usage: kill -s sigspec pid\n"); return 1; }
                sig = atoi(argv[2]);
                if (sig <= 0) {
                    if (strcmp(argv[2], "HUP") == 0) sig = SIGHUP;
                    else if (strcmp(argv[2], "INT") == 0) sig = SIGINT;
                    else if (strcmp(argv[2], "KILL") == 0) sig = SIGKILL;
                    else if (strcmp(argv[2], "TERM") == 0) sig = SIGTERM;
                    else if (strcmp(argv[2], "STOP") == 0) sig = SIGSTOP;
                    else if (strcmp(argv[2], "CONT") == 0) sig = SIGCONT;
                    else sig = SIGTERM;
                }
                arg_start = 3;
            } else {
                sig = atoi(argv[1] + 1);
                if (sig <= 0) sig = SIGTERM;
                arg_start = 2;
            }
        }
        for (int i = arg_start; i < argc; i++) {
            pid_t pid = atoi(argv[i]);
            if (pid > 0) kill(pid, sig);
        }
        return 0;
    }
    case BID_UMASK: {
        if (argc > 1) {
            mode_t m = strtol(argv[1], NULL, 8);
            umask(m);
        } else {
            mode_t m = umask(0); umask(m);
            printf("%04o\n", m); fflush(stdout);
        }
        return 0;
    }
    case BID_ULIMIT: {
        struct rlimit rl;
        if (argc > 1) {
            int resource = RLIMIT_NOFILE;
            if (strcmp(argv[1], "-n") == 0) resource = RLIMIT_NOFILE;
            else if (strcmp(argv[1], "-c") == 0) resource = RLIMIT_CORE;
            else if (strcmp(argv[1], "-t") == 0) resource = RLIMIT_CPU;
            if (argc > 2) {
                rl.rlim_cur = atol(argv[2]);
                rl.rlim_max = atol(argv[2]);
                setrlimit(resource, &rl);
            }
        } else {
            getrlimit(RLIMIT_NOFILE, &rl);
            printf("nofile: %ld\n", (long)rl.rlim_cur);
            fflush(stdout);
        }
        return 0;
    }
    case BID_TIMES: {
        struct tms buf; clock_t real = times(&buf);
        printf("0m%ld.%03lds real\n", (long)(real / CLOCKS_PER_SEC), (long)((real % CLOCKS_PER_SEC) * 1000 / CLOCKS_PER_SEC));
        fflush(stdout); return 0;
    }
    case BID_TRAP: {
        if (argc > 1) {
            int sig = 0;
            if (strcmp(argv[1], "INT") == 0) sig = SIGINT;
            else if (strcmp(argv[1], "TERM") == 0) sig = SIGTERM;
            else if (strcmp(argv[1], "HUP") == 0) sig = SIGHUP;
            else if (strcmp(argv[1], "QUIT") == 0) sig = SIGQUIT;
            else if (strcmp(argv[1], "EXIT") == 0) sig = 0;
            if (sig > 0 && argc > 2) signal(sig, SIG_IGN);
        } else {
            printf("bashc: trap: no traps set\n"); fflush(stdout);
        }
        return 0;
    }
    case BID_GETOPTS: {
        fprintf(stderr, "bashc: getopts: not fully implemented\n"); return 1;
    }
    case BID_DECLARE:
    case BID_LOCAL: {
        for (int i = 1; i < argc; i++) {
            char *eq = strchr(argv[i], '=');
            if (eq) { *eq = 0; set_var(vm, argv[i], eq + 1); *eq = '='; }
            else set_var(vm, argv[i], "");
        }
        return 0;
    }
    case BID_MAPFILE: {
        const char *vname = (argc > 2) ? argv[2] : "MAPFILE";
        const char *fname = argv[1];
        FILE *fp = fopen(fname, "r");
        if (!fp) { fprintf(stderr, "bashc: mapfile: %s: %s\n", fname, strerror(errno)); return 1; }
        char line[4096]; int idx = 0;
        while (fgets(line, sizeof(line), fp)) {
            line[strcspn(line, "\n")] = 0;
            array_set(vm, vname, idx++, line);
        }
        fclose(fp); return 0;
    }
    case BID_COMPGEN: {
        fprintf(stderr, "bashc: compgen: not implemented\n"); return 1;
    }
    case BID_COMPLETE: {
        fprintf(stderr, "bashc: complete: not implemented\n"); return 1;
    }
    case BID_ENABLE: {
        if (argc > 1 && strcmp(argv[1], "-n") == 0)
            fprintf(stderr, "bashc: enable: disabling builtins not supported\n");
        return 0;
    }
    case BID_BUILTIN: {
        if (argc < 2) return 0;
        int bid = builtin_lookup(argv[1]);
        if (bid < 0) { fprintf(stderr, "bashc: builtin: %s: not a builtin\n", argv[1]); return 1; }
        return builtin_dispatch(vm, (BuiltinID)bid, argc - 1, argv + 1);
    }
    case BID_CALLER: {
        printf("bashc: caller: frame 0 at pc=%d\n", vm->pc);
        fflush(stdout); return 0;
    }
    case BID_DIRS: {
        if (dir_sp == 0) {
            char cwd[4096]; if (getcwd(cwd, sizeof(cwd))) printf(" 0  %s\n", cwd);
        } else {
            for (int i = dir_sp - 1; i >= 0; i--) printf(" %d  %s\n", dir_sp - i - 1, dir_stack[i]);
        }
        fflush(stdout); return 0;
    }
    case BID_PUSHD: {
        if (argc < 2) { fprintf(stderr, "bashc: pushd: usage: pushd dir\n"); return 1; }
        char cwd[4096]; if (getcwd(cwd, sizeof(cwd))) dirs_push(cwd);
        if (chdir(argv[1]) != 0) { fprintf(stderr, "bashc: pushd: %s: %s\n", argv[1], strerror(errno)); return 1; }
        return 0;
    }
    case BID_POPD: {
        if (dir_sp <= 0) { fprintf(stderr, "bashc: popd: directory stack empty\n"); return 1; }
        char *d = dirs_pop();
        if (chdir(d) != 0) { fprintf(stderr, "bashc: popd: %s: %s\n", d, strerror(errno)); free(d); return 1; }
        free(d); return 0;
    }
    case BID_DISOWN: {
        fprintf(stderr, "bashc: disown: no job control\n"); return 1;
    }
    case BID_SHOPT: {
        printf("bashc: shopt: no options configurable\n"); fflush(stdout); return 0;
    }
    case BID_SUSPEND: {
        kill(getpid(), SIGSTOP); return 0;
    }
    case BID_TEST: {
        return execute_test(vm, argc, argv);
    }
    case BID_HASH: {
        printf("bashc: hash: hash table empty\n"); fflush(stdout); return 0;
    }
    case BID_BIND: {
        printf("bashc: bind: no key bindings\n"); fflush(stdout); return 0;
    }
    case BID_HELP: {
        if (argc > 1) {
            printf("bashc: help: no help available for %s\n", argv[1]);
        } else {
            const char *s = builtin_table[0].name;
            printf("bashc builtin commands: %s", s);
            for (int i = 1; i < builtin_table_size; i++) printf(" %s", builtin_table[i].name);
            printf("\n");
        }
        fflush(stdout); return 0;
    }
    case BID_HISTORY: {
        printf("bashc: history: no history available\n"); fflush(stdout); return 0;
    }
    case BID_LOGOUT: {
        vm->exit_code = 0; vm->running = 0; return 0;
    }

    /* ---- extended builtins (fork+execvp fallback) ---- */
    case BID_CAT:      case BID_CP:       case BID_MV:       case BID_RM:
    case BID_MKDIR:    case BID_RMDIR:    case BID_TOUCH:    case BID_CHMOD:
    case BID_CHOWN:    case BID_LN:       case BID_STAT:     case BID_BASENAME:
    case BID_DIRNAME:  case BID_REALPATH: case BID_MKTEMP:   case BID_TEE:
    case BID_HEAD:     case BID_TAIL:     case BID_WC:       case BID_TR:
    case BID_CUT:      case BID_SORT:     case BID_UNIQ:     case BID_DIFF:
    case BID_FIND:     case BID_GREP:     case BID_DU:       case BID_DF:
    case BID_WHICH:    case BID_WHEREIS:  case BID_FILE:     case BID_SEQ:
    case BID_SLEEP:    case BID_DATE:     case BID_ENV:      case BID_PRINTENV:
    case BID_HOSTNAME: case BID_ID:       case BID_WHOAMI:   case BID_UNAME:
    case BID_TTY:      case BID_CLEAR:    case BID_RESET:    case BID_YES:
    case BID_XARGS:    case BID_PASTE:    case BID_SHA1SUM:  case BID_SHA256SUM:
    case BID_MD5SUM:   case BID_BASE64:   case BID_COMM:     case BID_JOIN:
    case BID_NL:       case BID_OD:       case BID_PASTE_CMD:case BID_EXPAND:
    case BID_EXPR:     case BID_CMP:      case BID_DD:       case BID_SPLIT:
    case BID_CSCOPE:   case BID_CTAGS:    case BID_NM:       case BID_SIZE:
    case BID_STRINGS:  case BID_STRIP:    case BID_AR:       case BID_RANLIB:
    case BID_OBJDUMP:  case BID_READELF:  case BID_GDB:      case BID_MAKE:
        return builtin_execvp(vm, argc, argv);

    default:
        return -1;
    }
}

/* ========== execute_builtin (name lookup + dispatch) ========== */

static int execute_builtin(VM *vm, int argc, char **argv) {
    if (argc == 0) return 0;
    const char *cmd = argv[0];

    char *alias_val = get_alias(vm, cmd);
    if (alias_val) {
        char *expanded = expand_all(vm, alias_val);
        int ret = system(expanded);
        free(expanded);
        return ret;
    }

    int id = builtin_lookup(cmd);
    if (id < 0) return -1;
    return builtin_dispatch(vm, (BuiltinID)id, argc, argv);
}

/* ========== test / [ / [[ command ========== */

static int execute_test(VM *vm, int argc, char **argv) {
    (void)vm;
    while (argc > 0 && (strcmp(argv[argc-1], "]") == 0 || strcmp(argv[argc-1], "]]") == 0)) argc--;
    int start = 0;
    if (argc > 0 && (strcmp(argv[0], "[") == 0 || strcmp(argv[0], "[[") == 0)) start = 1;
    int n = argc - start; char **a = argv + start;
    if (n == 0) return 1;
    if (n == 1) return (a[0][0] == 0) ? 1 : 0;

    if (n == 2) {
        if (strcmp(a[0], "-n") == 0) return (a[1][0] == 0) ? 1 : 0;
        if (strcmp(a[0], "-z") == 0) return (a[1][0] == 0) ? 0 : 1;
        if (strcmp(a[0], "-f") == 0) { struct stat st; return (stat(a[1], &st) == 0 && S_ISREG(st.st_mode)) ? 0 : 1; }
        if (strcmp(a[0], "-d") == 0) { struct stat st; return (stat(a[1], &st) == 0 && S_ISDIR(st.st_mode)) ? 0 : 1; }
        if (strcmp(a[0], "-e") == 0) { struct stat st; return (stat(a[1], &st) == 0) ? 0 : 1; }
        if (strcmp(a[0], "-r") == 0) return (access(a[1], R_OK) == 0) ? 0 : 1;
        if (strcmp(a[0], "-w") == 0) return (access(a[1], W_OK) == 0) ? 0 : 1;
        if (strcmp(a[0], "-x") == 0) return (access(a[1], X_OK) == 0) ? 0 : 1;
        if (strcmp(a[0], "-L") == 0) { struct stat st; return (lstat(a[1], &st) == 0 && S_ISLNK(st.st_mode)) ? 0 : 1; }
        if (strcmp(a[0], "-s") == 0) { struct stat st; return (stat(a[1], &st) == 0 && st.st_size > 0) ? 0 : 1; }
        return (a[0][0] == 0) ? 1 : 0;
    }

    if (n == 3) {
        const char *op = a[1];
        if (strcmp(op, "=") == 0 || strcmp(op, "==") == 0) return pattern_match(a[2], a[0]) ? 0 : 1;
        if (strcmp(op, "!=") == 0) return (strcmp(a[0], a[2]) != 0) ? 0 : 1;
        if (strcmp(op, "=~") == 0) return pattern_match(a[2], a[0]) ? 0 : 1;
        int left = atoi(a[0]), right = atoi(a[2]);
        if (strcmp(op, "-eq") == 0) return (left == right) ? 0 : 1;
        if (strcmp(op, "-ne") == 0) return (left != right) ? 0 : 1;
        if (strcmp(op, "-lt") == 0) return (left < right) ? 0 : 1;
        if (strcmp(op, "-gt") == 0) return (left > right) ? 0 : 1;
        if (strcmp(op, "-le") == 0) return (left <= right) ? 0 : 1;
        if (strcmp(op, "-ge") == 0) return (left >= right) ? 0 : 1;
    }

    return 1;
}

/* ========== instruction reader ========== */

static int read_instruction(VM *vm, uint8_t *op, int32_t *a, int32_t *b) {
    if (vm->pc >= vm->code_size) return 0;
    *op = vm->code[vm->pc++]; *a = 0; *b = 0;
    int n = opcode_operand_count((Opcode)*op);
    if (n >= 1) { if (vm->pc + 4 > vm->code_size) return 0; memcpy(a, vm->code + vm->pc, 4); vm->pc += 4; }
    if (n >= 2) { if (vm->pc + 4 > vm->code_size) return 0; memcpy(b, vm->code + vm->pc, 4); vm->pc += 4; }
    return 1;
}

/* ========== VM API ========== */

int vm_init(VM *vm, const char *bc_file) {
    memset(vm, 0, sizeof(*vm));
    vm->saved_stdin = -1; vm->saved_stdout = -1;

    FILE *fp = fopen(bc_file, "rb");
    if (!fp) { fprintf(stderr, "bashc_vm: cannot open '%s'\n", bc_file); return -1; }

    int32_t magic;
    if (fread(&magic, 4, 1, fp) != 1) { fclose(fp); return -1; }
    if (magic != BASHC_MAGIC) { fprintf(stderr, "bashc_vm: bad magic\n"); fclose(fp); return -1; }

    int32_t version;
    if (fread(&version, 4, 1, fp) != 1) { fclose(fp); return -1; }
    if (version != BASHC_VERSION) { fprintf(stderr, "bashc_vm: version mismatch\n"); fclose(fp); return -1; }

    int32_t sc;
    if (fread(&sc, 4, 1, fp) != 1) { fclose(fp); return -1; }
    vm->str_count = sc;
    fprintf(stderr, "[vm_init] str_count=%d\n", sc);
    for (int i = 0; i < sc && i < MAX_STR_TABLE; i++) {
        int32_t len;
        if (fread(&len, 4, 1, fp) != 1) { fclose(fp); return -1; }
        vm->str_table[i].data = malloc(len + 1);
        if (!vm->str_table[i].data) { fclose(fp); return -1; }
        if (len > 0 && fread(vm->str_table[i].data, 1, len, fp) != (size_t)len) { fclose(fp); return -1; }
        vm->str_table[i].data[len] = 0;
        vm->str_table[i].len = len;
        fprintf(stderr, "  str[%d] len=%d data='%s'\n", i, len, vm->str_table[i].data);
    }

    /* read function table */
    int32_t fc;
    if (fread(&fc, 4, 1, fp) != 1) { fclose(fp); return -1; }
    vm->func_count = fc;
    fprintf(stderr, "[vm_init] func_count=%d\n", fc);
    for (int i = 0; i < fc && i < MAX_FUNCTIONS; i++) {
        int32_t name_idx, addr, argc;
        if (fread(&name_idx, 4, 1, fp) != 1) { fclose(fp); return -1; }
        if (fread(&addr, 4, 1, fp) != 1) { fclose(fp); return -1; }
        if (fread(&argc, 4, 1, fp) != 1) { fclose(fp); return -1; }
        fprintf(stderr, "  func[%d] name_idx=%d addr=%d argc=%d str_count=%d\n", i, name_idx, addr, argc, vm->str_count);
        if (name_idx >= 0 && name_idx < vm->str_count)
            vm->functions[i].name = strdup(vm->str_table[name_idx].data);
        else
            vm->functions[i].name = strdup("");
        vm->functions[i].addr = addr;
        vm->functions[i].argc = argc;
    }

    int32_t cs;
    if (fread(&cs, 4, 1, fp) != 1) { fclose(fp); return -1; }
    vm->code_size = cs;
    vm->code = malloc(cs);
    if (!vm->code) { fclose(fp); return -1; }
    if (fread(vm->code, 1, cs, fp) != (size_t)cs) { fclose(fp); return -1; }

    fclose(fp);
    vm->pc = 0; vm->sp = 0; vm->running = 1; vm->exit_code = 0; vm->call_sp = 0; vm->loop_sp = 0;
    vm->array_count = 0; vm->alias_count = 0; vm->positional_count = 0;
    vm->script_name = strdup(bc_file);
    return 0;
}

void vm_run(VM *vm) {
    uint8_t op; int32_t a, b;
    int skip_mode = 0;
    int trace_count = 0;
    fprintf(stderr, "[vm_run] code_size=%d func_count=%d str_count=%d\n", vm->code_size, vm->func_count, vm->str_count);
    for (int i = 0; i < vm->func_count && i < 5; i++) fprintf(stderr, "  func[%d] name=%s addr=%d\n", i, vm->functions[i].name, vm->functions[i].addr);
    int skip_depth = 0;

    vm->running = 1;

    while (vm->running && vm->pc < vm->code_size) {
        if (!read_instruction(vm, &op, &a, &b)) break;

        if (skip_mode) {
            if (op == OP_WHILE_BEG || op == OP_FOR_BEGIN || op == OP_SELECT_BEG) { skip_depth++; continue; }
            if (op == OP_WHILE_END) {
                if (skip_depth > 0) { skip_depth--; continue; }
                if (skip_mode == 1) { skip_mode = 0; }
                else { vm->pc = a; skip_mode = 0; }
                continue;
            }
            if (op == OP_FOR_NEXT) {
                if (skip_depth > 0) { skip_depth--; continue; }
                skip_mode = 0; for_pop(); continue;
            }
            if (op == OP_SELECT_END) {
                if (skip_depth > 0) { skip_depth--; continue; }
                skip_mode = 0; for_pop(); continue;
            }
            continue;
        }

        switch (op) {
        case OP_NOP: break;
        case OP_HALT: vm->running = 0; break;

        /* stack */
        case OP_PUSH_STR: push_str(vm, (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : ""); break;
        case OP_PUSH_INT: push_int(vm, a); break;
        case OP_POP: { VMValue v = pop(vm); free_value(&v); break; }
        case OP_DUP: { VMValue *t = peek(vm); if (t) { if (t->type == 0) push_int(vm, t->ival); else push_str(vm, t->sval); } break; }

        /* variables */
        case OP_STORE: if (a >= 0 && a < vm->str_count) { char *v = pop_str(vm); set_var(vm, vm->str_table[a].data, v); free(v); } break;
        case OP_LOAD: { const char *v = (a >= 0 && a < vm->str_count) ? get_var(vm, vm->str_table[a].data) : NULL; push_str(vm, v ? v : ""); break; }
        case OP_EXPORT: if (a >= 0 && a < vm->str_count) export_var(vm, vm->str_table[a].data); break;
        case OP_SHIFT: { int n = pop_int(vm); if (n < 0) n = 0; if (n > vm->positional_count) n = vm->positional_count; for (int i = 0; i < n; i++) free(vm->positional[i]); for (int i = n; i < vm->positional_count; i++) vm->positional[i - n] = vm->positional[i]; vm->positional_count -= n; push_int(vm, 0); break; }
        case OP_UNSET: { const char *vname = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : NULL; if (vname) unset_var(vm, vname); push_int(vm, 0); break; }

        case OP_EXPAND: { char *s = pop_str(vm); char *e = expand_vars(vm, s); push_str(vm, e); free(s); free(e); break; }
        case OP_EXPAND_PAT: {
            char *s = pop_str(vm);
            const char *pat = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "";
            const char *repl = (b >= 0 && b < vm->str_count) ? vm->str_table[b].data : "";
            SBuf sb; sb_init(&sb); int slen = strlen(s), plen = strlen(pat);
            for (int i = 0; i < slen; ) {
                if (plen > 0 && strncmp(s + i, pat, plen) == 0) { sb_append(&sb, repl); i += plen; }
                else { sb_append_char(&sb, s[i]); i++; }
            }
            free(s); char *r = sb_detach(&sb); push_str(vm, r); free(r); break;
        }
        case OP_EXPAND_ALL: { char *s = pop_str(vm); char *e = expand_all(vm, s); push_str(vm, e); free(s); free(e); break; }

        /* arithmetic */
        case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD: {
            int bv = pop_int(vm), av = pop_int(vm), r = 0;
            switch (op) { case OP_ADD: r=av+bv; break; case OP_SUB: r=av-bv; break; case OP_MUL: r=av*bv; break; case OP_DIV: r=bv?av/bv:0; break; case OP_MOD: r=bv?av%bv:0; break; }
            push_int(vm, r); break;
        }
        case OP_NEG: { int v = pop_int(vm); push_int(vm, -v); break; }
        case OP_NOT: { int v = pop_int(vm); push_int(vm, !v); break; }
        case OP_BIT_AND: { int bv = pop_int(vm), av = pop_int(vm); push_int(vm, av & bv); break; }
        case OP_BIT_OR:  { int bv = pop_int(vm), av = pop_int(vm); push_int(vm, av | bv); break; }
        case OP_BIT_XOR: { int bv = pop_int(vm), av = pop_int(vm); push_int(vm, av ^ bv); break; }

        /* comparisons */
        case OP_CMP_LT: case OP_CMP_GT: case OP_CMP_LE: case OP_CMP_GE: case OP_CMP_EQ: case OP_CMP_NE: {
            VMValue bv = pop(vm), av = pop(vm); int result = 0;
            if (av.type == 0 && bv.type == 0) {
                int ai = av.ival, bi = bv.ival;
                switch (op) { case OP_CMP_LT: result=ai<bi; break; case OP_CMP_GT: result=ai>bi; break; case OP_CMP_LE: result=ai<=bi; break; case OP_CMP_GE: result=ai>=bi; break; case OP_CMP_EQ: result=ai==bi; break; case OP_CMP_NE: result=ai!=bi; break; }
            } else {
                char buf1[32], buf2[32];
                char *as = (av.type == 1 && av.sval) ? av.sval : (snprintf(buf1,32,"%d",av.ival), buf1);
                char *bs = (bv.type == 1 && bv.sval) ? bv.sval : (snprintf(buf2,32,"%d",bv.ival), buf2);
                int cmp = strcmp(as, bs);
                switch (op) { case OP_CMP_LT: result=cmp<0; break; case OP_CMP_GT: result=cmp>0; break; case OP_CMP_LE: result=cmp<=0; break; case OP_CMP_GE: result=cmp>=0; break; case OP_CMP_EQ: result=cmp==0; break; case OP_CMP_NE: result=cmp!=0; break; }
            }
            free_value(&av); free_value(&bv); push_int(vm, result); break;
        }

        /* output */
        case OP_ECHO: case OP_ECHO_N: {
            int count = a; if (count > 255) count = 255;
            char *args[256]; int nl = (op == OP_ECHO);
            for (int i = count - 1; i >= 0; i--) args[i] = pop_str(vm);
            for (int i = 0; i < count; i++) {
                if (i > 0) printf(" ");
                char *expanded = expand_all(vm, args[i]);
                printf("%s", expanded);
                free(expanded);
                free(args[i]);
            }
            if (nl) printf("\n");
            fflush(stdout);
            push_int(vm, 0);
            break;
        }
        case OP_PRINTF: {
            int count = a; if (count > 255) count = 255;
            char *argv[256];
            for (int i = count - 1; i >= 0; i--) argv[i] = pop_str(vm);
            argv[count] = NULL;
            builtin_dispatch(vm, BID_PRINTF, count, argv);
            for (int i = 0; i < count; i++) free(argv[i]);
            push_int(vm, 0);
            break;
        }
        case OP_LET: {
            int count = a; if (count > 255) count = 255;
            char *argv[256];
            for (int i = count - 1; i >= 0; i--) argv[i] = pop_str(vm);
            argv[count] = NULL;
            builtin_dispatch(vm, BID_LET, count, argv);
            for (int i = 0; i < count; i++) free(argv[i]);
            push_int(vm, 0);
            break;
        }

        /* command execution */
        case OP_EXEC: case OP_EXEC_BUILTIN: {
            int count = a; if (count > 255) count = 255;
            char *argv[256];
            for (int i = count - 1; i >= 0; i--) argv[i] = pop_str(vm);
            argv[count] = NULL;
            if (count == 0) { push_int(vm, 0); break; }

            /* For builtin commands, expand variables in each argument */
            if (op == OP_EXEC_BUILTIN) {
                int bid = builtin_lookup(argv[0]);
                if (bid >= 0 && (bid == BID_ECHO || bid == BID_PRINTF || bid == BID_TEST)) {
                    for (int i = 1; i < count; i++) {
                        char *expanded = expand_all(vm, argv[i]);
                        free(argv[i]);
                        argv[i] = expanded;
                    }
                }
            }

            int rc = 0;
            if (op == OP_EXEC_BUILTIN) rc = execute_builtin(vm, count, argv);
            if (op == OP_EXEC || rc < 0) {
                fflush(NULL);
                pid_t pid = fork();
                if (pid == 0) { execvp(argv[0], argv); fprintf(stderr, "bashc: %s: %s\n", argv[0], strerror(errno)); _exit(127); }
                else if (pid > 0) { int status; waitpid(pid, &status, 0); rc = WIFEXITED(status) ? WEXITSTATUS(status) : 1; }
                else rc = 1;
            }
            push_int(vm, rc);
            for (int i = 0; i < count; i++) free(argv[i]);
            break;
        }

        case OP_TEST: {
            int count = a; if (count > 255) count = 255;
            char *argv[256];
            for (int i = count - 1; i >= 0; i--) argv[i] = pop_str(vm);
            argv[count] = NULL;
            int rc = execute_test(vm, count, argv);
            push_int(vm, rc);
            for (int i = 0; i < count; i++) free(argv[i]);
            break;
        }

        case OP_READ: {
            const char *vname = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "REPLY";
            char line[4096];
            if (fgets(line, sizeof(line), stdin)) { line[strcspn(line, "\n")] = 0; line[strcspn(line, "\r")] = 0; set_var(vm, vname, line); push_int(vm, 0); }
            else push_int(vm, 1);
            break;
        }

        /* control flow */
        case OP_JMP: vm->pc = a; break;
        case OP_JZ: { if (pop_int(vm) == 0) vm->pc = a; break; }
        case OP_JNZ: { if (pop_int(vm) != 0) vm->pc = a; break; }
        case OP_CALL:
            if (vm->call_sp >= VM_CALL_DEPTH) { vm->running = 0; break; }
            vm->call_stack[vm->call_sp++] = vm->pc; vm->pc = a; break;
        case OP_RET: {
            /* 从函数返回, 恢复位置参数 */
            if (vm->call_sp <= 0) { vm->running = 0; break; }
            /* 释放当前函数的位置参数 */
            for (int i = 0; i < vm->positional_count; i++) free(vm->positional[i]);
            /* 恢复调用者的位置参数 */
            vm->call_sp--;
            int saved_count = vm->saved_pos_count_stack[vm->call_sp];
            for (int i = 0; i < saved_count; i++) vm->positional[i] = vm->saved_pos_stack[vm->call_sp][i];
            vm->positional_count = saved_count;
            vm->pc = vm->call_stack[vm->call_sp];
            break;
        }

        /* case/esac */
        case OP_CASE: {
            const char *pat = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "";
            char *value = pop_str(vm);
            int matched = pattern_match(pat, value);
            push_int(vm, matched);
            free(value);
            break;
        }
        case OP_CASE_END: break;

        /* function definition and call */
        case OP_FUNC_DEF: {
            const char *fname = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "";
            if (vm->func_count < MAX_FUNCTIONS) {
                vm->functions[vm->func_count].name = strdup(fname);
                vm->functions[vm->func_count].addr = pop_int(vm);
                vm->functions[vm->func_count].argc = 0;
                vm->func_count++;
            }
            push_int(vm, 0);
            break;
        }
        case OP_FUNC_CALL: {
            /* a 编码: 高16位=arg_count, 低16位=name_idx */
            int func_argc = (a >> 16) & 0xFFFF;
            int name_idx = a & 0xFFFF;
            const char *fname = (name_idx >= 0 && name_idx < vm->str_count) ? vm->str_table[name_idx].data : "";
            int found = 0;
            for (int i = 0; i < vm->func_count; i++) {
                if (strcmp(vm->functions[i].name, fname) == 0) {
                    if (vm->call_sp >= VM_CALL_DEPTH) { vm->running = 0; break; }
                    /* 弹出参数 (逆序) */
                    char *new_args[256];
                    for (int i = func_argc - 1; i >= 0; i--) new_args[i] = pop_str(vm);
                    /* 保存当前函数的位置参数到 saved_pos_stack */
                    for (int i = 0; i < vm->positional_count; i++) {
                        vm->saved_pos_stack[vm->call_sp][i] = vm->positional[i];
                        vm->positional[i] = NULL;
                    }
                    vm->saved_pos_count_stack[vm->call_sp] = vm->positional_count;
                    /* 释放旧位置参数 */
                    for (int i = 0; i < vm->positional_count; i++) free(vm->positional[i]);
                    /* 设置新位置参数 */
                    for (int i = 0; i < func_argc && i < 256; i++) vm->positional[i] = new_args[i];
                    vm->positional_count = func_argc;
                    /* 压入返回地址 */
                    vm->call_stack[vm->call_sp++] = vm->pc;
                    vm->pc = vm->functions[i].addr;
                    found = 1;
                    break;
                }
            }
            if (!found) {
                fprintf(stderr, "bashc: function %s: not found\n", fname);
                /* 弹出已压入的参数 */
                for (int i = 0; i < func_argc; i++) { char *s = pop_str(vm); free(s); }
                push_int(vm, 1);
            }
            break;
        }
        case OP_RETURN: {
            /* return N - pop optional exit code and return from function */
            int rc = 0;
            if (vm->sp > 0) {
                VMValue top = vm->stack[--vm->sp];
                if (top.type == 0) rc = top.ival;
                else if (top.sval) { rc = atoi(top.sval); free(top.sval); }
            }
            vm->exit_code = rc;
            if (vm->call_sp > 0) {
                /* 释放当前函数的位置参数 */
                for (int i = 0; i < vm->positional_count; i++) free(vm->positional[i]);
                /* 恢复调用者的位置参数 */
                vm->call_sp--;
                int saved_count = vm->saved_pos_count_stack[vm->call_sp];
                for (int i = 0; i < saved_count; i++) vm->positional[i] = vm->saved_pos_stack[vm->call_sp][i];
                vm->positional_count = saved_count;
                vm->pc = vm->call_stack[vm->call_sp];
            } else {
                /* top-level return - exit script */
                vm->running = 0;
            }
            /* 不压入返回码到栈, 调用者通过 $? 获取 */
            break;
        }

        /* select */
        case OP_SELECT_BEG: {
            int count = pop_int(vm);
            char **items = malloc(sizeof(char *) * count);
            for (int i = count - 1; i >= 0; i--) items[i] = pop_str(vm);
            const char *vname = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "";
            /* print menu */
            printf("1) %s\n", items[0]);
            for (int i = 1; i < count; i++) printf("%d) %s\n", i + 1, items[i]);
            printf("#? "); fflush(stdout);
            char line[256];
            if (fgets(line, sizeof(line), stdin)) {
                line[strcspn(line, "\n")] = 0;
                int choice = atoi(line);
                if (choice >= 1 && choice <= count) {
                    set_var(vm, vname, items[choice - 1]);
                    push_int(vm, 1);
                } else {
                    set_var(vm, vname, "");
                    push_int(vm, 0);
                }
            } else {
                push_int(vm, 0);
            }
            for (int i = 0; i < count; i++) free(items[i]);
            free(items);
            break;
        }
        case OP_SELECT_END: break;

        /* arrays */
        case OP_ARRAY_SET: {
            const char *vname = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "";
            char *val = pop_str(vm);
            int idx = pop_int(vm);
            array_set(vm, vname, idx, val);
            free(val);
            push_int(vm, 0);
            break;
        }
        case OP_ARRAY_GET: {
            const char *vname = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "";
            int idx = pop_int(vm);
            char *val = array_get(vm, vname, idx);
            if (val) push_str(vm, val);
            else push_str(vm, "");
            break;
        }

        /* redirection */
        case OP_REDIR_OUT: case OP_REDIR_APP: {
            char *fn = pop_str(vm);
            if (vm->saved_stdout == -1) vm->saved_stdout = dup(STDOUT_FILENO);
            int flags = (op == OP_REDIR_APP) ? (O_WRONLY|O_CREAT|O_APPEND) : (O_WRONLY|O_CREAT|O_TRUNC);
            int fd = open(fn, flags, 0644);
            if (fd >= 0) { dup2(fd, STDOUT_FILENO); close(fd); }
            free(fn); break;
        }
        case OP_REDIR_IN: {
            char *fn = pop_str(vm);
            if (vm->saved_stdin == -1) vm->saved_stdin = dup(STDIN_FILENO);
            int fd = open(fn, O_RDONLY);
            if (fd >= 0) { dup2(fd, STDIN_FILENO); close(fd); }
            free(fn); break;
        }
        case OP_REDIR_ERR: {
            char *fn = pop_str(vm);
            int fd = open(fn, O_WRONLY|O_CREAT|O_TRUNC, 0644);
            if (fd >= 0) { dup2(fd, STDERR_FILENO); close(fd); }
            free(fn); break;
        }
        case OP_REDIR_RESTORE:
            if (vm->saved_stdin != -1) { dup2(vm->saved_stdin, STDIN_FILENO); close(vm->saved_stdin); vm->saved_stdin = -1; }
            if (vm->saved_stdout != -1) { dup2(vm->saved_stdout, STDOUT_FILENO); close(vm->saved_stdout); vm->saved_stdout = -1; }
            break;
        case OP_HEREDOC: {
            const char *delim = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "";
            SBuf sb; sb_init(&sb);
            char line[4096];
            while (fgets(line, sizeof(line), stdin)) {
                line[strcspn(line, "\n")] = 0;
                if (strcmp(line, delim) == 0) break;
                sb_append(&sb, line);
                sb_append_char(&sb, '\n');
            }
            char *content = sb_detach(&sb);
            push_str(vm, content);
            free(content);
            break;
        }

        /* pipe */
        case OP_PIPE: {
            /* 在子管道模式中, OP_PIPE 是结束标记 */
            if (vm->in_subpipe) { vm->running = 0; break; }
            int left_start = a;
            int pipefd[2];
            if (pipe(pipefd) == -1) { push_int(vm, 1); break; }
            fflush(NULL);
            pid_t pid = fork();
            if (pid == 0) {
                /* 子进程: 写端 -> stdout, 重跑到左命令起点 */
                close(pipefd[0]);
                dup2(pipefd[1], STDOUT_FILENO);
                close(pipefd[1]);
                /* 重置 VM 状态, 重新执行从 left_start 到当前 pc */
                /* 因为栈是当前 VM 的栈, 不能继续执行当前 OP_PIPE 之后的内容 */
                /* 用一个临时的子 VM 执行左侧代码段 */
                VM *sub = calloc(1, sizeof(VM));
                if (sub) {
                    sub->code = vm->code;
                    sub->code_size = vm->code_size;
                    for (int i = 0; i < vm->str_count; i++) sub->str_table[i] = vm->str_table[i];
                    sub->str_count = vm->str_count;
                    for (int i = 0; i < vm->func_count; i++) {
                        sub->functions[i].name = vm->functions[i].name;
                        sub->functions[i].addr = vm->functions[i].addr;
                        sub->functions[i].argc = vm->functions[i].argc;
                    }
                    sub->func_count = vm->func_count;
                    sub->saved_stdin = -1; sub->saved_stdout = -1;
                    sub->pc = left_start;
                    sub->script_name = vm->script_name;
                    sub->running = 1;
                    sub->in_subpipe = 1;  /* 在子管道中运行 */
                    vm_run(sub);
                    free(sub);
                }
                fflush(stdout);
                _exit(0);
            }
            /* 父进程: 读端 -> stdin */
            close(pipefd[1]);
            if (vm->saved_stdin == -1) vm->saved_stdin = dup(STDIN_FILENO);
            dup2(pipefd[0], STDIN_FILENO);
            close(pipefd[0]);
            int status; waitpid(pid, &status, 0);
            /* 恢复 stdin */
            if (vm->saved_stdin != -1) { dup2(vm->saved_stdin, STDIN_FILENO); close(vm->saved_stdin); vm->saved_stdin = -1; }
            push_int(vm, 0);
            break;
        }

        /* loops */
        case OP_FOR_BEGIN: {
            int count = pop_int(vm);
            char **items = malloc(sizeof(char *) * count);
            for (int i = count - 1; i >= 0; i--) items[i] = pop_str(vm);
            const char *vname = (a >= 0 && a < vm->str_count) ? vm->str_table[a].data : "";
            for_push(vname, items, count);
            for (int i = 0; i < count; i++) free(items[i]);
            free(items);
            for_begin(vm, vname); break;
        }
        case OP_FOR_NEXT:
            if (for_advance(vm)) { push_int(vm, 1); vm->pc = a; }
            else { push_int(vm, 0); for_pop(); }
            break;
        case OP_WHILE_BEG: if (vm->loop_sp < VM_CALL_DEPTH) vm->loop_stack[vm->loop_sp++] = vm->pc; break;
        case OP_WHILE_END: if (vm->loop_sp > 0) vm->loop_sp--; vm->pc = a; break;

        /* blocks */
        case OP_BLOCK_BEG: case OP_BLOCK_END: break;

        /* misc opcodes */
        case OP_CD: {
            char *path = pop_str(vm);
            /* cd - 回到上一个目录 */
            if (path && strcmp(path, "-") == 0) {
                /* 优先用 VM 自己的 OLDPWD, 否则用环境变量 */
                const char *oldpwd = get_var(vm, "OLDPWD");
                if (!oldpwd || !*oldpwd) oldpwd = getenv("OLDPWD");
                if (!oldpwd || !*oldpwd || chdir(oldpwd) != 0) {
                    fprintf(stderr, "bashc: cd: -: %s\n",
                            (!oldpwd || !*oldpwd) ? "OLDPWD not set" : strerror(errno));
                    free(path); push_int(vm, 1); break;
                }
                const char *cur_pwd = get_var(vm, "PWD");
                if (cur_pwd) set_var(vm, "OLDPWD", cur_pwd);
                char cwd[4096];
                if (getcwd(cwd, sizeof(cwd))) {
                    printf("%s\n", cwd);
                    set_var(vm, "PWD", cwd);
                }
                free(path); push_int(vm, 0); break;
            }
            if (!path || path[0] == 0) { free(path); const char *h = getenv("HOME"); path = strdup(h ? h : "/"); }
            /* 保存当前目录到 OLDPWD */
            char old_cwd[4096];
            const char *cur_pwd = get_var(vm, "PWD");
            if (!cur_pwd) { if (getcwd(old_cwd, sizeof(old_cwd))) cur_pwd = old_cwd; else cur_pwd = ""; }
            if (chdir(path) != 0) { fprintf(stderr, "bashc: cd: %s: %s\n", path, strerror(errno)); free(path); push_int(vm, 1); break; }
            set_var(vm, "OLDPWD", cur_pwd);
            char cwd[4096]; if (getcwd(cwd, sizeof(cwd))) set_var(vm, "PWD", cwd);
            push_int(vm, 0);
            free(path); break;
        }
        case OP_EXIT: { vm->exit_code = pop_int(vm); vm->running = 0; break; }
        case OP_SOURCE: {
            char *fn = pop_str(vm);
            VM *sub_vm = malloc(sizeof(VM));
            if (!sub_vm) { push_int(vm, 1); free(fn); break; }
            memset(sub_vm, 0, sizeof(VM));
            if (vm_init(sub_vm, fn) == 0) {
                for (int i = 0; i < vm->var_count; i++) set_var(sub_vm, vm->vars[i].name, vm->vars[i].value);
                vm_run(sub_vm); vm->exit_code = sub_vm->exit_code;
                for (int i = 0; i < sub_vm->var_count; i++) set_var(vm, sub_vm->vars[i].name, sub_vm->vars[i].value);
                vm_free(sub_vm);
            } else { fprintf(stderr, "bashc: source: %s: not found\n", fn); push_int(vm, 1); }
            free(sub_vm);
            free(fn); break;
        }
        case OP_PWD: { char cwd[4096]; if (getcwd(cwd, sizeof(cwd))) printf("%s\n", cwd); fflush(stdout); push_int(vm, 0); break; }
        case OP_BREAK: skip_mode = 1; skip_depth = 0; break;
        case OP_CONTINUE: skip_mode = 2; skip_depth = 0; break;

        /* alias / unalias */
        case OP_ALIAS: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "alias";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_ALIAS, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_UNALIAS: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "unalias";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_UNALIAS, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_EXEC_CMD: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "exec";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            builtin_dispatch(vm, BID_EXEC, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            break;
        }
        case OP_TYPE: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "type";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_TYPE, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_WAIT: { builtin_dispatch(vm, BID_WAIT, 1, NULL); push_int(vm, 0); break; }
        case OP_JOBS: { builtin_dispatch(vm, BID_JOBS, 1, NULL); push_int(vm, 0); break; }
        case OP_BG: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "bg";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_BG, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_FG: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "fg";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_FG, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_KILL: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "kill";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_KILL, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_UMASK: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "umask";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_UMASK, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_ULIMIT: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "ulimit";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_ULIMIT, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_TIMES: { builtin_dispatch(vm, BID_TIMES, 1, NULL); push_int(vm, 0); break; }
        case OP_TRAP: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "trap";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_TRAP, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_GETOPTS: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "getopts";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_GETOPTS, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_DECLARE: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "declare";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_DECLARE, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_LOCAL: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "local";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_LOCAL, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_MAPFILE: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "mapfile";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_MAPFILE, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_COMPGEN: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "compgen";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_COMPGEN, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_COMPLETE: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "complete";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_COMPLETE, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_ENABLE: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "enable";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_ENABLE, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_BUILTIN: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "builtin";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_BUILTIN, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_CALLER: { builtin_dispatch(vm, BID_CALLER, 1, NULL); push_int(vm, 0); break; }
        case OP_DIRS: { builtin_dispatch(vm, BID_DIRS, 1, NULL); push_int(vm, 0); break; }
        case OP_PUSHD: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "pushd";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_PUSHD, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_POPD: { builtin_dispatch(vm, BID_POPD, 1, NULL); push_int(vm, 0); break; }
        case OP_DISOWN: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "disown";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_DISOWN, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_SHOPT: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "shopt";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_SHOPT, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_SUSPEND: { builtin_dispatch(vm, BID_SUSPEND, 1, NULL); push_int(vm, 0); break; }
        case OP_TEST_CMD: {
            int count = a; if (count > 255) count = 255;
            char *args[256]; args[0] = "test";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_TEST, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_HASH: { builtin_dispatch(vm, BID_HASH, 1, NULL); push_int(vm, 0); break; }
        case OP_BIND: { builtin_dispatch(vm, BID_BIND, 1, NULL); push_int(vm, 0); break; }
        case OP_HELP: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "help";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_HELP, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }
        case OP_HISTORY: { builtin_dispatch(vm, BID_HISTORY, 1, NULL); push_int(vm, 0); break; }
        case OP_LOGOUT: { builtin_dispatch(vm, BID_LOGOUT, 1, NULL); break; }
        case OP_SET: {
            int count = pop_int(vm);
            char *args[256]; args[0] = "set";
            for (int i = count - 1; i >= 0; i--) args[i + 1] = pop_str(vm);
            int rc = builtin_dispatch(vm, BID_SET, count + 1, args);
            for (int i = 0; i < count; i++) free(args[i + 1]);
            push_int(vm, rc);
            break;
        }

        default:
            fprintf(stderr, "bashc_vm: unknown opcode 0x%02X at pc=%d\n", op, vm->pc - 1);
            vm->running = 0; break;
        }
    }
}

void vm_free(VM *vm) {
    for (int i = 0; i < vm->sp; i++) free_value(&vm->stack[i]);
    for (int i = 0; i < vm->str_count; i++) free(vm->str_table[i].data);
    free(vm->code);
    for (int i = 0; i < vm->var_count; i++) { free(vm->vars[i].name); free(vm->vars[i].value); }
    for (int i = 0; i < vm->func_count; i++) free(vm->functions[i].name);
    for (int i = 0; i < vm->array_count; i++) {
        free(vm->arrays[i].name);
        for (int j = 0; j < vm->arrays[i].count; j++) free(vm->arrays[i].values[j]);
    }
    for (int i = 0; i < vm->alias_count; i++) { free(vm->aliases[i].name); free(vm->aliases[i].value); }
    for (int i = 0; i < vm->positional_count; i++) free(vm->positional[i]);
    if (vm->saved_stdin != -1) close(vm->saved_stdin);
    if (vm->saved_stdout != -1) close(vm->saved_stdout);
    while (for_sp > 0) for_pop();
    while (dir_sp > 0) { free(dir_stack[--dir_sp]); dir_stack[dir_sp] = NULL; }
    memset(vm, 0, sizeof(*vm));
}

/* ========== main ========== */

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "Usage: %s <program.bc>\n", argv[0]); return 1; }
    /* 把当前 .bc 路径设为 PARENT_BC, 让 $(...) 命令替换能合并父 .bc + cmd .bc */
    if (!getenv("BASHC_PARENT_BC")) setenv("BASHC_PARENT_BC", argv[1], 1);
    /* 告诉子进程从哪找 bashc_compile / bashc_vm 二进制 */
    if (!getenv("BASHC_BIN")) {
        char self[1024] = ".";
        /* 从 argv[0] 推断目录 */
        const char *a = argv[0];
        const char *slash = strrchr(a, '/');
        if (slash) { int n = slash - a; if (n > 0 && n < 1024) { memcpy(self, a, n); self[n] = 0; } }
        setenv("BASHC_BIN", self, 1);
    }
    VM *vm = malloc(sizeof(VM));
    if (!vm) { fprintf(stderr, "bashc_vm: out of memory\n"); return 1; }
    if (vm_init(vm, argv[1]) != 0) { free(vm); return 1; }
    vm_run(vm);
    int exit_code = vm->exit_code;
    vm_free(vm);
    free(vm);
    return exit_code;
}