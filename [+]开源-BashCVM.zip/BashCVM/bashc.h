/*
 * Copyright (c) [2026] 难忘 743225426@qq.com
 *
 * This file is part of [Project Name], licensed under the Custom Source
 * Code License v1.0. You may use, modify, and distribute this file,
 * including in closed-source form, provided that this copyright and
 * license header is fully retained and no commercial charge is made.
 * See the LICENSE file for full terms.
 */
 
/*
 * bashc.h — Bash 字节码 VM 共享定义
 * 编译器: bashc_compile.c (bash → .bc)
 * 虚拟机: bashc_vm.c     (.bc → 执行)
 */

#ifndef BASHC_H
#define BASHC_H

#include <stdint.h>

/* ========== 字节码文件格式 ==========
 * [4B 魔数 "BCVM"]
 * [4B 版本号]
 * [4B 字符串表条目数 N]
 * [N 条: [4B 长度] [长度B 数据]]
 * [4B 代码段字节数]
 * [代码段: 指令流]
 *
 * 每条指令: [1B 操作码] [N*4B 操作数]
 * 操作码决定操作数个数 (0~2)
 */

#define BASHC_MAGIC   0x4D564342  /* "BCVM" */
#define BASHC_VERSION 2

/* ========== 操作码定义 ========== */
typedef enum {
    OP_NOP       = 0x00,  /* 无操作           [0 操作数] */
    OP_HALT      = 0x01,  /* 停止执行          [0] */

    /* --- 栈操作 --- */
    OP_PUSH_STR  = 0x10,  /* 压入字符串常量     [1: str_idx] */
    OP_PUSH_INT  = 0x11,  /* 压入整数常量       [1: int_val] */
    OP_POP       = 0x12,  /* 弹出栈顶          [0] */
    OP_DUP       = 0x13,  /* 复制栈顶          [0] */

    /* --- 变量操作 --- */
    OP_STORE     = 0x20,  /* 弹出值存入变量     [1: name_idx] */
    OP_LOAD      = 0x21,  /* 加载变量值压栈     [1: name_idx] */
    OP_EXPORT    = 0x22,  /* export 变量       [1: name_idx] */
    OP_EXPAND    = 0x23,  /* 弹出字符串,展开$var [0] */
    OP_EXPAND_PAT = 0x24, /* ${var//pat/repl}  [2: pat_idx, repl_idx] */
    OP_EXPAND_ALL = 0x25, /* 弹出字符串,展开所有  [0] */
    OP_SHIFT     = 0x26,  /* shift 移位参数    [1: n] */
    OP_UNSET     = 0x27,  /* 删除变量          [1: name_idx] */

    /* --- 算术运算 --- */
    OP_ADD       = 0x30,  /* b=pop a=pop push(b+a) [0] */
    OP_SUB       = 0x31,  /* b=pop a=pop push(b-a) [0] */
    OP_MUL       = 0x32,  /* b=pop a=pop push(b*a) [0] */
    OP_DIV       = 0x33,  /* b=pop a=pop push(b/a) [0] */
    OP_MOD       = 0x34,  /* b=pop a=pop push(b%a) [0] */
    OP_NEG       = 0x35,  /* push(-pop)        [0] */
    OP_NOT       = 0x36,  /* push(!pop)        [0] */
    OP_BIT_AND   = 0x37,  /* push(pop & pop)  [0] */
    OP_CMP_LT    = 0x38,  /* b=pop a=pop push(b<a)  [0] */
    OP_CMP_GT    = 0x39,  /* b=pop a=pop push(b>a)  [0] */
    OP_CMP_LE    = 0x3A,  /* b=pop a=pop push(b<=a) [0] */
    OP_CMP_GE    = 0x3B,  /* b=pop a=pop push(b>=a) [0] */
    OP_CMP_EQ    = 0x3C,  /* b=pop a=pop push(b==a) [0] */
    OP_CMP_NE    = 0x3D,  /* b=pop a=pop push(b!=a) [0] */
    OP_BIT_OR    = 0x3E,  /* push(pop | pop)  [0] */
    OP_BIT_XOR   = 0x3F,  /* push(pop ^ pop)  [0] */

    /* --- 输出 --- */
    OP_ECHO      = 0x40,  /* 弹出 argc 个参数打印  [1: argc] */
    OP_ECHO_N    = 0x41,  /* 同上但不换行         [1: argc] */
    OP_PRINTF    = 0x46,  /* printf 格式化输出   [1: argc] */

    /* --- 命令执行 --- */
    OP_EXEC      = 0x42,  /* 弹出 argc 个参数执行  [1: argc] */
    OP_EXEC_BUILTIN = 0x43, /* 执行内建命令      [1: argc] */
    OP_TEST      = 0x44,  /* test/[ 条件测试     [1: argc] */
    OP_READ      = 0x45,  /* read 读入变量       [1: name_idx] */
    OP_LET       = 0x47,  /* let 算术求值       [1: argc] */

    /* --- 控制流 --- */
    OP_JMP       = 0x50,  /* 无条件跳转          [1: offset] */
    OP_JZ        = 0x51,  /* 栈顶为0跳转         [1: offset] */
    OP_JNZ       = 0x52,  /* 栈顶非0跳转         [1: offset] */
    OP_CALL      = 0x53,  /* 调用子程序          [1: addr] */
    OP_RET       = 0x54,  /* 返回               [0] */
    OP_RETURN    = 0x55,  /* return N (带退出码) [0] 弹出N */
    OP_CASE      = 0x56,  /* case 匹配          [1: str_idx] 弹出值 */
    OP_CASE_END  = 0x57,  /* case 结束          [0] */

    /* --- 重定向 --- */
    OP_REDIR_OUT = 0x60,  /* 弹出文件名,重定向stdout [0] */
    OP_REDIR_IN  = 0x61,  /* 弹出文件名,重定向stdin  [0] */
    OP_REDIR_APP = 0x62,  /* 弹出文件名,追加重定向  [0] */
    OP_REDIR_RESTORE = 0x63, /* 恢复stdin/stdout   [0] */
    OP_REDIR_ERR = 0x65,  /* 2> stderr重定向    [0] */
    OP_HEREDOC   = 0x66,  /* << here-doc       [1: str_idx] */

    /* --- 管道 --- */
    OP_PIPE      = 0x64,  /* 弹出右半地址,管道连接  [0] */

    /* --- 循环 --- */
    OP_FOR_BEGIN = 0x70,  /* 开始for循环        [1: var_idx] 弹出列表 */
    OP_FOR_NEXT  = 0x71,  /* 取下一项           [1: end_pc] */
    OP_WHILE_BEG = 0x72,  /* 标记while条件检查点 [0] */
    OP_WHILE_END = 0x73,  /* while循环尾        [1: cond_pc] */
    OP_SELECT_BEG = 0x74,  /* select 开始       [1: var_idx] */
    OP_SELECT_END = 0x75,  /* select 结束       [0] */

    /* --- 块 --- */
    OP_BLOCK_BEG = 0x80,  /* 匿名块开始         [0] */
    OP_BLOCK_END = 0x81,  /* 匿名块结束         [0] */

    /* --- 函数 --- */
    OP_FUNC_DEF  = 0x82,  /* 定义函数           [1: name_idx, 1: addr] */
    OP_FUNC_CALL = 0x83,  /* 调用函数           [1: name_idx] */

    /* --- 数组 --- */
    OP_ARRAY_SET = 0x84,  /* 数组赋值           [1: name_idx] 弹出 idx,val */
    OP_ARRAY_GET = 0x85,  /* 数组取值           [1: name_idx] 弹出 idx */

    /* --- 杂项 --- */
    OP_CD        = 0x90,  /* cd 命令            [0] 弹出路径 */
    OP_EXIT      = 0x91,  /* exit               [0] 弹出退出码 */
    OP_SOURCE    = 0x92,  /* source 命令        [0] 弹出文件名 */
    OP_PWD       = 0x93,  /* pwd               [0] */
    OP_BREAK     = 0x94,  /* break             [0] */
    OP_CONTINUE  = 0x95,  /* continue          [0] */
    OP_ALIAS     = 0x96,  /* alias 定义        [0] */
    OP_UNALIAS   = 0x97,  /* unalias          [0] */
    OP_EXEC_CMD  = 0x98,  /* exec 替换进程     [0] */
    OP_TYPE      = 0x99,  /* type 命令类型     [0] */
    OP_WAIT      = 0x9A,  /* wait 等待子进程   [0] */
    OP_JOBS      = 0x9B,  /* jobs 后台任务     [0] */
    OP_BG        = 0x9C,  /* bg 后台运行       [0] */
    OP_FG        = 0x9D,  /* fg 前台运行       [0] */
    OP_KILL      = 0x9E,  /* kill 发送信号     [0] */
    OP_UMASK     = 0x9F,  /* umask 文件掩码    [0] */
    OP_ULIMIT    = 0xA0,  /* ulimit 资源限制   [0] */
    OP_TIMES     = 0xA1,  /* times 时间统计    [0] */
    OP_TRAP      = 0xA2,  /* trap 信号捕获     [0] */
    OP_GETOPTS   = 0xA3,  /* getopts 参数解析  [0] */
    OP_DECLARE   = 0xA4,  /* declare/typeset  [0] */
    OP_LOCAL     = 0xA5,  /* local 局部变量    [0] */
    OP_MAPFILE   = 0xA6,  /* mapfile/readarray [0] */
    OP_COMPGEN   = 0xA7,  /* compgen 补全      [0] */
    OP_COMPLETE  = 0xA8,  /* complete 补全定义  [0] */
    OP_ENABLE    = 0xA9,  /* enable 启用/禁用   [0] */
    OP_BUILTIN   = 0xAA,  /* builtin 强制内建   [0] */
    OP_CALLER    = 0xAB,  /* caller 调用栈     [0] */
    OP_DIRS      = 0xAC,  /* dirs 目录栈       [0] */
    OP_PUSHD     = 0xAD,  /* pushd 压入目录    [0] */
    OP_POPD      = 0xAE,  /* popd 弹出目录     [0] */
    OP_DISOWN    = 0xAF,  /* disown 脱离作业   [0] */
    OP_SHOPT     = 0xB0,  /* shopt shell选项   [0] */
    OP_SUSPEND   = 0xB1,  /* suspend 挂起     [0] */
    OP_TEST_CMD  = 0xB2,  /* test 命令         [0] */
    OP_HASH      = 0xB3,  /* hash 命令缓存     [0] */
    OP_BIND      = 0xB4,  /* bind 键绑定       [0] */
    OP_HELP      = 0xB5,  /* help 帮助         [0] */
    OP_HISTORY   = 0xB6,  /* history 历史      [0] */
    OP_LOGOUT    = 0xB7,  /* logout 登出       [0] */
    OP_SET       = 0xB8,  /* set shell选项     [0] */

    OP_MAX
} Opcode;

/* 操作码的操作数个数 */
static inline int opcode_operand_count(Opcode op) {
    switch (op) {
        /* 0 operands */
        case OP_NOP: case OP_HALT: case OP_POP: case OP_DUP:
        case OP_EXPAND: case OP_EXPAND_ALL:
        case OP_ADD: case OP_SUB: case OP_MUL: case OP_DIV: case OP_MOD:
        case OP_NEG: case OP_NOT: case OP_BIT_AND: case OP_BIT_OR: case OP_BIT_XOR:
        case OP_CMP_LT: case OP_CMP_GT: case OP_CMP_LE: case OP_CMP_GE:
        case OP_CMP_EQ: case OP_CMP_NE:
        case OP_RET: case OP_CASE_END:
        case OP_REDIR_OUT: case OP_REDIR_IN: case OP_REDIR_APP:
        case OP_REDIR_RESTORE: case OP_REDIR_ERR: case OP_PIPE:
        case OP_WHILE_BEG: case OP_SELECT_END:
        case OP_BLOCK_BEG: case OP_BLOCK_END:
        case OP_PWD: case OP_BREAK: case OP_CONTINUE:
        case OP_ALIAS: case OP_UNALIAS: case OP_EXEC_CMD: case OP_TYPE:
        case OP_WAIT: case OP_JOBS: case OP_BG: case OP_FG: case OP_KILL:
        case OP_UMASK: case OP_ULIMIT: case OP_TIMES: case OP_TRAP:
        case OP_GETOPTS: case OP_DECLARE: case OP_LOCAL: case OP_MAPFILE:
        case OP_COMPGEN: case OP_COMPLETE: case OP_ENABLE: case OP_BUILTIN:
        case OP_CALLER: case OP_DIRS: case OP_PUSHD: case OP_POPD:
        case OP_DISOWN: case OP_SHOPT: case OP_SUSPEND: case OP_TEST_CMD:
        case OP_HASH: case OP_BIND: case OP_HELP: case OP_HISTORY:
        case OP_LOGOUT: case OP_SET:
            return 0;
        /* 1 operand */
        case OP_PUSH_STR: case OP_PUSH_INT:
        case OP_STORE: case OP_LOAD: case OP_EXPORT:
        case OP_ECHO: case OP_ECHO_N: case OP_PRINTF:
        case OP_EXEC: case OP_EXEC_BUILTIN:
        case OP_TEST: case OP_READ: case OP_LET:
        case OP_JMP: case OP_JZ: case OP_JNZ: case OP_CALL:
        case OP_CASE: case OP_HEREDOC:
        case OP_FOR_BEGIN: case OP_FOR_NEXT: case OP_WHILE_END:
        case OP_SELECT_BEG:
        case OP_FUNC_DEF: case OP_FUNC_CALL:
        case OP_ARRAY_SET: case OP_ARRAY_GET:
        case OP_CD: case OP_EXIT: case OP_SOURCE:
        case OP_SHIFT: case OP_UNSET: case OP_RETURN:
            return 1;
        /* 2 operands */
        case OP_EXPAND_PAT:
            return 2;
        default:
            return 0;
    }
}

/* 指令的字节大小 */
static inline int opcode_size(Opcode op) {
    return 1 + 4 * opcode_operand_count(op);
}

/* ========== 内置命令表 ========== */
#define BASHC_BUILTIN_COUNT 128

/* 内置命令 ID 枚举 */
typedef enum {
    BID_ECHO = 0,    BID_CD,       BID_PWD,      BID_EXIT,
    BID_READ,        BID_EXPORT,   BID_UNSET,    BID_TRUE,
    BID_FALSE,       BID_BREAK,    BID_CONTINUE, BID_SOURCE,
    BID_EVAL,        BID_EXEC,     BID_SHIFT,    BID_SET,
    BID_PRINTF,      BID_LET,      BID_ALIAS,    BID_UNALIAS,
    BID_TYPE,        BID_WAIT,     BID_JOBS,     BID_BG,
    BID_FG,          BID_KILL,     BID_UMASK,    BID_ULIMIT,
    BID_TIMES,       BID_TRAP,     BID_GETOPTS,  BID_DECLARE,
    BID_LOCAL,       BID_MAPFILE,  BID_COMPGEN,  BID_COMPLETE,
    BID_ENABLE,      BID_BUILTIN,  BID_CALLER,   BID_DIRS,
    BID_PUSHD,       BID_POPD,     BID_DISOWN,   BID_SHOPT,
    BID_SUSPEND,     BID_TEST,     BID_HASH,     BID_BIND,
    BID_HELP,        BID_HISTORY,  BID_LOGOUT,
    /* 扩展内置命令 (文件/文本操作) */
    BID_CAT,         BID_CP,       BID_MV,       BID_RM,
    BID_MKDIR,       BID_RMDIR,    BID_TOUCH,    BID_CHMOD,
    BID_CHOWN,       BID_LN,       BID_STAT,     BID_BASENAME,
    BID_DIRNAME,     BID_REALPATH, BID_MKTEMP,   BID_TEE,
    BID_HEAD,        BID_TAIL,     BID_WC,       BID_TR,
    BID_CUT,         BID_SORT,     BID_UNIQ,     BID_DIFF,
    BID_FIND,        BID_GREP,     BID_DU,       BID_DF,
    BID_WHICH,       BID_WHEREIS,  BID_FILE,     BID_SEQ,
    BID_SLEEP,       BID_DATE,     BID_ENV,      BID_PRINTENV,
    BID_HOSTNAME,    BID_ID,       BID_WHOAMI,   BID_UNAME,
    BID_TTY,         BID_CLEAR,    BID_RESET,    BID_YES,
    BID_XARGS,       BID_PASTE,    BID_SHA1SUM,  BID_SHA256SUM,
    BID_MD5SUM,      BID_BASE64,   BID_COMM,     BID_JOIN,
    BID_NL,          BID_OD,       BID_PASTE_CMD,BID_EXPAND,
    BID_EXPR,        BID_CMP,      BID_DD,       BID_SPLIT,
    BID_CSCOPE,      BID_CTAGS,    BID_NM,       BID_SIZE,
    BID_STRINGS,     BID_STRIP,    BID_AR,       BID_RANLIB,
    BID_OBJDUMP,     BID_READELF,  BID_GDB,      BID_MAKE,
    BID_MAX
} BuiltinID;

/* 内置命令名称映射 */
typedef struct {
    const char *name;
    BuiltinID   id;
} BuiltinEntry;

/* ========== 编译器结构 ========== */
#define MAX_STR_TABLE   8192
#define MAX_CODE        131072
#define MAX_BC_LINE     4096
#define MAX_FUNCTIONS   256
#define MAX_ARRAYS      256
#define MAX_ARRAY_SIZE  4096

typedef struct {
    char  *data;
    int    len;
} BCString;

typedef struct {
    char *name;
    int   addr;  /* 函数入口地址 */
    int   argc;  /* 参数个数 */
} BCFunction;

typedef struct {
    char  *name;
    char  *values[MAX_ARRAY_SIZE];
    int    count;
} BCArray;

typedef struct {
    BCString strings[MAX_STR_TABLE];
    int      str_count;

    uint8_t  code[MAX_CODE];
    int      code_size;

    /* 标签系统: 用于前向跳转 */
    int      labels[MAX_CODE];
    int      label_count;

    /* 函数表 */
    BCFunction functions[MAX_FUNCTIONS];
    int         func_count;
} Compiler;

/* ========== VM 结构 ========== */
#define VM_STACK_SIZE   4096
#define VM_VARS_MAX     512
#define VM_CALL_DEPTH   256

typedef struct {
    int      type;  /* 0=int, 1=str */
    int      ival;
    char    *sval;
} VMValue;

typedef struct {
    char    *name;
    char    *value;
} VMVar;

typedef struct {
    /* 字节码 */
    uint8_t *code;
    int      code_size;
    int      pc;        /* 程序计数器 */

    /* 字符串表 */
    BCString str_table[MAX_STR_TABLE];
    int      str_count;

    /* 栈 */
    VMValue  stack[VM_STACK_SIZE];
    int      sp;        /* 栈指针 */

    /* 变量 */
    VMVar    vars[VM_VARS_MAX];
    int      var_count;

    /* 函数表 */
    BCFunction functions[MAX_FUNCTIONS];
    int         func_count;

    /* 数组 */
    BCArray  arrays[MAX_ARRAYS];
    int      array_count;

    /* 调用栈 */
    int      call_stack[VM_CALL_DEPTH];
    int      call_sp;

    /* 每个函数调用的位置参数保存 (恢复时使用) */
    char    *saved_pos_stack[VM_CALL_DEPTH][256];
    int      saved_pos_count_stack[VM_CALL_DEPTH];

    /* 循环栈 (break/continue) */
    int      loop_stack[VM_CALL_DEPTH];
    int      loop_sp;

    /* 重定向保存 */
    int      saved_stdin;
    int      saved_stdout;

    /* 别名表 */
    VMVar    aliases[256];
    int      alias_count;

    /* 运行状态 */
    int      running;
    int      exit_code;
    int      in_subpipe;  /* 子进程执行左管道段时为 1, 遇到 OP_PIPE 停止 */

    /* 位置参数 */
    char    *positional[256];
    int      positional_count;

    /* 脚本名 ($0) */
    char    *script_name;
} VM;

/* ========== 工具函数声明 ========== */
int  compiler_init(Compiler *c);
int  compiler_add_string(Compiler *c, const char *s);
int  compiler_emit(Compiler *c, Opcode op, int32_t a, int32_t b);
int  compiler_emit_label(Compiler *c);
void compiler_patch_jump(Compiler *c, int jump_addr, int target_label);
int  compiler_emit_jump_with_patch(Compiler *c, Opcode op);
int  compiler_get_pc(Compiler *c);
void compiler_patch_here(Compiler *c, int jump_addr);
int  compiler_add_function(Compiler *c, const char *name, int addr);
int  compiler_save(Compiler *c, const char *filename);
void compiler_dump(Compiler *c);

int  vm_init(VM *vm, const char *bc_file);
void vm_run(VM *vm);
void vm_free(VM *vm);

/* 字符串表索引 */
int  compiler_find_string(Compiler *c, const char *s);

/* 内置命令表 */
extern const BuiltinEntry builtin_table[];
extern const int builtin_table_size;

#endif /* BASHC_H */