# BashcVM —— Bash 字节码编译器 + 虚拟机

一个从零自制的 类Bash 解释器实现，采用「**编译器 + 栈式字节码虚拟机**」两层架构：

1. `bashc_compile`：把 Bash 脚本编译成自定义字节码文件（`.bc`）
2. `bashc_vm`：加载 `.bc` 字节码并解释执行

目标：用纯 C 复刻 Bash 的核心语法与内置命令，让常见 Bash 脚本无需系统 Bash 也能运行。

---

## 一、项目结构

| 文件 | 作用 |
|------|------|
| `bashc.h` | 共享头文件：操作码定义、字节码文件格式、内置命令表、VM/编译器共用结构 |
| `bashc_compile.c` | Bash → 字节码编译器（词法切分、语法解析、指令生成） |
| `bashc_vm.c` | 字节码虚拟机（指令循环、内置命令实现、进程管理） |
| `bashc_lib.c` | 编译器辅助库（字符串表、函数表、指令发射） |
| `Makefile` | 构建脚本 |

---

## 二、构建

依赖：仅需 GCC（Linux）。

```bash
make            # 生成 bashc_compile 与 bashc_vm
make clean      # 清理产物
```

---

## 三、使用方法

```bash
# 编译 Bash 脚本为字节码
./bashc_compile 你的脚本.sh 你的脚本.bc

# 运行字节码
./bashc_vm 你的脚本.bc
```

示例：

```bash
./bashc_compile sample4.sh sample4.bc
./bashc_vm sample4.bc
```

---

## 四、架构设计

### 1. 编译阶段（bashc_compile）

- 按行读取脚本，词法阶段按 `;` 把 `then/do/elif/fi/done/else/esac` 等关键字切分为独立行，便于结构识别
- 递归下降解析：if/elif/else、for/while/until、case、函数、管道、重定向、算术表达式
- 支持单行 `if ...; then ...; else ...; fi` 快速路径
- 中文函数名、`function` 关键字、同行 `{ ... }` 函数体均支持
- 变量赋值 `x=$((...))` 会编译为算术表达式求值，而非字面字符串
- 输出指令统一为 `OP_EXEC_BUILTIN`，由 VM 端的内建处理器统一处理（`echo -e`/`-n` 等）

### 2. 运行阶段（bashc_vm）

- 栈式指令循环，操作码 0/1/2 个操作数
- 变量表：普通变量 + 特殊变量（`$?` `$$` `$#` `$0` `$@` `$*` `$1..$9`）
- 函数调用：位置参数栈传递参数，`saved_pos_stack` 保存/恢复调用者参数
- `$(...)` 命令替换：把子命令编译为临时字节码，与父字节码合并（字符串表偏移、跳转地址重映射），fork + exec 子 VM 执行并捕获 stdout
- 管道：`OP_PIPE` 携带左段地址，fork 后子进程用子 VM 重跑左段
- 重定向、here-doc、目录栈（pushd/popd/dirs）、后台作业等均有实现

### 3. 字节码文件格式

```
[4B 魔数 "BCVM"]
[4B 版本号]
[4B 字符串表条目数 N]
[N 条: [4B 长度] [长度B 数据]]
[4B 函数表条目数 M]
[M 条: [4B name_idx] [4B addr] [4B argc]]
[4B 代码段字节数]
[代码段: 指令流]
```

每条指令：`[1B 操作码] [N×4B 操作数]`，操作码决定操作数个数（0~2）。

### 4. 操作码体系（节选）

| 类别 | 操作码 |
|------|--------|
| 栈操作 | `OP_PUSH_STR` `OP_PUSH_INT` `OP_POP` `OP_DUP` |
| 变量 | `OP_STORE` `OP_LOAD` `OP_EXPORT` `OP_EXPAND` `OP_SHIFT` `OP_UNSET` |
| 算术 | `OP_ADD` `OP_SUB` `OP_MUL` `OP_DIV` `OP_MOD` `OP_NEG` `OP_NOT` 及位运算/比较 |
| 输出 | `OP_ECHO` `OP_ECHO_N` `OP_PRINTF` |
| 命令执行 | `OP_EXEC` `OP_EXEC_BUILTIN` `OP_TEST` `OP_READ` `OP_LET` |
| 控制流 | `OP_JMP` `OP_JZ` `OP_JNZ` `OP_CALL` `OP_RET` `OP_RETURN` |
| 重定向 | `OP_REDIR_OUT` `OP_REDIR_IN` `OP_REDIR_APP` `OP_REDIR_RESTORE` `OP_HEREDOC` |
| 管道 | `OP_PIPE` |
| 循环 | `OP_FOR_BEGIN` `OP_FOR_NEXT` `OP_WHILE_BEG` `OP_WHILE_END` `OP_SELECT_BEG/END` |
| 函数 | `OP_FUNC_DEF` `OP_FUNC_CALL` |
| 杂项 | `OP_CD` `OP_EXIT` `OP_SOURCE` `OP_PWD` `OP_BREAK` `OP_CONTINUE` 等 100+ 内置命令 |

---

## 五、支持的特性

- **变量与参数**：赋值、`export`/`unset`、特殊变量（`$?` `$$` `$#` `$0` `$@` `$*` `$1..$9`）、`shift`、`local`
- **算术**：`$((...))` 完整表达式 —— 加减乘除、括号、负号、位运算、移位、比较、逻辑、三元、变量引用、`+=` `-=` `*=` `/=` `%=`
- **控制流**：`if/elif/else/fi`（含单行）、`for`、`while`、`until`、`case/esac`、`break`、`continue`、嵌套
- **条件测试**：`test` / `[ ]` / `[[ ]]`，支持 `=` `!=` `-n` `-z` `-eq` `-ne` `-lt` `-gt` `-le` `-ge` 及组合条件（`-a` `-o`）
- **函数**：中文/普通函数名、`function` 关键字、参数传递、`return` 退出码
- **命令替换**：`$(...)`（含函数调用）
- **管道与重定向**：`|`、`>`、`>>`、`<`、`2>`、here-doc
- **输出**：`echo`（含 `-e`/`-n`、`\033` 八进制、`\x` 十六进制转义）、`printf` 格式化
- **内置命令**：`cd`（含 `cd -`）、`pwd`、`read`、`export`、`unset`、`true`/`false`、`:`、`type`、`let` 等 100+ 内置命令
- **文本处理**：`cat` `cp` `mv` `rm` `mkdir` `touch` `chmod` 等扩展内置命令

---

## 六、验证情况

已使用 177 行的中文综合测试脚本（含中文函数名、颜色输出、特殊变量、参数扩展、算术、函数、while/for/if 嵌套、test 组合条件等）完整跑通，`EXIT=0`。

覆盖项包括：颜色函数输出、Hello World、文件路径、PID/脚本名/参数个数/退出码、变量与参数扩展、波浪号展开、`cd -`、`printf`、`read`、test 全套比较、重定向、双层 while、for-if 嵌套、if-for 嵌套、test 组合条件、边界输入（空/大数/嵌套）等。

---

## 七、已知限制

- `printf` 多参数格式化时参数取自栈的顺序仍需修正
- `read` 在管道子进程中读不到值（与 Bash 子 shell 语义一致）
- 部分 `$(...)` 场景（函数内嵌命令替换）输出可能缺失
- 单行多条命令（`echo a; echo b` 同行）暂按整行处理，未按 `;` 切分

---

## 八、License / 说明

个人学习/研究项目，纯 C 实现，无第三方依赖。
许可证请看LICENSE/LICENSE.zh