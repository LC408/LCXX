/*
 * Copyright (c) [2026] 难忘 743225426@qq.com
 *
 * This file is part of [Project Name], licensed under the Custom Source
 * Code License v1.0. You may use, modify, and distribute this file,
 * including in closed-source form, provided that this copyright and
 * license header is fully retained and no commercial charge is made.
 * See the LICENSE file for full terms.
 */
 
/*
 * bashc_compile.c — Bash-to-bytecode compiler (extended)
 * Compile: gcc -o bashc_compile bashc_compile.c bashc_lib.o -I.
 * Usage:   ./bashc_compile input.sh output.bc
 *
 * Supports: echo, pipes, redirects, for/while/until, if/elif/else/fi,
 *           &&, ||, variable assignment, anonymous blocks, arithmetic,
 *           test/[ ]/[[ ]], case/esac, select, function definitions,
 *           arrays, here-docs, and 100+ builtin commands.
 */

#include "bashc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* compiler_add_function 声明（定义在 bashc_lib.c） */
extern int compiler_add_function(Compiler *c, const char *name, int addr);

/* ========== 常量 ========== */
#define MAX_LINE      4096
#define MAX_ARGS      128
#define MAX_LINES     16384
#define MAX_CLAUSES   64
#define MAX_BRANCHES  64
#define MAX_HEREDOC_BODY (MAX_LINE * 10)

/* ========== 行存储 ========== */
typedef struct {
    char *line;
    int   line_number;
} ScriptLine;

static ScriptLine script_lines[MAX_LINES];
static int        script_line_count = 0;
static Compiler   *comp = NULL;

/* ========== 前向声明 ========== */
static void compile_script(const char *input_file, const char *output_file);
static void compile_lines(int start, int end);
static void compile_line(const char *line);
static int  compile_condition(const char *cond);
static void compile_expression(const char *expr);
static void compile_args(char **args, int start);
static int  tokenize_cmd(char *line, char *args[], int max_args);
static void strip_comment(char *line);
static char *find_unquoted_char(char *str, char target);
static char *find_unquoted_substr(char *str, const char *target);
static int  find_matching_done(int start);
static int  find_matching_fi(int start);
static int  find_matching_esac(int start);
static int  find_matching_brace(int start_line);
static int  find_function(const char *name);
static int  is_builtin_command(const char *name);
static int  builtin_dedicated_opcode(const char *name);

/* ========== 算术表达式递归下降解析（生成字节码）========== */

/* 跳过空白 */
static const char *expr_skip(const char *p) {
    while (*p && isspace(*p)) p++;
    return p;
}

/* 主表达式: 比较运算 */
static const char *compile_expr_compare(const char *p);

/* primary: 数字、变量、$(()) 嵌套、括号 */
static const char *compile_expr_primary(const char *p) {
    p = expr_skip(p);
    if (*p == '(') {
        p++;
        p = compile_expr_compare(p);
        if (*p == ')') p++;
        return p;
    }
    if (*p == '-' || *p == '+' || *p == '~' || *p == '!') {
        /* 一元运算符 */
        char op = *p;
        p++;
        p = compile_expr_primary(p);
        switch (op) {
            case '-': compiler_emit(comp, OP_NEG, 0, 0); break;
            case '!': compiler_emit(comp, OP_NOT, 0, 0); break;
            /* + 和 ~ 暂不处理 */
            default: break;
        }
        return p;
    }
    if (*p == '$') {
        p++;
        char vname[MAX_LINE];
        int i = 0;
        while (*p && (isalnum(*p) || *p == '_')) vname[i++] = *p++;
        vname[i] = 0;
        if (i > 0) {
            int idx = compiler_add_string(comp, vname);
            compiler_emit(comp, OP_LOAD, idx, 0);
        } else {
            compiler_emit(comp, OP_PUSH_INT, 0, 0);
        }
        return p;
    }
    if (isalpha(*p) || *p == '_') {
        /* $(( )) 内可直接使用变量名 */
        char vname[MAX_LINE];
        int i = 0;
        while (*p && (isalnum(*p) || *p == '_')) vname[i++] = *p++;
        vname[i] = 0;
        int idx = compiler_add_string(comp, vname);
        compiler_emit(comp, OP_LOAD, idx, 0);
        return p;
    }
    if (isdigit(*p)) {
        int val = 0;
        while (*p && isdigit(*p)) {
            val = val * 10 + (*p - '0');
            p++;
        }
        compiler_emit(comp, OP_PUSH_INT, val, 0);
        return p;
    }
    compiler_emit(comp, OP_PUSH_INT, 0, 0);
    return p;
}

/* 乘除取模 */
static const char *compile_expr_term(const char *p) {
    p = compile_expr_primary(p);
    while (1) {
        p = expr_skip(p);
        char op = *p;
        if (op != '*' && op != '/' && op != '%') break;
        p++;
        p = compile_expr_primary(p);
        switch (op) {
            case '*': compiler_emit(comp, OP_MUL, 0, 0); break;
            case '/': compiler_emit(comp, OP_DIV, 0, 0); break;
            case '%': compiler_emit(comp, OP_MOD, 0, 0); break;
        }
    }
    return p;
}

/* 加减 */
static const char *compile_expr_addsub(const char *p) {
    p = compile_expr_term(p);
    while (1) {
        p = expr_skip(p);
        char op = *p;
        if (op != '+' && op != '-') break;
        p++;
        p = compile_expr_term(p);
        if (op == '+') compiler_emit(comp, OP_ADD, 0, 0);
        else           compiler_emit(comp, OP_SUB, 0, 0);
    }
    return p;
}

/* 比较 */
static const char *compile_expr_compare(const char *p) {
    p = compile_expr_addsub(p);
    while (1) {
        p = expr_skip(p);
        if (*p == '<' && *(p+1) == '=') {
            p += 2; p = compile_expr_addsub(p);
            compiler_emit(comp, OP_CMP_LE, 0, 0);
        } else if (*p == '>' && *(p+1) == '=') {
            p += 2; p = compile_expr_addsub(p);
            compiler_emit(comp, OP_CMP_GE, 0, 0);
        } else if (*p == '=' && *(p+1) == '=') {
            p += 2; p = compile_expr_addsub(p);
            compiler_emit(comp, OP_CMP_EQ, 0, 0);
        } else if (*p == '!' && *(p+1) == '=') {
            p += 2; p = compile_expr_addsub(p);
            compiler_emit(comp, OP_CMP_NE, 0, 0);
        } else if (*p == '<') {
            p++; p = compile_expr_addsub(p);
            compiler_emit(comp, OP_CMP_LT, 0, 0);
        } else if (*p == '>') {
            p++; p = compile_expr_addsub(p);
            compiler_emit(comp, OP_CMP_GT, 0, 0);
        } else {
            break;
        }
    }
    return p;
}

/* 编译算术表达式（顶层入口） */
static void compile_expression(const char *expr) {
    if (!expr || !*expr) {
        compiler_emit(comp, OP_PUSH_INT, 0, 0);
        return;
    }
    compile_expr_compare(expr);
}

/* ========== 工具函数 ========== */

/* 去除注释 */
static void strip_comment(char *line) {
    char *p = line;
    char quote = 0;
    while (*p) {
        if (!quote && (*p == '"' || *p == '\'')) {
            quote = *p;
        } else if (quote && *p == quote) {
            quote = 0;
        } else if (!quote && *p == '#') {
            *p = 0;
            return;
        }
        p++;
    }
}

/* 查找未被引号包裹的字符 */
static char *find_unquoted_char(char *str, char target) {
    char quote = 0;
    while (*str) {
        if (!quote && (*str == '"' || *str == '\'')) {
            quote = *str;
        } else if (quote && *str == quote) {
            quote = 0;
        } else if (!quote && *str == target) {
            return str;
        }
        /* 跳过 $() 和 $(()) */
        if (!quote && *str == '$' && *(str+1) == '(') {
            int depth = 1;
            str += 2;
            if (*str == '(') { str++; depth++; }
            while (*str && depth > 0) {
                if (*str == '(') depth++;
                else if (*str == ')') depth--;
                if (depth > 0) str++;
            }
            if (*str == ')') str++;
            continue;
        }
        /* 跳过 { } 块 */
        if (!quote && *str == '{' && target != '{') {
            int depth = 1;
            str++;
            while (*str && depth > 0) {
                if (*str == '"' || *str == '\'') {
                    char q = *str; str++;
                    while (*str && *str != q) {
                        if (*str == '\\' && *(str+1) && q == '"') str++;
                        str++;
                    }
                    if (*str) str++;
                    continue;
                }
                if (*str == '{') depth++;
                else if (*str == '}') depth--;
                if (depth > 0) str++;
            }
            if (*str == '}') str++;
            continue;
        }
        str++;
    }
    return NULL;
}

/* 查找未被引号包裹的子串 */
static char *find_unquoted_substr(char *str, const char *target) {
    int tlen = strlen(target);
    char *p = str;
    while (*p) {
        char quote = 0;
        if (*p == '"' || *p == '\'') {
            quote = *p; p++;
            while (*p && *p != quote) {
                if (*p == '\\' && *(p+1)) p++;
                p++;
            }
            if (*p) p++;
            continue;
        }
        if (*p == '$' && *(p+1) == '(') {
            int depth = 1; p += 2;
            if (*p == '(') { p++; depth++; }
            while (*p && depth > 0) {
                if (*p == '(') depth++;
                else if (*p == ')') depth--;
                if (depth > 0) p++;
            }
            if (*p) p++;
            continue;
        }
        if (strncmp(p, target, tlen) == 0) return p;
        p++;
    }
    return NULL;
}

/* 分词 */
static int tokenize_cmd(char *line, char *args[], int max_args) {
    int argc = 0;
    char *p = line;

    while (*p && argc < max_args - 1) {
        while (*p && (*p == ' ' || *p == '\t')) p++;
        if (!*p) break;

        args[argc] = p;
        char *out = p;

        while (*p && *p != ' ' && *p != '\t') {
            if (*p == '\'' || *p == '"') {
                char quote = *p; p++;
                while (*p && *p != quote) {
                    if (*p == '\\' && *(p+1) && quote == '"') {
                        if (*(p+1) == '"' || *(p+1) == '\\' ||
                            *(p+1) == '$' || *(p+1) == '`') p++;
                    }
                    *out++ = *p++;
                }
                if (*p == quote) p++;
            } else if (*p == '$' && *(p+1) == '(' && *(p+2) == '(') {
                *out++ = *p++; *out++ = *p++; *out++ = *p++;
                int depth = 0;
                while (*p) {
                    if (*p == '(') depth++;
                    else if (*p == ')') {
                        if (depth == 0 && *(p+1) == ')') {
                            *out++ = *p++; *out++ = *p++; break;
                        }
                        depth--;
                    }
                    *out++ = *p++;
                }
            } else if (*p == '$' && *(p+1) == '(' && *(p+2) != '(') {
                *out++ = *p++; *out++ = *p++;
                int depth = 1;
                while (*p && depth > 0) {
                    if (*p == '(') depth++;
                    else if (*p == ')') depth--;
                    if (depth > 0) *out++ = *p++;
                    else *out++ = *p++;
                }
            } else {
                *out++ = *p++;
            }
        }
        int has_more = (*p != 0);
        *out = 0;
        if (has_more) p++;
        argc++;
    }
    args[argc] = NULL;
    return argc;
}

/* 查找匹配的 done */
static int find_matching_done(int start) {
    int depth = 1;
    for (int j = start + 1; j < script_line_count; j++) {
        char *lt = script_lines[j].line;
        while (*lt == ' ' || *lt == '\t') lt++;
        if (*lt == '#' || *lt == 0) continue;
        if (strncmp(lt, "for ", 4) == 0 ||
            strncmp(lt, "while ", 6) == 0 ||
            strncmp(lt, "until ", 6) == 0 ||
            strncmp(lt, "select ", 7) == 0) {
            depth++;
        }
        char *done_pos = strstr(lt, "done");
        if (done_pos) {
            if ((done_pos == lt || *(done_pos-1) == ' ' || *(done_pos-1) == ';' || *(done_pos-1) == '\t') &&
                (done_pos[4] == 0 || done_pos[4] == ' ' || done_pos[4] == '\t' || done_pos[4] == ';')) {
                depth--;
                if (depth == 0) return j;
            }
        }
    }
    return script_line_count;
}

/* 查找匹配的 fi */
static int find_matching_fi(int start) {
    int depth = 1;
    for (int j = start + 1; j < script_line_count; j++) {
        char *lt = script_lines[j].line;
        while (*lt == ' ' || *lt == '\t') lt++;
        if (*lt == '#' || *lt == 0) continue;
        if (strncmp(lt, "if ", 3) == 0) depth++;
        char *fi_pos = strstr(lt, "fi");
        if (fi_pos) {
            if ((fi_pos == lt || *(fi_pos-1) == ' ' || *(fi_pos-1) == ';' || *(fi_pos-1) == '\t') &&
                (fi_pos[2] == 0 || fi_pos[2] == ' ' || fi_pos[2] == '\t' || fi_pos[2] == ';')) {
                depth--;
                if (depth == 0) return j;
            }
        }
    }
    return script_line_count;
}

/* 查找匹配的 esac */
static int find_matching_esac(int start) {
    int depth = 1;
    for (int j = start + 1; j < script_line_count; j++) {
        char *lt = script_lines[j].line;
        while (*lt == ' ' || *lt == '\t') lt++;
        if (*lt == '#' || *lt == 0) continue;
        if (strncmp(lt, "case ", 5) == 0) depth++;
        char *esac_pos = strstr(lt, "esac");
        if (esac_pos) {
            if ((esac_pos == lt || *(esac_pos-1) == ' ' || *(esac_pos-1) == ';' || *(esac_pos-1) == '\t') &&
                (esac_pos[4] == 0 || esac_pos[4] == ' ' || esac_pos[4] == '\t' || esac_pos[4] == ';')) {
                depth--;
                if (depth == 0) return j;
            }
        }
    }
    return script_line_count;
}

/* 查找匹配的 } 用于函数定义，从 start_line 行开始扫描 */
static int find_matching_brace(int start_line) {
    int depth = 0;
    int started = 0;
    for (int j = start_line; j < script_line_count; j++) {
        char *line = script_lines[j].line;
        char *p = line;
        char quote = 0;
        while (*p) {
            if (!quote && (*p == '"' || *p == '\'')) {
                quote = *p;
            } else if (quote && *p == quote) {
                quote = 0;
            } else if (!quote && *p == '$' && *(p+1) == '(') {
                int d = 1; p += 2;
                if (*p == '(') { p++; d++; }
                while (*p && d > 0) {
                    if (*p == '(') d++;
                    else if (*p == ')') d--;
                    if (d > 0) p++;
                }
                if (*p == ')') p++;
                continue;
            } else if (!quote && *p == '{') {
                depth++;
                started = 1;
            } else if (!quote && *p == '}') {
                depth--;
                if (started && depth == 0) return j;
            }
            p++;
        }
    }
    return script_line_count;
}

/* 查找函数（在编译器函数表中） */
static int find_function(const char *name) {
    for (int i = 0; i < comp->func_count; i++) {
        if (strcmp(comp->functions[i].name, name) == 0)
            return i;
    }
    return -1;
}

/* 检查命令名是否为内置命令 */
static int is_builtin_command(const char *name) {
    for (int i = 0; i < builtin_table_size; i++) {
        if (strcmp(builtin_table[i].name, name) == 0)
            return 1;
    }
    return 0;
}

/* 返回专用操作码（如果命令有专用操作码），否则返回 -1 */
static int builtin_dedicated_opcode(const char *name) {
    if (strcmp(name, "echo") == 0)     return OP_ECHO;
    if (strcmp(name, "cd") == 0)       return OP_CD;
    if (strcmp(name, "pwd") == 0)      return OP_PWD;
    if (strcmp(name, "exit") == 0)     return OP_EXIT;
    if (strcmp(name, "read") == 0)     return OP_READ;
    if (strcmp(name, "source") == 0)   return OP_SOURCE;
    if (strcmp(name, ".") == 0)        return OP_SOURCE;
    if (strcmp(name, "break") == 0)    return OP_BREAK;
    if (strcmp(name, "continue") == 0) return OP_CONTINUE;
    if (strcmp(name, "true") == 0)     return OP_EXEC_BUILTIN;
    if (strcmp(name, "false") == 0)    return OP_EXEC_BUILTIN;
    if (strcmp(name, "export") == 0)   return OP_EXPORT;
    if (strcmp(name, "unset") == 0)    return OP_UNSET;
    if (strcmp(name, "shift") == 0)    return OP_SHIFT;
    if (strcmp(name, "printf") == 0)   return OP_PRINTF;
    if (strcmp(name, "let") == 0)      return OP_LET;
    if (strcmp(name, "alias") == 0)    return OP_ALIAS;
    if (strcmp(name, "unalias") == 0)  return OP_UNALIAS;
    if (strcmp(name, "type") == 0)     return OP_TYPE;
    if (strcmp(name, "wait") == 0)     return OP_WAIT;
    if (strcmp(name, "jobs") == 0)     return OP_JOBS;
    if (strcmp(name, "bg") == 0)       return OP_BG;
    if (strcmp(name, "fg") == 0)       return OP_FG;
    if (strcmp(name, "kill") == 0)     return OP_KILL;
    if (strcmp(name, "umask") == 0)    return OP_UMASK;
    if (strcmp(name, "ulimit") == 0)   return OP_ULIMIT;
    if (strcmp(name, "times") == 0)    return OP_TIMES;
    if (strcmp(name, "trap") == 0)     return OP_TRAP;
    if (strcmp(name, "getopts") == 0)  return OP_GETOPTS;
    if (strcmp(name, "declare") == 0)  return OP_DECLARE;
    if (strcmp(name, "typeset") == 0)  return OP_DECLARE;
    if (strcmp(name, "local") == 0)    return OP_LOCAL;
    if (strcmp(name, "mapfile") == 0)  return OP_MAPFILE;
    if (strcmp(name, "readarray") == 0)return OP_MAPFILE;
    if (strcmp(name, "compgen") == 0)  return OP_COMPGEN;
    if (strcmp(name, "complete") == 0) return OP_COMPLETE;
    if (strcmp(name, "enable") == 0)   return OP_ENABLE;
    if (strcmp(name, "builtin") == 0)  return OP_BUILTIN;
    if (strcmp(name, "caller") == 0)   return OP_CALLER;
    if (strcmp(name, "dirs") == 0)     return OP_DIRS;
    if (strcmp(name, "pushd") == 0)    return OP_PUSHD;
    if (strcmp(name, "popd") == 0)     return OP_POPD;
    if (strcmp(name, "disown") == 0)   return OP_DISOWN;
    if (strcmp(name, "shopt") == 0)    return OP_SHOPT;
    if (strcmp(name, "suspend") == 0)  return OP_SUSPEND;
    if (strcmp(name, "test") == 0)     return OP_TEST_CMD;
    if (strcmp(name, "hash") == 0)     return OP_HASH;
    if (strcmp(name, "bind") == 0)     return OP_BIND;
    if (strcmp(name, "help") == 0)     return OP_HELP;
    if (strcmp(name, "history") == 0)  return OP_HISTORY;
    if (strcmp(name, "logout") == 0)   return OP_LOGOUT;
    if (strcmp(name, "set") == 0)      return OP_SET;
    if (strcmp(name, "exec") == 0)     return OP_EXEC_CMD;
    if (strcmp(name, "eval") == 0)     return OP_EXEC_BUILTIN;
    return -1; /* no dedicated opcode */
}

/* ========== 编译核心 ========== */

/* 编译 test / [[ ]] 参数，支持 $VAR 展开 */
static void compile_test_arg(const char *arg) {
    /* 处理 $VAR 和 ${VAR} */
    if (arg[0] == '$') {
        const char *vstart = arg + 1;
        if (*vstart == '{') {
            vstart++;
            char vname[MAX_LINE];
            int i = 0;
            while (*vstart && *vstart != '}' && i < MAX_LINE - 1) vname[i++] = *vstart++;
            vname[i] = 0;
            int idx = compiler_add_string(comp, vname);
            compiler_emit(comp, OP_LOAD, idx, 0);
            return;
        } else if (isalpha(*vstart) || *vstart == '_') {
            char vname[MAX_LINE];
            int i = 0;
            while (*vstart && (isalnum(*vstart) || *vstart == '_') && i < MAX_LINE - 1)
                vname[i++] = *vstart++;
            vname[i] = 0;
            int idx = compiler_add_string(comp, vname);
            compiler_emit(comp, OP_LOAD, idx, 0);
            return;
        }
    }
    int idx = compiler_add_string(comp, arg);
    compiler_emit(comp, OP_PUSH_STR, idx, 0);
}

static int compile_condition(const char *cond) {
    char buf[MAX_LINE];
    strncpy(buf, cond, MAX_LINE - 1);
    buf[MAX_LINE - 1] = 0;

    /* 去除尾部空白 */
    char *e = buf + strlen(buf) - 1;
    while (e > buf && (*e == ' ' || *e == '\t')) *e-- = 0;

    char *p = buf;
    while (*p == ' ' || *p == '\t') p++;

    if (!*p) {
        compiler_emit(comp, OP_PUSH_INT, 0, 0);
        return 0;
    }

    /* ((expr)) 算术条件 */
    if (*p == '(' && *(p+1) == '(') {
        char *start = p + 2;
        char *end = buf + strlen(buf) - 1;
        while (end > start && (*end == ' ' || *end == '\t')) end--;
        if (*end == ')' && *(end-1) == ')') {
            *end = 0;
            *(end-1) = 0;
            compile_expression(start);
            return 0;
        }
    }

    /* [[ ... ]] 条件 — execute_test 返回 0=成功, 用 OP_NOT 归一化为 1=真 */
    if (strncmp(p, "[[", 2) == 0) {
        p += 2;
        while (*p == ' ' || *p == '\t') p++;
        char *args[MAX_ARGS];
        char *end_bb = strstr(p, "]]");
        if (end_bb) *end_bb = 0;
        int argc = tokenize_cmd(p, args, MAX_ARGS);
        for (int i = 0; i < argc; i++) compile_test_arg(args[i]);
        compiler_emit(comp, OP_TEST, argc, 0);
        compiler_emit(comp, OP_NOT, 0, 0);  /* 归一化: 0→1, 非0→0 */
        if (end_bb) *end_bb = ']';
        return 0;
    }

    /* [ ... ] 条件 */
    if (*p == '[') {
        char *end_br = strrchr(p, ']');
        if (end_br) *end_br = 0;
        p++;
        while (*p == ' ' || *p == '\t') p++;

        char *args[MAX_ARGS];
        int argc = tokenize_cmd(p, args, MAX_ARGS);
        for (int i = 0; i < argc; i++) compile_test_arg(args[i]);
        compiler_emit(comp, OP_TEST, argc, 0);
        compiler_emit(comp, OP_NOT, 0, 0);  /* 归一化 */
        if (end_br) *end_br = ']';
        return 0;
    }

    /* 普通命令条件 — 退出码 0=成功, 归一化 */
    char *args[MAX_ARGS];
    int argc = tokenize_cmd(p, args, MAX_ARGS);
    if (argc > 0) {
        compile_args(args, 0);
        compiler_emit(comp, OP_EXEC, argc, 0);
        compiler_emit(comp, OP_NOT, 0, 0);  /* 归一化: 0→1, 非0→0 */
    }
    return 0;
}

/* 编译单个参数（支持数组访问: ${arr[index]}） */
static void compile_arg(const char *arg) {
    /* 检查是否为数组访问: ${name[index]} */
    if (arg && arg[0] == '$' && arg[1] == '{') {
        const char *close = strchr(arg + 2, '}');
        if (close) {
            const char *bracket = strchr(arg + 2, '[');
            if (bracket && bracket < close) {
                /* 提取数组名 */
                int name_len = bracket - (arg + 2);
                if (name_len > 0) {
                    char arr_name[MAX_LINE];
                    strncpy(arr_name, arg + 2, name_len);
                    arr_name[name_len] = 0;

                    /* 提取索引 */
                    const char *idx_start = bracket + 1;
                    int idx_len = close - idx_start;
                    if (idx_len > 0) {
                        char idx_str[MAX_LINE];
                        strncpy(idx_str, idx_start, idx_len);
                        idx_str[idx_len] = 0;

                        /* 推送索引 */
                        if (isdigit((unsigned char)idx_str[0]) ||
                            (idx_str[0] == '-' && isdigit((unsigned char)idx_str[1]))) {
                            compiler_emit(comp, OP_PUSH_INT, atoi(idx_str), 0);
                        } else if (idx_str[0] == '$') {
                            const char *vstart = idx_str + 1;
                            if (*vstart == '{') {
                                vstart++;
                                char vname[MAX_LINE]; int vi = 0;
                                while (*vstart && *vstart != '}' && vi < MAX_LINE - 1)
                                    vname[vi++] = *vstart++;
                                vname[vi] = 0;
                                int vidx = compiler_add_string(comp, vname);
                                compiler_emit(comp, OP_LOAD, vidx, 0);
                            } else {
                                char vname[MAX_LINE]; int vi = 0;
                                while (*vstart && (isalnum((unsigned char)*vstart) || *vstart == '_')
                                       && vi < MAX_LINE - 1)
                                    vname[vi++] = *vstart++;
                                vname[vi] = 0;
                                int vidx = compiler_add_string(comp, vname);
                                compiler_emit(comp, OP_LOAD, vidx, 0);
                            }
                        } else {
                            int idx = compiler_add_string(comp, idx_str);
                            compiler_emit(comp, OP_PUSH_STR, idx, 0);
                        }

                        compiler_emit(comp, OP_ARRAY_GET,
                                      compiler_add_string(comp, arr_name), 0);
                        return;
                    }
                }
            }
        }
    }
    /* 普通参数 */
    int idx = compiler_add_string(comp, arg);
    compiler_emit(comp, OP_PUSH_STR, idx, 0);
}

/* 编译命令参数压栈 */
static void compile_args(char **args, int start) {
    for (int i = start; args[i]; i++) {
        compile_arg(args[i]);
    }
}

/* 编译单行（单个逻辑语句） */
static void compile_line(const char *line) {
    if (!line || !*line) return;

    char buf[MAX_LINE * 2];
    strncpy(buf, line, MAX_LINE * 2 - 1);
    buf[MAX_LINE * 2 - 1] = 0;

    strip_comment(buf);

    char *p = buf;
    while (*p == ' ' || *p == '\t') p++;
    char *end = p + strlen(p) - 1;
    while (end > p && (*end == ' ' || *end == '\t')) end--;
    *(end + 1) = 0;

    if (!*p) return;

    /* ===== 空命令 (:) ===== */
    if (strcmp(p, ":") == 0) {
        /* nullary builtin - always succeeds, push 0 */
        compiler_emit(comp, OP_PUSH_INT, 0, 0);
        return;
    }

    /* ===== 变量赋值: VAR=value ===== */
    if (isalpha(*p) || *p == '_') {
        char *vp = p + 1;
        while (isalnum(*vp) || *vp == '_') vp++;
        if (*vp == '=') {
            /* 检查是否为数组赋值: arr=(val1 val2) */
            if (*(vp + 1) == '(') {
                *vp = 0;
                char *var_name = p;
                char *arr_content = vp + 2; /* skip =( */

                /* 查找匹配的 ) */
                char *close_paren = strchr(arr_content, ')');
                if (close_paren) {
                    *close_paren = 0;

                    /* 分词数组元素 */
                    char *arr_args[MAX_ARGS];
                    int arr_argc = tokenize_cmd(arr_content, arr_args, MAX_ARGS);

                    int name_idx = compiler_add_string(comp, var_name);
                    for (int ai = 0; ai < arr_argc; ai++) {
                        int val_idx = compiler_add_string(comp, arr_args[ai]);
                        compiler_emit(comp, OP_PUSH_STR, val_idx, 0);
                        compiler_emit(comp, OP_ARRAY_SET, name_idx, 0);
                    }
                    *close_paren = ')';
                    return;
                }
            }

            /* 普通变量赋值 */
            *vp = 0;
            char *var_name = p;
            char *var_value = vp + 1;

            /* 剥离引号 */
            int had_quote = 0;
            if (var_value[0] == '\'' || var_value[0] == '"') {
                had_quote = 1;
                char quote = var_value[0];
                size_t vlen = strlen(var_value);
                if (vlen >= 2 && var_value[vlen - 1] == quote) {
                    var_value[vlen - 1] = 0;
                    var_value++;
                }
            }

            /* 检测 $((...)) 算术扩展 (未被引号包裹时) */
            if (!had_quote && var_value[0] == '$' && var_value[1] == '(' &&
                var_value[2] == '(') {
                char *start = var_value + 3;
                char *end = start + strlen(start);
                if (end > start && end[-1] == ')' && end[-2] == ')') {
                    end -= 2;
                    while (end > start && (*(end-1) == ' ' || *(end-1) == '\t')) end--;
                    *end = 0;
                    /* 编译算术表达式，结果留在栈顶 */
                    compile_expression(start);
                    int idx = compiler_add_string(comp, var_name);
                    compiler_emit(comp, OP_STORE, idx, 0);
                    *vp = '=';
                    return;
                }
            }

            int idx = compiler_add_string(comp, var_value);
            compiler_emit(comp, OP_PUSH_STR, idx, 0);
            idx = compiler_add_string(comp, var_name);
            compiler_emit(comp, OP_STORE, idx, 0);
            *vp = '=';
            return;
        }
    }

    /* ===== { } 匿名块 ===== */
    if (*p == '{') {
        /* 查找匹配的 } */
        char *brace_start = p;
        char *brace_end = p + 1;
        int depth = 1;
        char quote = 0;
        while (*brace_end) {
            if (!quote && (*brace_end == '"' || *brace_end == '\'')) {
                quote = *brace_end;
            } else if (quote && *brace_end == quote) {
                quote = 0;
            } else if (!quote && *brace_end == '{') {
                depth++;
            } else if (!quote && *brace_end == '}') {
                depth--;
                if (depth == 0) break;
            } else if (!quote && *brace_end == '$' && *(brace_end+1) == '(') {
                int d = 1; brace_end += 2;
                if (*brace_end == '(') { brace_end++; d++; }
                while (*brace_end && d > 0) {
                    if (*brace_end == '(') d++;
                    else if (*brace_end == ')') d--;
                    if (d > 0) brace_end++;
                }
                if (*brace_end) brace_end++;
                continue;
            }
            brace_end++;
        }
        if (*brace_end == '}' && depth == 0) {
            compiler_emit(comp, OP_BLOCK_BEG, 0, 0);
            /* 提取内部内容并编译 */
            char inner[MAX_LINE * 2];
            int inner_len = brace_end - (brace_start + 1);
            strncpy(inner, brace_start + 1, inner_len);
            inner[inner_len] = 0;

            char *ip = inner;
            while (*ip == ' ' || *ip == '\t') ip++;
            if (*ip) {
                /* 递归编译内部命令 */
                char *semi = find_unquoted_char(ip, ';');
                while (semi) {
                    *semi = 0;
                    if (*ip) compile_line(ip);
                    ip = semi + 1;
                    while (*ip == ' ' || *ip == '\t') ip++;
                    semi = find_unquoted_char(ip, ';');
                }
                if (*ip) compile_line(ip);
            }
            compiler_emit(comp, OP_BLOCK_END, 0, 0);
            return;
        }
    }

    /* ===== 逻辑运算符 && || ===== */
    {
        char *aa = find_unquoted_substr(p, "&&");
        char *oo = find_unquoted_substr(p, "||");
        if (aa || oo) {
            char *op_pos = NULL;
            int is_and = 0;
            if (aa && (!oo || aa < oo)) { op_pos = aa; is_and = 1; }
            else { op_pos = oo; is_and = 0; }

            *op_pos = 0;
            char *left = p;
            char *right = op_pos + 2;

            while (*left == ' ') left++;
            char *le = left + strlen(left) - 1;
            while (le > left && *le == ' ') *le-- = 0;
            while (*right == ' ') right++;

            /* 编译左侧 */
            if (*left) compile_line(left);

            /* 归一化左侧结果: 0=false, 1=true */
            compiler_emit(comp, OP_NOT, 0, 0);

            if (is_and) {
                /* && : 左侧失败(0)则跳过右侧 (JZ: jump if false) */
                int jz_addr = compiler_emit(comp, OP_JZ, 0, 0);
                compiler_emit(comp, OP_POP, 0, 0);
                if (*right) compile_line(right);
                int end_label = compiler_emit_label(comp);
                compiler_patch_jump(comp, jz_addr, end_label);
            } else {
                /* || : 左侧成功(1)则跳过右侧 (JNZ: jump if true) */
                int jnz_addr = compiler_emit(comp, OP_JNZ, 0, 0);
                compiler_emit(comp, OP_POP, 0, 0);
                if (*right) compile_line(right);
                int end_label = compiler_emit_label(comp);
                compiler_patch_jump(comp, jnz_addr, end_label);
            }
            return;
        }
    }

    /* ===== 管道 | ===== */
    {
        char *pipe_pos = NULL;
        char *pp = p;
        char quote = 0;
        while (*pp) {
            if (!quote && (*pp == '"' || *pp == '\'')) {
                quote = *pp;
            } else if (quote && *pp == quote) {
                quote = 0;
            } else if (!quote && *pp == '|') {
                if (*(pp+1) != '|') { pipe_pos = pp; break; }
                pp++;
            }
            if (!quote && *pp == '$' && *(pp+1) == '(') {
                int d = 1; pp += 2;
                if (*pp == '(') { pp++; d++; }
                while (*pp && d > 0) {
                    if (*pp == '(') d++;
                    else if (*pp == ')') d--;
                    if (d > 0) pp++;
                }
                if (*pp == ')') pp++;
                continue;
            }
            pp++;
        }

        if (pipe_pos) {
            *pipe_pos = 0;
            char *left_cmd = p;
            char *right_cmd = pipe_pos + 1;
            while (*left_cmd == ' ') left_cmd++;
            while (*right_cmd == ' ') right_cmd++;

            /* 管道实现: 标记左命令起点, 编译左+右, OP_PIPE 在 VM 中 fork,
             * 子进程重跑到左命令起点执行左侧, 父进程继续执行右侧 */
            int left_start = compiler_emit_label(comp);
            if (*left_cmd) compile_line(left_cmd);
            compiler_emit(comp, OP_PIPE, left_start, 0);
            if (*right_cmd) compile_line(right_cmd);
            return;
        }
    }

    /* ===== 重定向 > >> < 以及 here-doc << ===== */
    {
        char clean_cmd[MAX_LINE * 2];
        clean_cmd[0] = 0;
        char *src = p;
        char *out = clean_cmd;
        int has_redirect = 0;

        while (*src) {
            if (*src == '"' || *src == '\'') {
                char q = *src; *out++ = *src++;
                while (*src && *src != q) {
                    if (*src == '\\' && *(src+1) && q == '"') { *out++ = *src++; }
                    *out++ = *src++;
                }
                if (*src) *out++ = *src++;
                continue;
            }
            if (*src == '$' && *(src+1) == '(') {
                int d = 1; *out++ = *src++; *out++ = *src++;
                if (*src == '(') { *out++ = *src++; d++; }
                while (*src && d > 0) {
                    if (*src == '(') d++;
                    else if (*src == ')') d--;
                    *out++ = *src++;
                }
                continue;
            }
            if (*src == '$' && *(src+1) == '{') {
                *out++ = *src++; *out++ = *src++;
                while (*src && *src != '}') *out++ = *src++;
                if (*src) *out++ = *src++;
                continue;
            }

            /* << here-doc (body handled by compile_lines, skip delimiter here) */
            if (*src == '<' && *(src+1) == '<' && *(src+2) != '<') {
                src += 2;
                while (*src == ' ' || *src == '\t') src++;
                /* skip delimiter */
                if (*src == '"' || *src == '\'') {
                    char q = *src++;
                    while (*src && *src != q) src++;
                    if (*src) src++;
                } else {
                    while (*src && *src != ' ' && *src != '\t' && *src != ';' && *src != '>' && *src != '<' && *src != '|')
                        src++;
                }
                continue;
            }

            /* >> 追加 */
            if (*src == '>' && *(src+1) == '>') {
                src += 2;
                while (*src == ' ') src++;
                char fname[MAX_LINE]; int fi = 0;
                while (*src && *src != ' ' && *src != '\t' && *src != '>' && *src != '<' && *src != '|') {
                    fname[fi++] = *src++;
                }
                fname[fi] = 0;
                if (fi > 0) {
                    int idx = compiler_add_string(comp, fname);
                    compiler_emit(comp, OP_PUSH_STR, idx, 0);
                    compiler_emit(comp, OP_REDIR_APP, 0, 0);
                    has_redirect = 1;
                }
                continue;
            }
            /* > 覆盖 */
            if (*src == '>') {
                src++;
                while (*src == ' ') src++;
                char fname[MAX_LINE]; int fi = 0;
                while (*src && *src != ' ' && *src != '\t' && *src != '>' && *src != '<' && *src != '|') {
                    fname[fi++] = *src++;
                }
                fname[fi] = 0;
                if (fi > 0) {
                    int idx = compiler_add_string(comp, fname);
                    compiler_emit(comp, OP_PUSH_STR, idx, 0);
                    compiler_emit(comp, OP_REDIR_OUT, 0, 0);
                    has_redirect = 1;
                }
                continue;
            }
            /* < 输入 */
            if (*src == '<') {
                src++;
                while (*src == ' ') src++;
                char fname[MAX_LINE]; int fi = 0;
                while (*src && *src != ' ' && *src != '\t' && *src != '>' && *src != '<' && *src != '|') {
                    fname[fi++] = *src++;
                }
                fname[fi] = 0;
                if (fi > 0) {
                    int idx = compiler_add_string(comp, fname);
                    compiler_emit(comp, OP_PUSH_STR, idx, 0);
                    compiler_emit(comp, OP_REDIR_IN, 0, 0);
                    has_redirect = 1;
                }
                continue;
            }
            *out++ = *src++;
        }
        *out = 0;

        char *s = clean_cmd;
        while (*s == ' ') s++;
        char *se = s + strlen(s) - 1;
        while (se > s && *se == ' ') *se-- = 0;

        if (*s) {
            char *args[MAX_ARGS];
            int argc = tokenize_cmd(s, args, MAX_ARGS);
            if (argc > 0) {
                /* ---- 内建命令检测 ---- */
                if (strcmp(args[0], "echo") == 0) {
                    /* Push "echo" as command name, then all args, then OP_EXEC_BUILTIN */
                    int e_idx = compiler_add_string(comp, "echo");
                    compiler_emit(comp, OP_PUSH_STR, e_idx, 0);
                    for (int i = 1; args[i]; i++) {
                        int idx = compiler_add_string(comp, args[i]);
                        compiler_emit(comp, OP_PUSH_STR, idx, 0);
                    }
                    int n = argc; /* includes "echo" */
                    compiler_emit(comp, OP_EXEC_BUILTIN, n, 0);
                } else if (strcmp(args[0], "cd") == 0) {
                    if (args[1]) {
                        int idx = compiler_add_string(comp, args[1]);
                        compiler_emit(comp, OP_PUSH_STR, idx, 0);
                    } else {
                        compiler_emit(comp, OP_PUSH_STR,
                            compiler_add_string(comp, ""), 0);
                    }
                    compiler_emit(comp, OP_CD, 0, 0);
                } else if (strcmp(args[0], "return") == 0) {
                    if (args[1]) {
                        int idx = compiler_add_string(comp, args[1]);
                        compiler_emit(comp, OP_PUSH_STR, idx, 0);
                    } else {
                        compiler_emit(comp, OP_PUSH_INT, 0, 0);
                    }
                    compiler_emit(comp, OP_RETURN, 0, 0);
                } else if (strcmp(args[0], "pwd") == 0) {
                    compiler_emit(comp, OP_PWD, 0, 0);
                } else if (strcmp(args[0], "exit") == 0) {
                    if (args[1]) {
                        int idx = compiler_add_string(comp, args[1]);
                        compiler_emit(comp, OP_PUSH_STR, idx, 0);
                    } else {
                        compiler_emit(comp, OP_PUSH_INT, 0, 0);
                    }
                    compiler_emit(comp, OP_EXIT, 0, 0);
                } else if (strcmp(args[0], "read") == 0) {
                    char *vname = args[1] ? args[1] : "REPLY";
                    int idx = compiler_add_string(comp, vname);
                    compiler_emit(comp, OP_READ, idx, 0);
                } else if (strcmp(args[0], "source") == 0 || strcmp(args[0], ".") == 0) {
                    if (args[1]) {
                        int idx = compiler_add_string(comp, args[1]);
                        compiler_emit(comp, OP_PUSH_STR, idx, 0);
                    }
                    compiler_emit(comp, OP_SOURCE, 0, 0);
                } else if (strcmp(args[0], "break") == 0) {
                    compiler_emit(comp, OP_BREAK, 0, 0);
                } else if (strcmp(args[0], "continue") == 0) {
                    compiler_emit(comp, OP_CONTINUE, 0, 0);
                } else if (strcmp(args[0], "export") == 0) {
                    if (args[1]) {
                        compile_args(args, 1);
                        int idx = compiler_add_string(comp, args[1]);
                        compiler_emit(comp, OP_EXPORT, idx, 0);
                    }
                } else if (strcmp(args[0], "unset") == 0) {
                    if (args[1]) {
                        int idx = compiler_add_string(comp, args[1]);
                        compiler_emit(comp, OP_UNSET, idx, 0);
                    }
                } else if (strcmp(args[0], "shift") == 0) {
                    int n = 1;
                    if (args[1]) n = atoi(args[1]);
                    compiler_emit(comp, OP_SHIFT, n, 0);
                } else if (strcmp(args[0], "printf") == 0) {
                    compile_args(args, 1);
                    int count = 0;
                    for (int i = 1; args[i]; i++) count++;
                    compiler_emit(comp, OP_PRINTF, count, 0);
                } else if (strcmp(args[0], "let") == 0) {
                    compile_args(args, 1);
                    int count = 0;
                    for (int i = 1; args[i]; i++) count++;
                    compiler_emit(comp, OP_LET, count, 0);
                } else if (strcmp(args[0], "true") == 0 || strcmp(args[0], "false") == 0) {
                    compile_args(args, 0);
                    compiler_emit(comp, OP_EXEC_BUILTIN, argc, 0);
                } else if (strcmp(args[0], "[") == 0) {
                    /* test 命令形式 */
                    int test_argc = 0;
                    for (int i = 1; args[i] && strcmp(args[i], "]") != 0; i++) {
                        compile_test_arg(args[i]);
                        test_argc++;
                    }
                    compiler_emit(comp, OP_TEST, test_argc, 0);
                } else if (strcmp(args[0], "[[") == 0) {
                    int test_argc = 0;
                    for (int i = 1; args[i] && strcmp(args[i], "]]") != 0; i++) {
                        compile_test_arg(args[i]);
                        test_argc++;
                    }
                    compiler_emit(comp, OP_TEST, test_argc, 0);
                } else if (strcmp(args[0], "alias") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_ALIAS, 0, 0);
                } else if (strcmp(args[0], "unalias") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_UNALIAS, 0, 0);
                } else if (strcmp(args[0], "type") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_TYPE, 0, 0);
                } else if (strcmp(args[0], "wait") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_WAIT, 0, 0);
                } else if (strcmp(args[0], "jobs") == 0) {
                    compiler_emit(comp, OP_JOBS, 0, 0);
                } else if (strcmp(args[0], "bg") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_BG, 0, 0);
                } else if (strcmp(args[0], "fg") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_FG, 0, 0);
                } else if (strcmp(args[0], "kill") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_KILL, 0, 0);
                } else if (strcmp(args[0], "umask") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_UMASK, 0, 0);
                } else if (strcmp(args[0], "ulimit") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_ULIMIT, 0, 0);
                } else if (strcmp(args[0], "times") == 0) {
                    compiler_emit(comp, OP_TIMES, 0, 0);
                } else if (strcmp(args[0], "trap") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_TRAP, 0, 0);
                } else if (strcmp(args[0], "getopts") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_GETOPTS, 0, 0);
                } else if (strcmp(args[0], "declare") == 0 || strcmp(args[0], "typeset") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_DECLARE, 0, 0);
                } else if (strcmp(args[0], "local") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_LOCAL, 0, 0);
                } else if (strcmp(args[0], "mapfile") == 0 || strcmp(args[0], "readarray") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_MAPFILE, 0, 0);
                } else if (strcmp(args[0], "compgen") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_COMPGEN, 0, 0);
                } else if (strcmp(args[0], "complete") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_COMPLETE, 0, 0);
                } else if (strcmp(args[0], "enable") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_ENABLE, 0, 0);
                } else if (strcmp(args[0], "builtin") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_BUILTIN, 0, 0);
                } else if (strcmp(args[0], "caller") == 0) {
                    compiler_emit(comp, OP_CALLER, 0, 0);
                } else if (strcmp(args[0], "dirs") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_DIRS, 0, 0);
                } else if (strcmp(args[0], "pushd") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_PUSHD, 0, 0);
                } else if (strcmp(args[0], "popd") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_POPD, 0, 0);
                } else if (strcmp(args[0], "disown") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_DISOWN, 0, 0);
                } else if (strcmp(args[0], "shopt") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_SHOPT, 0, 0);
                } else if (strcmp(args[0], "suspend") == 0) {
                    compiler_emit(comp, OP_SUSPEND, 0, 0);
                } else if (strcmp(args[0], "hash") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_HASH, 0, 0);
                } else if (strcmp(args[0], "bind") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_BIND, 0, 0);
                } else if (strcmp(args[0], "help") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_HELP, 0, 0);
                } else if (strcmp(args[0], "history") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_HISTORY, 0, 0);
                } else if (strcmp(args[0], "logout") == 0) {
                    compiler_emit(comp, OP_LOGOUT, 0, 0);
                } else if (strcmp(args[0], "set") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_SET, 0, 0);
                } else if (strcmp(args[0], "exec") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_EXEC_CMD, 0, 0);
                } else if (strcmp(args[0], "test") == 0 && args[1] && strcmp(args[1], "[") != 0) {
                    /* compile_test_arg 会展开 $VAR */
                    int test_argc = 0;
                    for (int i = 1; args[i]; i++) {
                        compile_test_arg(args[i]);
                        test_argc++;
                    }
                    compiler_emit(comp, OP_TEST_CMD, test_argc, 0);
                } else if (strcmp(args[0], "eval") == 0) {
                    compile_args(args, 1);
                    compiler_emit(comp, OP_EXEC_BUILTIN, argc, 0);
                }
                /* ---- 检查是否为其他内置命令 ---- */
                else if (is_builtin_command(args[0])) {
                    compile_args(args, 0);
                    compiler_emit(comp, OP_EXEC_BUILTIN, argc, 0);
                }
                /* ---- 检查是否为函数调用 ---- */
                else if (find_function(args[0]) >= 0) {
                    /* 压入函数参数 (从位置1开始到末尾) */
                    int func_argc = 0;
                    for (int i = 1; args[i]; i++) {
                        compile_arg(args[i]);
                        func_argc++;
                    }
                    int name_idx = compiler_add_string(comp, args[0]);
                    /* a = name_idx (in upper bits), b = arg count for split
                     * 用 a=name_idx (高16位名字idx) 在 VM 解析
                     * 简单做法: a = (arg_count << 16) | name_idx */
                    compiler_emit(comp, OP_FUNC_CALL, (func_argc << 16) | (name_idx & 0xFFFF), 0);
                }
                /* ---- 外部命令 ---- */
                else {
                    compile_args(args, 0);
                    compiler_emit(comp, OP_EXEC, argc, 0);
                }
            }
        }

        if (has_redirect) {
            compiler_emit(comp, OP_REDIR_RESTORE, 0, 0);
        }
        return;
    }
}

/* 编译多行代码块 */
static void compile_lines(int start, int end) {
    int i = start;

    while (i < end) {
        char *trimmed = script_lines[i].line;
        while (*trimmed == ' ' || *trimmed == '\t') trimmed++;

        if (*trimmed == '#' || *trimmed == 0) { i++; continue; }

        /* 跳过控制关键字 */
        if (strcmp(trimmed, "then") == 0 || strcmp(trimmed, "do") == 0 ||
            strcmp(trimmed, "fi") == 0 || strcmp(trimmed, "done") == 0 ||
            strcmp(trimmed, "else") == 0 || strcmp(trimmed, "in") == 0 ||
            strcmp(trimmed, "esac") == 0) {
            i++; continue;
        }

        if (strncmp(trimmed, "then ", 5) == 0) {
            compile_line(trimmed + 5);
            i++; continue;
        }
        if (strncmp(trimmed, "do ", 3) == 0) {
            /* do 后面可能有 body (例如 "do if [ ... ]; then ...; fi")
             * 这种情况 do 后是另一行, 但如果 "do cmd" 同行, 编译剩余部分 */
            compile_line(trimmed + 3);
            i++; continue;
        }
        if (strncmp(trimmed, "else ", 5) == 0 || strncmp(trimmed, "else\t", 5) == 0) {
            /* else 同行 body 已经在 if 块扫描时识别为 inline_body 处理,
             * 这里不重复编译 */
            i++; continue;
        }
        if (strncmp(trimmed, "fi ", 3) == 0 || strncmp(trimmed, "fi\t", 3) == 0 ||
            strncmp(trimmed, "fi;", 3) == 0) {
            i++; continue;
        }
        if (strncmp(trimmed, "done ", 5) == 0 || strncmp(trimmed, "done\t", 5) == 0 ||
            strncmp(trimmed, "done;", 5) == 0) {
            i++; continue;
        }
        if (strncmp(trimmed, "elif ", 5) == 0) {
            i++; continue;
        }

        /* ===== 函数定义: name() { ... } ===== */
        {
            char *paren = strstr(trimmed, "()");
            if (paren && !find_unquoted_char(trimmed, '=')) {
                /* 提取函数名 */
                char *name_start = trimmed;
                while (*name_start == ' ' || *name_start == '\t') name_start++;
                /* Skip 'function ' keyword if present */
                if (strncmp(name_start, "function", 8) == 0 &&
                    (name_start[8] == ' ' || name_start[8] == '\t')) {
                    name_start += 8;
                    while (*name_start == ' ' || *name_start == '\t') name_start++;
                }
                char *name_end = paren;
                /* trim trailing whitespace from name */
                char *nt = name_end - 1;
                while (nt > name_start && (*nt == ' ' || *nt == '\t')) nt--;
                int name_len = nt - name_start + 1;
                if (name_len > 0 && name_len < MAX_LINE) {
                    char func_name[MAX_LINE];
                    strncpy(func_name, name_start, name_len);
                    func_name[name_len] = 0;

                    /* 查找 { */
                    char *brace = paren + 2;
                    while (*brace == ' ' || *brace == '\t') brace++;

                    int brace_line = i;

                    if (*brace == '{') {
                        /* { 在同一行，函数体从下一行开始 */
                        brace_line = i;
                    } else {
                        /* { 在下一行 */
                        if (i + 1 < end) {
                            brace_line = i + 1;
                        } else {
                            i++; continue;
                        }
                    }

                    int close_brace_line = find_matching_brace(i);
                    if (close_brace_line >= end) { i++; continue; }

                    /* 发射 JMP 跳过函数体 */
                    int jmp_addr = compiler_emit(comp, OP_JMP, 0, 0);

                    /* 记录函数入口（JMP 之后才是函数体） */
                    int func_addr = compiler_get_pc(comp);
                    compiler_add_function(comp, func_name, func_addr);

                    /* 编译函数体 */
                    /* 编译 brace_line 到 close_brace_line 之间的内容 */
                    if (brace_line == i) {
                        /* { 和函数定义在同一行，body 在 { 和 } 之间 */
                        /* 找到 { 之后的位置 */
                        char *line_copy = strdup(trimmed);
                        char *open_brace = strchr(line_copy, '{');
                        if (open_brace) {
                            char *body_str = open_brace + 1;
                            /* 找到匹配的 } */
                            char *close_brace = NULL;
                            int depth = 1;
                            char *sp = open_brace + 1;
                            while (*sp && depth > 0) {
                                if (*sp == '{') depth++;
                                else if (*sp == '}') { depth--; if (depth == 0) { close_brace = sp; break; } }
                                sp++;
                            }
                            if (close_brace) {
                                *close_brace = 0;
                                while (*body_str == ' ' || *body_str == '\t') body_str++;
                                /* trim trailing whitespace and ; */
                                char *be = body_str + strlen(body_str) - 1;
                                while (be > body_str && (*be == ' ' || *be == '\t' || *be == ';')) be--;
                                *(be + 1) = 0;
                                if (*body_str) compile_line(body_str);
                            }
                        }
                        free(line_copy);
                    } else if (close_brace_line > brace_line) {
                        /* body_start 是 brace_line 之后 */
                        compile_lines(brace_line, close_brace_line);
                    }

                    /* 发射 RET */
                    compiler_emit(comp, OP_RET, 0, 0);

                    /* 补丁 JMP */
                    int after_label = compiler_emit_label(comp);
                    compiler_patch_jump(comp, jmp_addr, after_label);

                    i = close_brace_line + 1;
                    continue;
                }
            }
        }

        /* ===== "; ;"  case clause 终止符 ===== */
        if (strcmp(trimmed, ";;") == 0) {
            i++; continue;
        }

        /* ===== HERE-DOC 预检测 ===== */
        {
            char *hh = find_unquoted_substr(trimmed, "<<");
            if (hh) {
                /* 确保不是 <<< (here-string) 或 <<- */
                char *next = hh + 2;
                if (*next != '<') {
                    /* 跳过 - 如果存在 */
                    int strip_tabs = 0;
                    if (*next == '-') { strip_tabs = 1; next++; }
                    while (*next == ' ' || *next == '\t') next++;

                    char delim[MAX_LINE];
                    int di = 0;
                    /* 处理引号包裹的定界符 */
                    if (*next == '"' || *next == '\'') {
                        char q = *next++;
                        while (*next && *next != q && di < MAX_LINE - 1) delim[di++] = *next++;
                        if (*next == q) next++;
                    } else {
                        while (*next && *next != ' ' && *next != '\t' && *next != ';' &&
                               *next != '\n' && *next != '>' && *next != '<' && *next != '|' &&
                               di < MAX_LINE - 1)
                            delim[di++] = *next++;
                    }
                    delim[di] = 0;

                    if (di > 0) {
                        /* 收集 here-doc 体 */
                        char body[MAX_HEREDOC_BODY];
                        body[0] = 0;
                        int body_len = 0;
                        int body_end_line = i;

                        for (int j = i + 1; j < end; j++) {
                            char *lt = script_lines[j].line;
                            if (strip_tabs) {
                                while (*lt == '\t') lt++;
                            }
                            if (strcmp(lt, delim) == 0) {
                                body_end_line = j;
                                break;
                            }
                            if (body_len > 0) {
                                strcat(body, "\n");
                                body_len++;
                            }
                            strcat(body, script_lines[j].line);
                            body_len += strlen(script_lines[j].line);
                        }

                        /* 剥离 << DELIM 部分，编译命令 */
                        *hh = 0;
                        char *cmd_end = hh - 1;
                        while (cmd_end > trimmed && (*cmd_end == ' ' || *cmd_end == '\t')) *cmd_end-- = 0;

                        if (*trimmed) {
                            compile_line(trimmed);
                        }

                        /* 发射 here-doc */
                        if (body[0]) {
                            int idx = compiler_add_string(comp, body);
                            compiler_emit(comp, OP_HEREDOC, idx, 0);
                        }

                        i = body_end_line + 1;
                        continue;
                    }
                }
            }
        }

        /* ===== FOR 循环 ===== */
        if (strncmp(trimmed, "for ", 4) == 0) {
            char *var_start = trimmed + 4;
            while (*var_start == ' ') var_start++;
            char *var_end = var_start;
            while (*var_end && !isspace(*var_end) && *var_end != '=') var_end++;
            if (*var_end == 0) { i++; continue; }

            char var_name[MAX_LINE];
            strncpy(var_name, var_start, var_end - var_start);
            var_name[var_end - var_start] = 0;

            char *in_pos = strstr(trimmed, " in ");
            if (!in_pos) { i++; continue; }

            char *list_start = in_pos + 4;
            char *do_pos = strstr(list_start, "; do");
            if (!do_pos) do_pos = strstr(list_start, "\tdo");
            if (!do_pos) do_pos = strstr(list_start, " do");

            char list_str[MAX_LINE];
            int body_start_line = i + 1;

            if (do_pos) {
                strncpy(list_str, list_start, do_pos - list_start);
                list_str[do_pos - list_start] = 0;
                body_start_line = i + 1;
            } else {
                if (i + 1 < end) {
                    char *next_line = script_lines[i + 1].line;
                    while (*next_line == ' ' || *next_line == '\t') next_line++;
                    if (strcmp(next_line, "do") == 0) {
                        strcpy(list_str, list_start);
                        body_start_line = i + 2;
                    } else if (strncmp(next_line, "do ", 3) == 0) {
                        strcpy(list_str, list_start);
                        body_start_line = i + 1;
                    } else {
                        i++; continue;
                    }
                } else {
                    i++; continue;
                }
            }

            int done_line = find_matching_done(i);

            /* 分词列表 */
            char *args[MAX_ARGS];
            int argc = tokenize_cmd(list_str, args, MAX_ARGS);

            /* 压入列表项 */
            for (int k = 0; k < argc; k++) {
                int idx = compiler_add_string(comp, args[k]);
                compiler_emit(comp, OP_PUSH_STR, idx, 0);
            }
            /* 压入列表计数 */
            compiler_emit(comp, OP_PUSH_INT, argc, 0);

            int var_idx = compiler_add_string(comp, var_name);
            compiler_emit(comp, OP_FOR_BEGIN, var_idx, 0);

            /* 循环体 */
            int loop_start = compiler_emit_label(comp);
            compile_lines(body_start_line, done_line);

            /* FOR_NEXT */
            int fn_addr = compiler_emit(comp, OP_FOR_NEXT, 0, 0);
            compiler_patch_jump(comp, fn_addr, loop_start);

            i = done_line + 1;
            continue;
        }

        /* ===== SELECT 循环 ===== */
        if (strncmp(trimmed, "select ", 7) == 0) {
            char *var_start = trimmed + 7;
            while (*var_start == ' ') var_start++;
            char *var_end = var_start;
            while (*var_end && !isspace(*var_end) && *var_end != '=') var_end++;
            if (*var_end == 0) { i++; continue; }

            char var_name[MAX_LINE];
            strncpy(var_name, var_start, var_end - var_start);
            var_name[var_end - var_start] = 0;

            char *in_pos = strstr(trimmed, " in ");
            if (!in_pos) { i++; continue; }

            char *list_start = in_pos + 4;
            char *do_pos = strstr(list_start, "; do");
            if (!do_pos) do_pos = strstr(list_start, "\tdo");
            if (!do_pos) do_pos = strstr(list_start, " do");

            char list_str[MAX_LINE];
            int body_start_line = i + 1;

            if (do_pos) {
                strncpy(list_str, list_start, do_pos - list_start);
                list_str[do_pos - list_start] = 0;
                body_start_line = i + 1;
            } else {
                if (i + 1 < end) {
                    char *next_line = script_lines[i + 1].line;
                    while (*next_line == ' ' || *next_line == '\t') next_line++;
                    if (strcmp(next_line, "do") == 0) {
                        strcpy(list_str, list_start);
                        body_start_line = i + 2;
                    } else if (strncmp(next_line, "do ", 3) == 0) {
                        strcpy(list_str, list_start);
                        body_start_line = i + 1;
                    } else {
                        i++; continue;
                    }
                } else {
                    i++; continue;
                }
            }

            int done_line = find_matching_done(i);

            /* 分词列表 */
            char *args[MAX_ARGS];
            int argc = tokenize_cmd(list_str, args, MAX_ARGS);

            /* 压入列表项 */
            for (int k = 0; k < argc; k++) {
                int idx = compiler_add_string(comp, args[k]);
                compiler_emit(comp, OP_PUSH_STR, idx, 0);
            }
            /* 压入列表计数 */
            compiler_emit(comp, OP_PUSH_INT, argc, 0);

            int var_idx = compiler_add_string(comp, var_name);
            compiler_emit(comp, OP_SELECT_BEG, var_idx, 0);

            /* 循环体 */
            compile_lines(body_start_line, done_line);

            /* SELECT_END */
            compiler_emit(comp, OP_SELECT_END, 0, 0);

            i = done_line + 1;
            continue;
        }

        /* ===== WHILE 循环 ===== */
        if (strncmp(trimmed, "while ", 6) == 0) {
            char *cond_start = trimmed + 6;
            while (*cond_start == ' ') cond_start++;

            char *do_pos = strstr(cond_start, "; do");
            if (!do_pos) do_pos = strstr(cond_start, "\tdo");
            if (!do_pos) do_pos = strstr(cond_start, " do");

            char condition[MAX_LINE];
            int body_start_line = i + 1;

            if (do_pos) {
                strncpy(condition, cond_start, do_pos - cond_start);
                condition[do_pos - cond_start] = 0;
                body_start_line = i + 1;
            } else {
                if (i + 1 < end) {
                    char *next_line = script_lines[i + 1].line;
                    while (*next_line == ' ' || *next_line == '\t') next_line++;
                    if (strcmp(next_line, "do") == 0) {
                        strcpy(condition, cond_start);
                        body_start_line = i + 2;
                    } else if (strncmp(next_line, "do ", 3) == 0) {
                        strcpy(condition, cond_start);
                        body_start_line = i + 1;
                    } else {
                        i++; continue;
                    }
                } else {
                    i++; continue;
                }
            }

            int done_line = find_matching_done(i);

            /* WHILE_BEG */
            compiler_emit(comp, OP_WHILE_BEG, 0, 0);

            /* 条件检查点 */
            int cond_label = compiler_emit_label(comp);

            /* 编译条件 */
            compile_condition(condition);

            /* 条件为假则跳出 */
            int jz_addr = compiler_emit(comp, OP_JZ, 0, 0);

            /* 编译循环体 */
            compile_lines(body_start_line, done_line);

            /* WHILE_END */
            int we_addr = compiler_emit(comp, OP_WHILE_END, 0, 0);
            compiler_patch_jump(comp, we_addr, cond_label);

            /* 补丁跳出位置 */
            int end_label = compiler_emit_label(comp);
            compiler_patch_jump(comp, jz_addr, end_label);

            i = done_line + 1;
            continue;
        }

        /* ===== UNTIL 循环 ===== */
        if (strncmp(trimmed, "until ", 6) == 0) {
            char *cond_start = trimmed + 6;
            while (*cond_start == ' ') cond_start++;

            char *do_pos = strstr(cond_start, "; do");
            if (!do_pos) do_pos = strstr(cond_start, "\tdo");
            if (!do_pos) do_pos = strstr(cond_start, " do");

            char condition[MAX_LINE];
            int body_start_line = i + 1;

            if (do_pos) {
                strncpy(condition, cond_start, do_pos - cond_start);
                condition[do_pos - cond_start] = 0;
                body_start_line = i + 1;
            } else {
                if (i + 1 < end) {
                    char *next_line = script_lines[i + 1].line;
                    while (*next_line == ' ' || *next_line == '\t') next_line++;
                    if (strcmp(next_line, "do") == 0) {
                        strcpy(condition, cond_start);
                        body_start_line = i + 2;
                    } else if (strncmp(next_line, "do ", 3) == 0) {
                        strcpy(condition, cond_start);
                        body_start_line = i + 1;
                    } else {
                        i++; continue;
                    }
                } else {
                    i++; continue;
                }
            }

            int done_line = find_matching_done(i);

            /* until 跟 while 一样，只是条件反转 */
            compiler_emit(comp, OP_WHILE_BEG, 0, 0);
            int cond_label = compiler_emit_label(comp);
            compile_condition(condition);
            /* until: 条件为真则跳出，所以用 JNZ */
            int jnz_addr = compiler_emit(comp, OP_JNZ, 0, 0);
            compile_lines(body_start_line, done_line);
            int we_addr = compiler_emit(comp, OP_WHILE_END, 0, 0);
            compiler_patch_jump(comp, we_addr, cond_label);
            int end_label = compiler_emit_label(comp);
            compiler_patch_jump(comp, jnz_addr, end_label);

            i = done_line + 1;
            continue;
        }

        /* ===== CASE / ESAC ===== */
        if (strncmp(trimmed, "case ", 5) == 0) {
            int esac_line = find_matching_esac(i);

            /* 提取变量名 */
            char *var_start = trimmed + 5;
            while (*var_start == ' ') var_start++;
            if (*var_start == '$') var_start++;  /* 去掉 $ 前缀 */
            char *in_pos = strstr(var_start, " in");
            if (!in_pos) { i++; continue; }

            char var_name[MAX_LINE];
            int vn_len = in_pos - var_start;
            /* trim trailing whitespace */
            while (vn_len > 0 && (var_start[vn_len-1] == ' ' || var_start[vn_len-1] == '\t')) vn_len--;
            strncpy(var_name, var_start, vn_len);
            var_name[vn_len] = 0;

            /* 加载变量值 */
            int var_idx = compiler_add_string(comp, var_name);
            compiler_emit(comp, OP_LOAD, var_idx, 0);

            int jmp_addrs[MAX_CLAUSES];
            int jmp_count = 0;

            /* 解析 case 子句 */
            int j = i + 1;
            while (j < esac_line) {
                char *lt = script_lines[j].line;
                while (*lt == ' ' || *lt == '\t') lt++;

                if (*lt == '#' || *lt == 0) { j++; continue; }
                if (strcmp(lt, "esac") == 0) break;
                if (strcmp(lt, "in") == 0) { j++; continue; }
                if (strcmp(lt, ";;") == 0) { j++; continue; }

                /* 查找 ) 作为模式和命令体的分界 */
                char *paren = find_unquoted_char(lt, ')');
                if (!paren) { j++; continue; }

                /* 提取模式 */
                char pattern[MAX_LINE];
                int plen = paren - lt;
                /* trim trailing whitespace */
                while (plen > 0 && (lt[plen-1] == ' ' || lt[plen-1] == '\t')) plen--;
                strncpy(pattern, lt, plen);
                pattern[plen] = 0;

                /* 命令体起始 */
                char *body_start = paren + 1;
                while (*body_start == ' ' || *body_start == '\t') body_start++;

                /* DUP 变量值 */
                compiler_emit(comp, OP_DUP, 0, 0);

                /* 推送模式并发射 OP_CASE */
                int pat_idx = compiler_add_string(comp, pattern);
                compiler_emit(comp, OP_CASE, pat_idx, 0);

                /* 模式不匹配则跳过 */
                int jz_addr = compiler_emit(comp, OP_JZ, 0, 0);

                /* 编译命令体: 如果 body 在同一行 */
                if (*body_start) {
                    /* 检查是否以 ;; 结尾 */
                    char *dsemi = find_unquoted_substr(body_start, ";;");
                    if (dsemi) {
                        *dsemi = 0;
                        if (*body_start) compile_line(body_start);
                        *dsemi = ';';
                    } else {
                        compile_line(body_start);
                    }
                }

                /* 编译后续行直到 ;; 或 esac */
                int clause_end = j;
                for (int k = j + 1; k < esac_line; k++) {
                    char *klt = script_lines[k].line;
                    while (*klt == ' ' || *klt == '\t') klt++;
                    if (strcmp(klt, ";;") == 0) {
                        clause_end = k;
                        break;
                    }
                    if (strcmp(klt, "esac") == 0) {
                        clause_end = k;
                        break;
                    }
                    /* 检查是否包含 ;; */
                    char *ds = find_unquoted_substr(klt, ";;");
                    if (ds) {
                        *ds = 0;
                        char *ks = klt;
                        while (*ks == ' ' || *ks == '\t') ks++;
                        if (*ks) compile_line(ks);
                        *ds = ';';
                        clause_end = k;
                        break;
                    }
                    /* 如果在行末找到 ) 且不是第一个非空白字符，则可能是新 clause */
                    char *next_paren = find_unquoted_char(klt, ')');
                    if (next_paren && next_paren > klt) {
                        /* 检查 ) 前面是否只有空白和模式字符 */
                        int is_new_clause = 1;
                        for (char *cp = klt; cp < next_paren; cp++) {
                            if (*cp != ' ' && *cp != '\t' && *cp != '*' && *cp != '?' &&
                                *cp != '[' && *cp != ']' && *cp != '|' &&
                                !isalnum(*cp) && *cp != '_' && *cp != '.' && *cp != '-') {
                                /* 非模式字符，可能不是新 clause */
                                is_new_clause = 0;
                                break;
                            }
                        }
                        if (is_new_clause) {
                            clause_end = k - 1;
                            break;
                        }
                    }
                }

                /* 编译命令体中的剩余行 */
                if (clause_end > j) {
                    /* 从 j+1 到 clause_end 编译 */
                    if (clause_end > j + 1) {
                        compile_lines(j + 1, clause_end);
                    }
                }

                j = clause_end;

                /* 跳转到 esac 结束 */
                int jmp_addr = compiler_emit(comp, OP_JMP, 0, 0);
                jmp_addrs[jmp_count++] = jmp_addr;

                /* 补丁 JZ */
                int skip_label = compiler_emit_label(comp);
                compiler_patch_jump(comp, jz_addr, skip_label);

                j++;
            }

            /* 弹出原始变量值 */
            compiler_emit(comp, OP_POP, 0, 0);

            /* 发射 CASE_END */
            compiler_emit(comp, OP_CASE_END, 0, 0);

            /* 补丁所有 JMP */
            int case_end_label = compiler_emit_label(comp);
            for (int k = 0; k < jmp_count; k++) {
                compiler_patch_jump(comp, jmp_addrs[k], case_end_label);
            }

            i = esac_line + 1;
            continue;
        }

        /* ===== IF 语句 ===== */
        if (strncmp(trimmed, "if ", 3) == 0) {
            /* 单行 if 快速路径: if cond; then A; [elif ...; then B;] [else C]; fi
             * 检测到 ; then 和 ; fi/else 都在同一行 (同行内) → 在此处切分处理
             */
            {
                char *sl_then_inline = strstr(trimmed, "; then");
                if (!sl_then_inline) sl_then_inline = strstr(trimmed, " then");
                if (sl_then_inline) {
                    /* 检查 fi/else 是否也在同一行 (说明整个 if 都在一行) */
                    char *p_scan = sl_then_inline + 1;
                    int has_inline_close = 0;
                    int depth = 0;
                    while (*p_scan) {
                        if (*p_scan == '"' || *p_scan == '\'') {
                            char q = *p_scan++;
                            while (*p_scan && *p_scan != q) p_scan++;
                            if (*p_scan) p_scan++;
                            continue;
                        }
                        if (strncmp(p_scan, "else", 4) == 0 &&
                            (p_scan[4] == ' ' || p_scan[4] == ';' || p_scan[4] == 0)) {
                            has_inline_close = 1; break;
                        }
                        if (strncmp(p_scan, "elif", 4) == 0 &&
                            (p_scan[4] == ' ' || p_scan[4] == 0)) {
                            has_inline_close = 1; break;
                        }
                        if (strncmp(p_scan, "fi", 2) == 0 &&
                            (p_scan[2] == ' ' || p_scan[2] == ';' || p_scan[2] == 0)) {
                            has_inline_close = 1; break;
                        }
                        p_scan++;
                    }
                    if (has_inline_close) {
                        /* 单行 if — 切分为多个分支, 直接编译 */
                        char line_copy[MAX_LINE * 2];
                        strncpy(line_copy, trimmed, MAX_LINE * 2 - 1);
                        line_copy[MAX_LINE * 2 - 1] = 0;
                        /* 切掉开头的 "if " */
                        char *cur = line_copy + 3;
                        /* 解析 cond: 直到 ; then */
                        char *then_pos = strstr(cur, "; then");
                        if (!then_pos) then_pos = strstr(cur, " then");
                        /* cond 字符串 */
                        char cond_str[MAX_LINE]; int ci = 0;
                        char *cp = cur;
                        while (cp < then_pos && ci < MAX_LINE - 1) cond_str[ci++] = *cp++;
                        cond_str[ci] = 0;
                        /* 去 cond_str 尾部的 ' then' 后的空格 */
                        char *cpe = cond_str + ci - 1;
                        while (cpe > cond_str && (*cpe == ' ' || *cpe == '\t')) *cpe-- = 0;

                        /* 收集分支: (cond, body, is_else) */
                        typedef struct { char *cond; char *body; int is_else; } IB;
                        IB ibranches[8]; int ibc = 0;
                        char *seg = then_pos;
                        /* 跳过 ; then /  then */
                        if (*seg == ';') seg++;
                        while (*seg == ' ' || *seg == '\t') seg++;
                        if (strncmp(seg, "then", 4) == 0) {
                            seg += 4;
                            while (*seg == ' ' || *seg == '\t') seg++;
                        }
                        /* 当前 cond 已确定: cur_cond = cond_str */
                        ibranches[ibc].cond = strdup(cond_str);
                        ibranches[ibc].is_else = 0;
                        /* 解析 body: 直到 ; else 或 ; fi 或 ; elif */
                        char *body_start = seg;
                        char *seg_end = body_start + strlen(body_start);
                        char *body_end = seg_end;
                        /* 找到 ; fi 或 ; else 或 ; elif */
                        {
                            char *p2 = body_start;
                            int d2 = 0;
                            while (*p2) {
                                if (*p2 == '"' || *p2 == '\'') {
                                    char q = *p2++; while (*p2 && *p2 != q) p2++;
                                    if (*p2) p2++; continue;
                                }
                                if (p2[0] == ';' && (p2[1] == ' ' || p2[1] == '\t')) {
                                    char *kw = p2 + 2;
                                    while (*kw == ' ' || *kw == '\t') kw++;
                                    if (strncmp(kw, "fi", 2) == 0 && (kw[2] == 0 || kw[2] == ' ' || kw[2] == ';' || kw[2] == '\t')) {
                                        body_end = p2; break;
                                    }
                                    if (strncmp(kw, "else", 4) == 0 && (kw[4] == 0 || kw[4] == ' ' || kw[4] == ';' || kw[4] == '\t')) {
                                        body_end = p2; break;
                                    }
                                    if (strncmp(kw, "elif", 4) == 0 && (kw[4] == 0 || kw[4] == ' ')) {
                                        body_end = p2; break;
                                    }
                                }
                                p2++;
                            }
                        }
                        *body_end = 0;
                        ibranches[ibc].body = strdup(body_start);
                        ibc++;

                        /* 处理后续 elif/else */
                        char *rest = body_end + 1;
                        while (*rest == ' ' || *rest == '\t' || *rest == ';') rest++;
                        while (strncmp(rest, "elif", 4) == 0 && (rest[4] == ' ' || rest[4] == 0)) {
                            rest += 4;
                            while (*rest == ' ' || *rest == '\t') rest++;
                            /* 解析 cond 直到 ; then */
                            char *et = strstr(rest, "; then");
                            if (!et) et = strstr(rest, " then");
                            if (!et) break;
                            char cc[MAX_LINE]; int cci = 0;
                            while (rest < et && cci < MAX_LINE - 1) cc[cci++] = *rest++;
                            cc[cci] = 0;
                            char *cce = cc + cci - 1;
                            while (cce > cc && (*cce == ' ' || *cce == '\t')) *cce-- = 0;
                            /* 跳到 then 后 */
                            char *tt = et;
                            if (*tt == ';') tt++;
                            while (*tt == ' ' || *tt == '\t') tt++;
                            if (strncmp(tt, "then", 4) == 0) {
                                tt += 4;
                                while (*tt == ' ' || *tt == '\t') tt++;
                            }
                            /* 找 body 结束 */
                            char *bs2 = tt;
                            char *be2 = bs2 + strlen(bs2);
                            {
                                char *p2 = bs2;
                                while (*p2) {
                                    if (*p2 == '"' || *p2 == '\'') {
                                        char q = *p2++; while (*p2 && *p2 != q) p2++;
                                        if (*p2) p2++; continue;
                                    }
                                    if (p2[0] == ';' && (p2[1] == ' ' || p2[1] == '\t')) {
                                        char *kw = p2 + 2;
                                        while (*kw == ' ' || *kw == '\t') kw++;
                                        if (strncmp(kw, "fi", 2) == 0 && (kw[2] == 0 || kw[2] == ' ' || kw[2] == ';' || kw[2] == '\t')) { be2 = p2; break; }
                                        if (strncmp(kw, "else", 4) == 0 && (kw[4] == 0 || kw[4] == ' ' || kw[4] == ';' || kw[4] == '\t')) { be2 = p2; break; }
                                        if (strncmp(kw, "elif", 4) == 0 && (kw[4] == 0 || kw[4] == ' ')) { be2 = p2; break; }
                                    }
                                    p2++;
                                }
                            }
                            *be2 = 0;
                            ibranches[ibc].cond = strdup(cc);
                            ibranches[ibc].body = strdup(bs2);
                            ibranches[ibc].is_else = 0;
                            ibc++;
                            rest = be2 + 1;
                            while (*rest == ' ' || *rest == '\t' || *rest == ';') rest++;
                        }
                        /* 处理 else */
                        if (strncmp(rest, "else", 4) == 0 && (rest[4] == 0 || rest[4] == ' ' || rest[4] == ';')) {
                            rest += 4;
                            while (*rest == ' ' || *rest == '\t' || *rest == ';') rest++;
                            char *bs3 = rest;
                            /* body 直到 ; fi */
                            char *be3 = bs3 + strlen(bs3);
                            {
                                char *p2 = bs3;
                                while (*p2) {
                                    if (*p2 == '"' || *p2 == '\'') {
                                        char q = *p2++; while (*p2 && *p2 != q) p2++;
                                        if (*p2) p2++; continue;
                                    }
                                    if (p2[0] == ';' && (p2[1] == ' ' || p2[1] == '\t')) {
                                        char *kw = p2 + 2;
                                        while (*kw == ' ' || *kw == '\t') kw++;
                                        if (strncmp(kw, "fi", 2) == 0 && (kw[2] == 0 || kw[2] == ' ' || kw[2] == ';' || kw[2] == '\t')) { be3 = p2; break; }
                                    }
                                    p2++;
                                }
                            }
                            *be3 = 0;
                            ibranches[ibc].cond = NULL;
                            ibranches[ibc].body = strdup(bs3);
                            ibranches[ibc].is_else = 1;
                            ibc++;
                        }

                        /* 生成跳转链 */
                        int jmp_addrs[8]; int jmp_count = 0;
                        int has_else = 0;
                        for (int b = 0; b < ibc; b++) {
                            if (ibranches[b].is_else) {
                                has_else = 1;
                                if (ibranches[b].body && *ibranches[b].body)
                                    compile_line(ibranches[b].body);
                            } else {
                                compile_condition(ibranches[b].cond);
                                int jz_addr = compiler_emit(comp, OP_JZ, 0, 0);
                                if (ibranches[b].body && *ibranches[b].body)
                                    compile_line(ibranches[b].body);
                                if (b < ibc - 1 || has_else) {
                                    int jmp_addr = compiler_emit(comp, OP_JMP, 0, 0);
                                    jmp_addrs[jmp_count++] = jmp_addr;
                                }
                                int end_label = compiler_emit_label(comp);
                                compiler_patch_jump(comp, jz_addr, end_label);
                            }
                            free(ibranches[b].cond);
                            free(ibranches[b].body);
                        }
                        int final_label = compiler_emit_label(comp);
                        for (int k = 0; k < jmp_count; k++) {
                            compiler_patch_jump(comp, jmp_addrs[k], final_label);
                        }
                        i++;
                        continue;
                    }
                }
            }

            int fi_line = find_matching_fi(i);

            typedef struct {
                int cond_line;
                int body_start;
                int body_end;
                int is_else;
                char *inline_body;  /* else 同行 body (单行 if-else 用) */
            } Branch;
            Branch branches[MAX_BRANCHES];
            int branch_count = 0;

            int cur_cond_line = i;
            int cur_body_start = -1;

            {
                char *sl_then = strstr(trimmed, "; then");
                if (!sl_then) sl_then = strstr(trimmed, " then");
                if (sl_then) cur_body_start = i + 1;
            }

            for (int j = i + 1; j < fi_line; j++) {
                char *lt = script_lines[j].line;
                while (*lt == ' ' || *lt == '\t') lt++;
                if (*lt == '#' || *lt == 0) continue;

                if (strcmp(lt, "then") == 0) {
                    cur_body_start = j + 1;
                    continue;
                }
                if (strncmp(lt, "then ", 5) == 0 || strncmp(lt, "then\t", 5) == 0) {
                    cur_body_start = j;
                    continue;
                }

                if (strncmp(lt, "elif ", 5) == 0) {
                    if (cur_body_start != -1 && branch_count < MAX_BRANCHES) {
                        branches[branch_count].cond_line = cur_cond_line;
                        branches[branch_count].body_start = cur_body_start;
                        branches[branch_count].body_end = j;
                        branches[branch_count].is_else = 0;
                        branch_count++;
                    }
                    cur_cond_line = j;
                    cur_body_start = -1;
                    {
                        char *sl_then = strstr(lt, "; then");
                        if (!sl_then) sl_then = strstr(lt, " then");
                        if (sl_then) cur_body_start = j + 1;
                    }
                    continue;
                }

                if (strcmp(lt, "else") == 0 ||
                    (strncmp(lt, "else", 4) == 0 && (lt[4] == ' ' || lt[4] == '\t' || lt[4] == ';'))) {
                    if (cur_body_start != -1 && branch_count < MAX_BRANCHES) {
                        branches[branch_count].cond_line = cur_cond_line;
                        branches[branch_count].body_start = cur_body_start;
                        branches[branch_count].body_end = j;
                        branches[branch_count].is_else = 0;
                        branches[branch_count].inline_body = NULL;
                        branch_count++;
                    }
                    cur_cond_line = j;
                    cur_body_start = -1;
                    /* else 后面可能带 body 在同一行 — 提取出来作为字符串保存 */
                    {
                        char *p = lt + 4;
                        while (*p == ' ' || *p == '\t' || *p == ';') p++;
                        if (*p) {
                            char *ib = strdup(p);
                            /* 去除尾部分号 */
                            int bl = strlen(ib);
                            while (bl > 0 && (ib[bl-1] == ';' || ib[bl-1] == ' ' || ib[bl-1] == '\t')) ib[--bl] = 0;
                            if (branch_count < MAX_BRANCHES) {
                                branches[branch_count].cond_line = -1;
                                branches[branch_count].body_start = 0;
                                branches[branch_count].body_end = 0;
                                branches[branch_count].is_else = 1;
                                branches[branch_count].inline_body = ib;
                                branch_count++;
                            }
                        }
                    }
                    continue;
                }

                if (strcmp(lt, "fi") == 0 ||
                    (strncmp(lt, "fi", 2) == 0 && (lt[2] == ' ' || lt[2] == '\t' || lt[2] == ';'))) {
                    /* fi 关闭 if — 不需要单独处理, find_matching_fi 已经定位 */
                    continue;
                }
            }

            if (cur_body_start != -1 && branch_count < MAX_BRANCHES) {
                branches[branch_count].cond_line = cur_cond_line;
                branches[branch_count].body_start = cur_body_start;
                branches[branch_count].body_end = fi_line;
                char *lt = script_lines[cur_cond_line].line;
                while (*lt == ' ' || *lt == '\t') lt++;
                branches[branch_count].is_else = (strcmp(lt, "else") == 0 ||
                    (strncmp(lt, "else", 4) == 0 && (lt[4] == ' ' || lt[4] == '\t' || lt[4] == ';')));
                branches[branch_count].inline_body = NULL;
                branch_count++;
            }

            /* 生成跳转链 */
            int jmp_addrs[MAX_BRANCHES];
            int jmp_count = 0;
            int has_else = 0;

            for (int b = 0; b < branch_count; b++) {
                if (branches[b].is_else) {
                    has_else = 1;
                    if (branches[b].inline_body) {
                        compile_line(branches[b].inline_body);
                    } else {
                        compile_lines(branches[b].body_start, branches[b].body_end);
                    }
                } else {
                    char *cl = script_lines[branches[b].cond_line].line;
                    while (*cl == ' ' || *cl == '\t') cl++;

                    const char *cond_str;
                    if (strncmp(cl, "if ", 3) == 0) cond_str = cl + 3;
                    else if (strncmp(cl, "elif ", 5) == 0) cond_str = cl + 5;
                    else cond_str = cl;

                    compile_condition(cond_str);
                    int jz_addr = compiler_emit(comp, OP_JZ, 0, 0);
                    compile_lines(branches[b].body_start, branches[b].body_end);

                    if (b < branch_count - 1 || has_else) {
                        int jmp_addr = compiler_emit(comp, OP_JMP, 0, 0);
                        jmp_addrs[jmp_count++] = jmp_addr;
                    }

                    int end_label = compiler_emit_label(comp);
                    compiler_patch_jump(comp, jz_addr, end_label);
                }
            }
            /* 释放 inline_body 字符串 */
            for (int b = 0; b < branch_count; b++) {
                if (branches[b].inline_body) free(branches[b].inline_body);
            }

            /* 补丁所有 JMP */
            int final_label = compiler_emit_label(comp);
            for (int k = 0; k < jmp_count; k++) {
                compiler_patch_jump(comp, jmp_addrs[k], final_label);
            }

            i = fi_line + 1;
            continue;
        }

        /* ===== 多行 { } 匿名块 ===== */
        if (*trimmed == '{') {
            int brace_depth = 0;
            int block_start = i;
            int block_end = -1;

            for (int j = i; j < end; j++) {
                char *bl = script_lines[j].line;
                while (*bl == ' ' || *bl == '\t') bl++;
                char *c = bl;
                char quote = 0;
                while (*c) {
                    if (quote) {
                        if (*c == '\\' && *(c+1) && quote == '"') { c += 2; continue; }
                        if (*c == quote) quote = 0;
                        c++; continue;
                    }
                    if (*c == '"' || *c == '\'') { quote = *c; c++; continue; }
                    if (*c == '$' && *(c+1) == '(') {
                        int d = 1; c += 2;
                        if (*c == '(') { c++; d++; }
                        while (*c && d > 0) {
                            if (*c == '(') d++;
                            else if (*c == ')') d--;
                            if (d > 0) c++;
                        }
                        if (*c == ')') c++;
                        continue;
                    }
                    if (*c == '[' && *(c+1) == '[') {
                        c += 2;
                        while (*c) { if (*c == ']' && *(c+1) == ']') { c += 2; break; } c++; }
                        continue;
                    }
                    if (*c == '{') brace_depth++;
                    else if (*c == '}') {
                        brace_depth--;
                        if (brace_depth == 0) { block_end = j; break; }
                    }
                    c++;
                }
                if (block_end >= 0) break;
            }

            if (block_end >= 0) {
                compiler_emit(comp, OP_BLOCK_BEG, 0, 0);

                /* 检查 { 同行是否有命令 */
                char *after_brace = trimmed + 1;
                while (*after_brace == ' ' || *after_brace == '\t') after_brace++;
                if (*after_brace && *after_brace != '}') {
                    char *close_brace = strchr(after_brace, '}');
                    if (close_brace) {
                        *close_brace = 0;
                        compile_line(after_brace);
                        *close_brace = '}';
                    }
                }

                if (block_end > block_start + 1) {
                    compile_lines(block_start + 1, block_end);
                }

                compiler_emit(comp, OP_BLOCK_END, 0, 0);
                i = block_end + 1;
                continue;
            }
        }

        /* 跳过 } */
        if (strcmp(trimmed, "}") == 0) { i++; continue; }

        /* 普通命令 */
        compile_line(trimmed);
        i++;
    }
}

/* 编译脚本 */
static void compile_script(const char *input_file, const char *output_file) {
    FILE *fp = fopen(input_file, "r");
    if (!fp) {
        fprintf(stderr, "bashc_compile: cannot open '%s'\n", input_file);
        exit(1);
    }

    /* 初始化编译器 */
    comp = malloc(sizeof(Compiler));
    if (!comp) { fprintf(stderr, "bashc_compile: out of memory\n"); exit(1); }
    compiler_init(comp);

    /* 读入全部行并智能拆分 */
    script_line_count = 0;
    char line_buf[MAX_LINE];

    while (fgets(line_buf, sizeof(line_buf), fp)) {
        line_buf[strcspn(line_buf, "\n")] = 0;
        line_buf[strcspn(line_buf, "\r")] = 0;

        char *p = line_buf;
        char quote = 0;
        char *seg_start = line_buf;

        while (*p) {
            if (!quote && (*p == '"' || *p == '\'')) {
                quote = *p;
            } else if (quote && *p == quote) {
                quote = 0;
            }
            /* ;; 处理: 将 ;; 拆分为独立行 */
            else if (!quote && *p == ';' && *(p+1) == ';') {
                /* 保存 ;; 之前的内容 */
                char tmp[MAX_LINE];
                int len = p - seg_start;
                if (len > 0) {
                    strncpy(tmp, seg_start, len);
                    tmp[len] = 0;
                    char *s = tmp;
                    while (*s == ' ') s++;
                    char *e = s + strlen(s) - 1;
                    while (e > s && *e == ' ') *e-- = 0;
                    if (*s && script_line_count < MAX_LINES) {
                        script_lines[script_line_count].line = strdup(s);
                        script_lines[script_line_count].line_number = script_line_count;
                        script_line_count++;
                    }
                }
                /* 保存 ;; 作为独立行 */
                if (script_line_count < MAX_LINES) {
                    script_lines[script_line_count].line = strdup(";;");
                    script_lines[script_line_count].line_number = script_line_count;
                    script_line_count++;
                }
                seg_start = p + 2;
                p += 1; /* p++ at end of loop makes it +2 total */
            }
            else if (!quote && *p == ';') {
                char *after = p + 1;
                while (*after == ' ') after++;

                int should_split = 0;
                /* 切分条件: ; 之后是 then/do/elif/done/fi (block 边界)
                 * else 后面跟 body 也切, 但由 if 块单独处理 inline body */
                if (strncmp(after, "then", 4) == 0 &&
                    (after[4] == 0 || after[4] == ' ' || after[4] == ';' || after[4] == '\t'))
                    should_split = 1;
                else if (strncmp(after, "do", 2) == 0 &&
                    (after[2] == 0 || after[2] == ' ' || after[2] == ';' || after[2] == '\t'))
                    should_split = 1;
                else if (strncmp(after, "fi", 2) == 0 &&
                    (after[2] == 0 || after[2] == ' ' || after[2] == ';' || after[2] == '\t'))
                    should_split = 1;
                else if (strncmp(after, "done", 4) == 0 &&
                    (after[4] == 0 || after[4] == ' ' || after[4] == ';' || after[4] == '\t'))
                    should_split = 1;
                else if (strncmp(after, "else", 4) == 0 &&
                    (after[4] == 0 || after[4] == ' ' || after[4] == ';' || after[4] == '\t'))
                    should_split = 1;
                else if (strncmp(after, "elif ", 5) == 0)
                    should_split = 1;
                else if (strncmp(after, "esac", 4) == 0 &&
                    (after[4] == 0 || after[4] == ' ' || after[4] == ';' || after[4] == '\t'))
                    should_split = 1;

                if (should_split) {
                    char tmp[MAX_LINE];
                    int len = p - seg_start;
                    strncpy(tmp, seg_start, len);
                    tmp[len] = 0;
                    char *s = tmp;
                    while (*s == ' ') s++;
                    char *e = s + strlen(s) - 1;
                    while (e > s && *e == ' ') *e-- = 0;
                    if (*s && script_line_count < MAX_LINES) {
                        script_lines[script_line_count].line = strdup(s);
                        script_lines[script_line_count].line_number = script_line_count;
                        script_line_count++;
                    }
                    seg_start = p + 1;
                    while (*seg_start == ' ') seg_start++;

                    /* 特殊处理: ; 后面是 do/then 且后面还有内容时
                     * 把关键字自身切出来作为独立行, 剩余内容作为新的独立行.
                     * 例如 "for X; do if [ ... ]" -> ["for X", "do", "if [ ... ]"] */
                    if (seg_start != p + 1 && *seg_start) {
                        /* 检查 after 是否是 do/then 且后面还有 body */
                        char *kw = seg_start;
                        int kw_len = 0;
                        int is_kw = 0;
                        if (strncmp(kw, "do", 2) == 0 &&
                            (kw[2] == ' ' || kw[2] == '\t' || kw[2] == ';' || kw[2] == 0)) {
                            kw_len = 2; is_kw = 1;
                        } else if (strncmp(kw, "then", 4) == 0 &&
                            (kw[4] == ' ' || kw[4] == '\t' || kw[4] == ';' || kw[4] == 0)) {
                            kw_len = 4; is_kw = 1;
                        } else if (strncmp(kw, "elif", 4) == 0 &&
                            (kw[4] == ' ' || kw[4] == 0)) {
                            kw_len = 4; is_kw = 1;
                        }
                        if (is_kw) {
                            char *body = kw + kw_len;
                            while (*body == ' ' || *body == '\t' || *body == ';') body++;
                            if (*body) {
                                /* 切出关键字作为独立行 */
                                char kwbuf[16]; int kbi = 0;
                                while (kbi < kw_len && kbi < 15) kwbuf[kbi++] = kw[kbi];
                                kwbuf[kbi] = 0;
                                script_lines[script_line_count].line = strdup(kwbuf);
                                script_lines[script_line_count].line_number = script_line_count;
                                script_line_count++;
                                /* 剩余 body 作为新段 */
                                seg_start = body;
                            }
                        }
                    }
                }
            }
            p++;
        }

        /* 最后一段 */
        if (*seg_start && script_line_count < MAX_LINES) {
            char tmp[MAX_LINE];
            strcpy(tmp, seg_start);
            char *s = tmp;
            while (*s == ' ') s++;
            char *e = s + strlen(s) - 1;
            while (e > s && *e == ' ') *e-- = 0;
            if (*s) {
                script_lines[script_line_count].line = strdup(s);
                script_lines[script_line_count].line_number = script_line_count;
                script_line_count++;
            }
        }
    }
    fclose(fp);

    /* 编译所有行 */
    compile_lines(0, script_line_count);

    /* 结束指令 */
    compiler_emit(comp, OP_HALT, 0, 0);

    /* 调试输出 */
    compiler_dump(comp);

    /* 保存字节码 */
    compiler_save(comp, output_file);

    printf("Compiled %d lines to %s\n", script_line_count, output_file);

    /* 清理 */
    for (int i = 0; i < script_line_count; i++) {
        free(script_lines[i].line);
    }
    free(comp);
}

/* ========== 主函数 ========== */
int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <input.sh> <output.bc>\n", argv[0]);
        return 1;
    }

    compile_script(argv[1], argv[2]);
    return 0;
}