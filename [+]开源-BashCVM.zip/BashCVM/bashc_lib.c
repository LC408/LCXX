/*
 * Copyright (c) [2026] 难忘 743225426@qq.com
 *
 * This file is part of [Project Name], licensed under the Custom Source
 * Code License v1.0. You may use, modify, and distribute this file,
 * including in closed-source form, provided that this copyright and
 * license header is fully retained and no commercial charge is made.
 * See the LICENSE file for full terms.
 */
 
/*
 * bashc_lib.c — 编译器辅助函数 + 内置命令表
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "bashc.h"

/* ========== 内置命令表 ========== */
const BuiltinEntry builtin_table[] = {
    {"echo",     BID_ECHO},     {"cd",       BID_CD},
    {"pwd",      BID_PWD},      {"exit",     BID_EXIT},
    {"read",     BID_READ},     {"export",   BID_EXPORT},
    {"unset",    BID_UNSET},    {"true",     BID_TRUE},
    {"false",    BID_FALSE},    {"break",    BID_BREAK},
    {"continue", BID_CONTINUE}, {"source",   BID_SOURCE},
    {".",        BID_SOURCE},   {"eval",     BID_EVAL},
    {"exec",     BID_EXEC},     {"shift",    BID_SHIFT},
    {"set",      BID_SET},      {"printf",   BID_PRINTF},
    {"let",      BID_LET},      {"alias",    BID_ALIAS},
    {"unalias",  BID_UNALIAS},  {"type",     BID_TYPE},
    {"wait",     BID_WAIT},     {"jobs",     BID_JOBS},
    {"bg",       BID_BG},       {"fg",       BID_FG},
    {"kill",     BID_KILL},     {"umask",    BID_UMASK},
    {"ulimit",   BID_ULIMIT},   {"times",    BID_TIMES},
    {"trap",     BID_TRAP},     {"getopts",  BID_GETOPTS},
    {"declare",  BID_DECLARE},  {"typeset",  BID_DECLARE},
    {"local",    BID_LOCAL},    {"mapfile",  BID_MAPFILE},
    {"readarray",BID_MAPFILE},  {"compgen",  BID_COMPGEN},
    {"complete", BID_COMPLETE}, {"enable",   BID_ENABLE},
    {"builtin",  BID_BUILTIN},  {"caller",   BID_CALLER},
    {"dirs",     BID_DIRS},     {"pushd",    BID_PUSHD},
    {"popd",     BID_POPD},     {"disown",   BID_DISOWN},
    {"shopt",    BID_SHOPT},    {"suspend",  BID_SUSPEND},
    {"test",     BID_TEST},     {"[",        BID_TEST},
    {"hash",     BID_HASH},     {"bind",     BID_BIND},
    {"help",     BID_HELP},     {"history",  BID_HISTORY},
    {"logout",   BID_LOGOUT},
    /* 扩展内置命令 */
    {"cat",      BID_CAT},      {"cp",       BID_CP},
    {"mv",       BID_MV},       {"rm",       BID_RM},
    {"mkdir",    BID_MKDIR},    {"rmdir",    BID_RMDIR},
    {"touch",    BID_TOUCH},    {"chmod",    BID_CHMOD},
    {"chown",    BID_CHOWN},    {"ln",       BID_LN},
    {"stat",     BID_STAT},     {"basename", BID_BASENAME},
    {"dirname",  BID_DIRNAME},  {"realpath", BID_REALPATH},
    {"mktemp",   BID_MKTEMP},   {"tee",      BID_TEE},
    {"head",     BID_HEAD},     {"tail",     BID_TAIL},
    {"wc",       BID_WC},       {"tr",       BID_TR},
    {"cut",      BID_CUT},      {"sort",     BID_SORT},
    {"uniq",     BID_UNIQ},     {"diff",     BID_DIFF},
    {"find",     BID_FIND},     {"grep",     BID_GREP},
    {"du",       BID_DU},       {"df",       BID_DF},
    {"which",    BID_WHICH},    {"whereis",  BID_WHEREIS},
    {"file",     BID_FILE},     {"seq",      BID_SEQ},
    {"sleep",    BID_SLEEP},    {"date",     BID_DATE},
    {"env",      BID_ENV},      {"printenv", BID_PRINTENV},
    {"hostname", BID_HOSTNAME}, {"id",       BID_ID},
    {"whoami",   BID_WHOAMI},   {"uname",    BID_UNAME},
    {"tty",      BID_TTY},      {"clear",    BID_CLEAR},
    {"reset",    BID_RESET},    {"yes",      BID_YES},
    {"xargs",    BID_XARGS},    {"paste",    BID_PASTE},
    {"sha1sum",  BID_SHA1SUM},  {"sha256sum",BID_SHA256SUM},
    {"md5sum",   BID_MD5SUM},   {"base64",   BID_BASE64},
    {"comm",     BID_COMM},     {"join",     BID_JOIN},
    {"nl",       BID_NL},       {"od",       BID_OD},
    {"expand",   BID_EXPAND},   {"expr",     BID_EXPR},
    {"cmp",      BID_CMP},      {"dd",       BID_DD},
    {"split",    BID_SPLIT},    {"cscope",   BID_CSCOPE},
    {"ctags",    BID_CTAGS},    {"nm",       BID_NM},
    {"size",     BID_SIZE},     {"strings",  BID_STRINGS},
    {"strip",    BID_STRIP},    {"ar",       BID_AR},
    {"ranlib",   BID_RANLIB},   {"objdump",  BID_OBJDUMP},
    {"readelf",  BID_READELF},  {"gdb",      BID_GDB},
    {"make",     BID_MAKE},
};
const int builtin_table_size = sizeof(builtin_table) / sizeof(builtin_table[0]);

/* ========== 编译器实现 ========== */

int compiler_init(Compiler *c) {
    memset(c, 0, sizeof(*c));
    return 0;
}

int compiler_add_string(Compiler *c, const char *s) {
    if (!s) s = "";
    for (int i = 0; i < c->str_count; i++) {
        if (strcmp(c->strings[i].data, s) == 0)
            return i;
    }
    if (c->str_count >= MAX_STR_TABLE) return -1;
    int idx = c->str_count++;
    c->strings[idx].data = strdup(s);
    c->strings[idx].len  = strlen(s);
    return idx;
}

int compiler_find_string(Compiler *c, const char *s) {
    for (int i = 0; i < c->str_count; i++) {
        if (strcmp(c->strings[i].data, s) == 0)
            return i;
    }
    return -1;
}

int compiler_emit(Compiler *c, Opcode op, int32_t a, int32_t b) {
    if (c->code_size + 10 > MAX_CODE) return -1;
    int operand_addr = c->code_size + 1;
    c->code[c->code_size++] = (uint8_t)op;
    int n = opcode_operand_count(op);
    if (n >= 1) {
        memcpy(c->code + c->code_size, &a, 4);
        c->code_size += 4;
    }
    if (n >= 2) {
        memcpy(c->code + c->code_size, &b, 4);
        c->code_size += 4;
    }
    return operand_addr;
}

int compiler_emit_label(Compiler *c) {
    if (c->label_count >= MAX_CODE) return -1;
    int id = c->label_count++;
    c->labels[id] = c->code_size;
    return id;
}

void compiler_patch_jump(Compiler *c, int jump_addr, int target_label) {
    if (target_label < 0 || target_label >= c->label_count) return;
    int target_pc = c->labels[target_label];
    memcpy(c->code + jump_addr, &target_pc, 4);
}

int compiler_emit_jump_with_patch(Compiler *c, Opcode op) {
    int addr = c->code_size + 1;
    compiler_emit(c, op, 0, 0);
    return addr;
}

int compiler_get_pc(Compiler *c) {
    return c->code_size;
}

void compiler_patch_here(Compiler *c, int jump_addr) {
    int pc = c->code_size;
    memcpy(c->code + jump_addr, &pc, 4);
}

int compiler_add_function(Compiler *c, const char *name, int addr) {
    if (c->func_count >= MAX_FUNCTIONS) return -1;
    c->functions[c->func_count].name = strdup(name);
    c->functions[c->func_count].addr = addr;
    c->functions[c->func_count].argc = 0;
    /* 把函数名加入字符串表, 这样后续能找到 */
    compiler_add_string(c, name);
    return c->func_count++;
}

int compiler_save(Compiler *c, const char *filename) {
    FILE *fp = fopen(filename, "wb");
    if (!fp) { perror("fopen"); return -1; }

    int32_t magic = BASHC_MAGIC;
    fwrite(&magic, 4, 1, fp);

    int32_t version = BASHC_VERSION;
    fwrite(&version, 4, 1, fp);

    /* 字符串表 */
    int32_t sc = c->str_count;
    fwrite(&sc, 4, 1, fp);
    for (int i = 0; i < c->str_count; i++) {
        int32_t len = c->strings[i].len;
        fwrite(&len, 4, 1, fp);
        fwrite(c->strings[i].data, 1, len, fp);
    }

    /* 函数表 */
    int32_t fc = c->func_count;
    fwrite(&fc, 4, 1, fp);
    for (int i = 0; i < c->func_count; i++) {
        int32_t name_idx = compiler_find_string(c, c->functions[i].name);
        int32_t addr = c->functions[i].addr;
        int32_t argc = c->functions[i].argc;
        fwrite(&name_idx, 4, 1, fp);
        fwrite(&addr, 4, 1, fp);
        fwrite(&argc, 4, 1, fp);
    }

    /* 代码段 */
    int32_t cs = c->code_size;
    fwrite(&cs, 4, 1, fp);
    fwrite(c->code, 1, cs, fp);

    fclose(fp);
    return 0;
}

void compiler_dump(Compiler *c) {
    printf("=== Bytecode Dump ===\n");
    printf("Strings: %d\n", c->str_count);
    for (int i = 0; i < c->str_count; i++) {
        printf("  [%d] \"%s\"\n", i, c->strings[i].data);
    }
    if (c->func_count > 0) {
        printf("Functions: %d\n", c->func_count);
        for (int i = 0; i < c->func_count; i++) {
            printf("  %s @ %d\n", c->functions[i].name, c->functions[i].addr);
        }
    }
    printf("Code: %d bytes\n", c->code_size);
    int pos = 0;
    while (pos < c->code_size) {
        Opcode op = (Opcode)c->code[pos];
        int n = opcode_operand_count(op);
        printf("  %04d: %02X", pos, op);
        pos++;
        for (int i = 0; i < n; i++) {
            int32_t val;
            memcpy(&val, c->code + pos, 4);
            pos += 4;
            printf(" %d", val);
        }
        const char *names[] = {
            [OP_NOP]="NOP", [OP_HALT]="HALT",
            [OP_PUSH_STR]="PUSH_STR", [OP_PUSH_INT]="PUSH_INT",
            [OP_POP]="POP", [OP_DUP]="DUP",
            [OP_STORE]="STORE", [OP_LOAD]="LOAD", [OP_EXPORT]="EXPORT",
            [OP_EXPAND]="EXPAND", [OP_EXPAND_PAT]="EXPAND_PAT", [OP_EXPAND_ALL]="EXPAND_ALL",
            [OP_SHIFT]="SHIFT", [OP_UNSET]="UNSET",
            [OP_ADD]="ADD", [OP_SUB]="SUB", [OP_MUL]="MUL", [OP_DIV]="DIV", [OP_MOD]="MOD",
            [OP_NEG]="NEG", [OP_NOT]="NOT", [OP_BIT_AND]="BIT_AND",
            [OP_CMP_LT]="CMP_LT", [OP_CMP_GT]="CMP_GT",
            [OP_CMP_LE]="CMP_LE", [OP_CMP_GE]="CMP_GE",
            [OP_CMP_EQ]="CMP_EQ", [OP_CMP_NE]="CMP_NE",
            [OP_BIT_OR]="BIT_OR", [OP_BIT_XOR]="BIT_XOR",
            [OP_ECHO]="ECHO", [OP_ECHO_N]="ECHO_N", [OP_PRINTF]="PRINTF",
            [OP_EXEC]="EXEC", [OP_EXEC_BUILTIN]="EXEC_BUILTIN",
            [OP_TEST]="TEST", [OP_READ]="READ", [OP_LET]="LET",
            [OP_JMP]="JMP", [OP_JZ]="JZ", [OP_JNZ]="JNZ",
            [OP_CALL]="CALL", [OP_RET]="RET",
            [OP_CASE]="CASE", [OP_CASE_END]="CASE_END",
            [OP_REDIR_OUT]="REDIR_OUT", [OP_REDIR_IN]="REDIR_IN",
            [OP_REDIR_APP]="REDIR_APP", [OP_REDIR_RESTORE]="REDIR_RESTORE",
            [OP_REDIR_ERR]="REDIR_ERR", [OP_HEREDOC]="HEREDOC",
            [OP_PIPE]="PIPE",
            [OP_FOR_BEGIN]="FOR_BEGIN", [OP_FOR_NEXT]="FOR_NEXT",
            [OP_WHILE_BEG]="WHILE_BEG", [OP_WHILE_END]="WHILE_END",
            [OP_SELECT_BEG]="SELECT_BEG", [OP_SELECT_END]="SELECT_END",
            [OP_BLOCK_BEG]="BLOCK_BEG", [OP_BLOCK_END]="BLOCK_END",
            [OP_FUNC_DEF]="FUNC_DEF", [OP_FUNC_CALL]="FUNC_CALL",
            [OP_ARRAY_SET]="ARRAY_SET", [OP_ARRAY_GET]="ARRAY_GET",
            [OP_CD]="CD", [OP_EXIT]="EXIT", [OP_SOURCE]="SOURCE",
            [OP_PWD]="PWD", [OP_BREAK]="BREAK", [OP_CONTINUE]="CONTINUE",
            [OP_ALIAS]="ALIAS", [OP_UNALIAS]="UNALIAS",
            [OP_EXEC_CMD]="EXEC_CMD", [OP_TYPE]="TYPE",
            [OP_WAIT]="WAIT", [OP_JOBS]="JOBS", [OP_BG]="BG", [OP_FG]="FG",
            [OP_KILL]="KILL", [OP_UMASK]="UMASK", [OP_ULIMIT]="ULIMIT",
            [OP_TIMES]="TIMES", [OP_TRAP]="TRAP", [OP_GETOPTS]="GETOPTS",
            [OP_DECLARE]="DECLARE", [OP_LOCAL]="LOCAL", [OP_MAPFILE]="MAPFILE",
            [OP_COMPGEN]="COMPGEN", [OP_COMPLETE]="COMPLETE",
            [OP_ENABLE]="ENABLE", [OP_BUILTIN]="BUILTIN",
            [OP_CALLER]="CALLER", [OP_DIRS]="DIRS",
            [OP_PUSHD]="PUSHD", [OP_POPD]="POPD", [OP_DISOWN]="DISOWN",
            [OP_SHOPT]="SHOPT", [OP_SUSPEND]="SUSPEND",
            [OP_TEST_CMD]="TEST_CMD", [OP_HASH]="HASH",
            [OP_BIND]="BIND", [OP_HELP]="HELP", [OP_HISTORY]="HISTORY",
            [OP_LOGOUT]="LOGOUT", [OP_SET]="SET",
        };
        if (op < (int)(sizeof(names)/sizeof(names[0])) && names[op])
            printf("  ; %s", names[op]);
        printf("\n");
    }
}

/* 查找内置命令 */
int builtin_lookup(const char *name) {
    for (int i = 0; i < builtin_table_size; i++) {
        if (strcmp(builtin_table[i].name, name) == 0)
            return (int)builtin_table[i].id;
    }
    return -1;
}